HOLYFAITH ACADEMY V8000.1 - QUICK PREVIEW

1. Extract the ZIP.
2. Double-click RUN-PREVIEW.bat.
3. The browser opens http://localhost:3000.
4. Keep the black server window open while using the preview.
5. Close the server window to stop the preview.

This preview uses the local JSON data in WindowsApp/data and does NOT require PostgreSQL.

@echo off
cd /d "%~dp0WindowsApp"
if not exist node_modules (echo Installing backend dependency... & npm install --omit=dev)
echo Set DATABASE_URL before starting online mode.
node server.js
pause

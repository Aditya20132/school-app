# Holyfaith Academy iOS App — V8.000

This is the iPhone/iPad companion app for SchoolHub V8000. It opens the same online school portal/backend used by Android, Windows and the web.

## Build on a Mac
1. Open `HolyfaithAcademy.xcodeproj` in Xcode 26+.
2. In Signing & Capabilities, choose your Apple Developer Team and a unique Bundle Identifier if needed.
3. Set the School Portal URL in `ContentView.swift` (`defaultURL`) or use the in-app Website Settings screen.
4. Select a simulator/iPhone and Build/Run.
5. For App Store: Product → Archive → Distribute App → App Store Connect.

The app intentionally uses the same HTTPS web portal, so school data is never duplicated between platforms.

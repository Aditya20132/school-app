import SwiftUI
import WebKit

struct ContentView: View {
    @AppStorage("schoolURL") private var schoolURL = "https://YOUR-SCHOOL-DOMAIN.example/"
    @State private var editing = false
    @State private var draft = ""

    var body: some View {
        NavigationStack {
            Group {
                if let url = URL(string: schoolURL), url.scheme?.lowercased() == "https", url.host != nil, !schoolURL.contains("YOUR-SCHOOL-DOMAIN") {
                    SchoolWebView(url: url)
                } else {
                    setup
                }
            }
            .navigationTitle("Holyfaith Academy")
            .toolbar {
                if schoolURL.contains("http") && !schoolURL.contains("YOUR-SCHOOL-DOMAIN") {
                    ToolbarItem(placement: .topBarTrailing) { Button("Settings") { draft = schoolURL; editing = true } }
                }
            }
            .sheet(isPresented: $editing) { settingsSheet }
        }
    }

    private var setup: some View {
        VStack(spacing: 18) {
            Image("holyfaith-logo").resizable().scaledToFit().frame(height: 150)
            Text("HOLYFAITH ACADEMY").font(.title2.bold())
            Text("SchoolHub V8.000").foregroundStyle(.secondary)
            Text("Connect this app to your school's secure HTTPS portal.").multilineTextAlignment(.center).foregroundStyle(.secondary)
            TextField("https://school.example.com/", text: $draft).textInputAutocapitalization(.never).keyboardType(.URL).textFieldStyle(.roundedBorder)
            Button("Save & Open School") { saveURL() }.buttonStyle(.borderedProminent)
        }.padding(28).onAppear { draft = schoolURL.contains("YOUR-SCHOOL-DOMAIN") ? "" : schoolURL }
    }

    private var settingsSheet: some View {
        NavigationStack {
            Form {
                Section("School Portal") { TextField("HTTPS URL", text: $draft).textInputAutocapitalization(.never).keyboardType(.URL) }
                Section { Button("Save & Open") { saveURL(); editing = false } }
            }.navigationTitle("Website Settings")
        }
    }

    private func saveURL() {
        var value = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        if !value.lowercased().hasPrefix("https://") { return }
        if !value.hasSuffix("/") { value += "/" }
        schoolURL = value
    }
}

struct SchoolWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let view = WKWebView(frame: .zero)
        view.configuration.websiteDataStore = .default()
        view.load(URLRequest(url: url))
        return view
    }
    func updateUIView(_ view: WKWebView, context: Context) { }
}

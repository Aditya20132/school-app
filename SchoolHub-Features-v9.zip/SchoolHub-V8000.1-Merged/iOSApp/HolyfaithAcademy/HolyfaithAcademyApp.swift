import SwiftUI

@main
struct HolyfaithAcademyApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

$ErrorActionPreference = 'Stop'
$dir = Join-Path $PSScriptRoot 'node'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$url = 'https://nodejs.org/dist/v22.19.0/node-v22.19.0-win-x64.zip'
$zip = Join-Path $env:TEMP 'holyfaith-node.zip'
Invoke-WebRequest -Uri $url -OutFile $zip
if (Test-Path (Join-Path $dir 'node.exe')) { Remove-Item $dir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Expand-Archive -Path $zip -DestinationPath $env:TEMP -Force
$src = Join-Path $env:TEMP 'node-v22.19.0-win-x64'
Copy-Item (Join-Path $src '*') $dir -Recurse -Force
Remove-Item $src -Recurse -Force
Remove-Item $zip -Force
Write-Host 'Portable Node.js is ready.'

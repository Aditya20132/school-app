$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $PSScriptRoot 'jdk21'
$zip = Join-Path $PSScriptRoot 'jdk21.zip'
if (Test-Path (Join-Path $dest 'bin\java.exe')) { exit 0 }
Write-Host 'Downloading portable Java 21 (Temurin) ...'
$url = 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse'
Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
New-Item -ItemType Directory -Path $dest | Out-Null
$tmp = Join-Path $PSScriptRoot 'jdk21-extract'
if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Path $tmp | Out-Null
Expand-Archive -Path $zip -DestinationPath $tmp -Force
$jdkDir = Get-ChildItem $tmp -Directory | Select-Object -First 1
if (-not $jdkDir) { throw 'Downloaded Java archive did not contain a JDK folder.' }
Copy-Item (Join-Path $jdkDir.FullName '*') $dest -Recurse -Force
Remove-Item $tmp -Recurse -Force
Remove-Item $zip -Force
if (-not (Test-Path (Join-Path $dest 'bin\java.exe'))) { throw 'Java 21 installation failed.' }
Write-Host "Java 21 ready: $dest"

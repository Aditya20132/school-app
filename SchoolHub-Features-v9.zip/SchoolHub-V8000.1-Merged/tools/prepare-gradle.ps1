$ErrorActionPreference = 'Stop'
$android = Join-Path $PSScriptRoot '..\AndroidApp'
$gradleDir = Join-Path $PSScriptRoot 'gradle'
$zip = Join-Path $env:TEMP 'holyfaith-gradle.zip'
$url = 'https://services.gradle.org/distributions/gradle-8.10.2-bin.zip'
Invoke-WebRequest -Uri $url -OutFile $zip
if (Test-Path $gradleDir) { Remove-Item $gradleDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $gradleDir | Out-Null
Expand-Archive -Path $zip -DestinationPath $gradleDir -Force
$install = Join-Path $gradleDir 'gradle-8.10.2'
$wrapperDir = Join-Path $android 'gradle\wrapper'
New-Item -ItemType Directory -Force -Path $wrapperDir | Out-Null
# Generate wrapper files by using Gradle directly.
& (Join-Path $install 'bin\gradle.bat') -p $android wrapper --gradle-version 8.10.2
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Remove-Item $zip -Force
Write-Host 'Gradle wrapper is ready.'

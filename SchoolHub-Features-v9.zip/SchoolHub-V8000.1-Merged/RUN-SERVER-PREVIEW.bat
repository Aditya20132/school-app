@echo off
setlocal
cd /d "%~dp0WindowsApp"
set "PREVIEW_MODE=true"
set "PORT=3000"
if exist "%~dp0tools\node\node.exe" (
  "%~dp0tools\node\node.exe" server.js
) else (
  node server.js
)
echo.
echo Preview server stopped.
pause
endlocal

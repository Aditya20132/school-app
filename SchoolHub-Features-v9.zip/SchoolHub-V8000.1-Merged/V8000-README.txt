HOLYFAITH ACADEMY SCHOOLHUB V8000
=================================

V8000 is the unified platform version.

PLATFORMS
- Web: the same Node.js school portal
- Windows: existing SchoolHub desktop/server package
- Android: WebView app, version 8.000, HTTPS portal URL can be changed in-app
- iOS/iPadOS: iOSApp/HolyfaithAcademy.xcodeproj, same HTTPS portal/backend

ONE BACKEND + ONE DATABASE
All clients connect to the same school backend and PostgreSQL database. Do not create a separate database for each app.

EXISTING FEATURES INCLUDED
- Admin / Teacher / Guardian roles
- All Classes teacher
- Student management and photos
- Excel/CSV import up to 1,500 students
- Automatic guardian accounts
- Attendance: Present / Absent / Leave
- Subjects and teacher subject ownership
- Exams, marks, variable total marks
- Result Draft / Published / Locked status
- Rank, percentage and grades
- Report cards
- Monthly tuition fees and admission fees
- Fee receipts and partial payments
- Homework for any class
- Timetable, calendar, announcements
- Academic session promotion
- Class create/delete for administrators
- Backup/restore and audit log
- Modern premium login

ONLINE DEPLOYMENT
1. Put WindowsApp on a server with Node 20+ and PostgreSQL, or use the included Docker setup.
2. Set DATABASE_URL in the environment.
3. Run: npm install --omit=dev
4. Run: npm start
5. Put HTTPS in front of port 3000 using your preferred reverse proxy/tunnel.
6. Set that HTTPS portal URL in Android and iOS apps.

HEALTH CHECK
GET /api/health returns version 8.0.0 and database status.

IMPORTANT
The Windows EXE is still a self-contained Node SEA server application, not a traditional MSI installer. The iOS app must be signed with an Apple Developer account before App Store distribution.


V8000.1 FEATURE PACK
- Advanced Analytics dashboard
- Guardian Multiple-Child Family Overview
- Student Documents with upload/delete/open
- Printable Student ID Card generator
- Printable certificate generator (Bonafide, Character, Study, Fee, Transfer, custom title)
- Automatic startup + daily JSON backups, 30-file retention, manual backup and restore
- Existing Teacher Attendance + Global Search retained

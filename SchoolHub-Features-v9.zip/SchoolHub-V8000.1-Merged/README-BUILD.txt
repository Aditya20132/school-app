HOLYFAITH ACADEMY - ONE CLICK BUILD

This package builds:
  BUILD-OUTPUT\Holyfaith-Academy.apk
  BUILD-OUTPUT\Holyfaith-Academy.exe

IMPORTANT:
- Android Studio is required for the Android SDK.
- Install Android SDK Platform 35 (Android 15 / API 35).
- You may keep API 37 installed too.
- The build script now automatically prefers Android Studio's bundled Java and avoids the Java 25 / Gradle 8.10.2 error.
- If Android Studio's Java is not found, the script automatically downloads a portable Java 21 copy.

STEPS
1. Install/open Android Studio once.
2. In SDK Manager, install Android SDK Platform 35.
3. Extract this ZIP.
4. Double-click BUILD-ALL.bat.
5. Wait for the build to finish.
6. Open BUILD-OUTPUT.

APK NOTE
The APK is a DEBUG APK for testing/direct installation. A release APK for public distribution should be signed with your own release keystore.

WINDOWS NOTE
The EXE is a single executable server application, not a traditional Windows Setup installer.

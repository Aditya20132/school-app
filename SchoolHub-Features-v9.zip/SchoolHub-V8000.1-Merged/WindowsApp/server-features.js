'use strict';
/* SchoolHub feature pack: day-book, daily collection report, sequential receipts, student ledger,
   payment edit log + undo, clerk role, payment-proof approval, attendance alerts, off-site backup. */
const fs = require('fs'), path = require('path');

module.exports = function (ctx) {
  const D = () => ctx.db();
  const esc = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const today = () => ctx.localDate();
  const nid = arr => arr.length ? Math.max(...arr.map(x => Number(x.id) || 0)) + 1 : 1;
  const MODES = ['Cash', 'UPI', 'Cheque', 'Bank', 'Other'];
  const normMode = m => { const s = String(m || 'Cash').trim().toLowerCase(); if (s === 'cash') return 'Cash'; if (s.includes('upi') || s.includes('gpay') || s.includes('phonepe') || s.includes('paytm')) return 'UPI'; if (s.startsWith('cheq') || s.startsWith('chec') || s === 'dd') return 'Cheque'; if (s.includes('bank') || s.includes('neft') || s.includes('imps') || s.includes('rtgs') || s.includes('transfer')) return 'Bank'; return 'Other'; };

  function ensure() {
    const d = D();
    for (const k of ['payments', 'payment_log', 'payment_proofs', 'alert_sent', 'feature_settings']) if (!Array.isArray(d[k])) d[k] = [];
    if (!d.feature_settings.length) d.feature_settings.push({ id: 1, receipt_prefix: 'HFA', counters: {}, offsite_dir: '', last_offsite: null });
    const s = d.feature_settings[0]; if (!s.counters) s.counters = {}; if (!s.receipt_prefix) s.receipt_prefix = 'HFA';
    return s;
  }
  const settings = () => ensure();

  /* ---------- sequential receipt numbers: HFA/2026-27/0001 ---------- */
  function receiptInUse(no) { return D().fees.some(f => f.receipt_no === no || f.receipt_group === no); }
  function nextReceipt() {
    const s = settings(), yr = (D().years.find(y => Number(y.is_current)) || {}).name || String(new Date().getFullYear());
    let n = Number(s.counters[yr] || 0), no;
    do { n++; no = `${s.receipt_prefix}/${yr}/${String(n).padStart(4, '0')}`; } while (receiptInUse(no));
    s.counters[yr] = n; return no;
  }

  /* ---------- fee snapshots / payment ledger / edit log ---------- */
  const FIELDS = ['amount', 'paid', 'paid_date', 'receipt_no', 'receipt_group', 'pay_mode', 'instrument_no', 'bank_name', 'status', 'group_paid', 'remark'];
  const pick = f => { const o = {}; for (const k of FIELDS) if (f[k] !== undefined) o[k] = f[k]; return o; };
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const snapAll = () => { const m = new Map(); for (const f of D().fees) m.set(f.id, pick(f)); return m; };

  function ledger(f, amount, user, type, receipt, extra = {}) {
    const d = D();
    d.payments.push({ id: nid(d.payments), ts: new Date().toISOString(), date: extra.date || f.paid_date || today(), fee_id: f.id, student_id: f.student_id, receipt_no: receipt || f.receipt_no || '', amount: ctx.round2(amount), mode: normMode(extra.mode || f.pay_mode), instrument: extra.instrument ?? f.instrument_no ?? '', by: user ? user.name : '', by_id: user ? user.id : 0, type });
  }
  function logChange(user, type, f, before, after, note) {
    const d = D();
    d.payment_log.push({ id: nid(d.payment_log), ts: new Date().toISOString(), user: user ? user.name : '', user_id: user ? user.id : 0, type, fee_id: f.id, student_id: f.student_id, fee_label: f.fee_type === 'Admission Fee' ? 'Admission Fee' : (f.month || f.fee_type || 'Fee'), before, after, note: note || '', undone: false });
    if (d.payment_log.length > 5000) d.payment_log = d.payment_log.slice(-5000);
  }

  /* run after a fee-changing request has finished: write ledger + log + convert RCP-<timestamp> into the series */
  function afterFees(before, user) {
    const d = D(), remap = new Map(); let changed = false;
    for (const f of d.fees) {
      const b = before.get(f.id), a = pick(f);
      if (b && same(b, a)) continue;
      const bb = b || { amount: a.amount, paid: 0, paid_date: '', receipt_no: '', pay_mode: a.pay_mode, status: 'Pending' };
      const delta = ctx.round2(Number(a.paid || 0) - Number(bb.paid || 0));
      if (delta > 0 && a.receipt_no && a.receipt_no !== bb.receipt_no && /^RCP-\d+$/.test(a.receipt_no)) {
        if (!remap.has(a.receipt_no)) remap.set(a.receipt_no, nextReceipt());
        const nn = remap.get(a.receipt_no);
        if (f.receipt_group === f.receipt_no) f.receipt_group = nn;
        f.receipt_no = nn;
      }
      const after = pick(f);
      if (delta > 0) { ledger(f, delta, user, 'PAYMENT', f.receipt_no); logChange(user, b ? 'PAYMENT' : 'PAYMENT', f, bb, after, 'Payment received'); }
      else if (delta < 0) { ledger(f, delta, user, 'REVERSAL', bb.receipt_no, { date: today(), mode: bb.pay_mode, instrument: bb.instrument_no }); logChange(user, 'EDIT', f, bb, after, 'Payment reduced / cleared'); }
      else logChange(user, 'EDIT', f, bb, after, 'Fee or payment details edited');
      changed = true;
    }
    if (changed) ctx.save();
    return remap;
  }

  /* ---------- apply a payment to a student's oldest dues (used by proof approval) ---------- */
  function applyPayment(sid, amount, o) {
    const d = D();
    const list = d.fees.filter(f => Number(f.student_id) === Number(sid) && !f.cancelled && ctx.feeBal(f) > 0).sort((a, b) => String(a.due_date).localeCompare(String(b.due_date)) || a.id - b.id);
    const total = ctx.round2(list.reduce((n, f) => n + ctx.feeBal(f), 0));
    if (!list.length) return { error: 'This student has no pending fees.' };
    const amt = Math.min(ctx.round2(amount), total);
    if (!(amt > 0)) return { error: 'Invalid amount' };
    const no = nextReceipt(); let left = amt; const applied = [];
    for (const f of list) {
      if (left <= 0) break;
      const before = pick(f), pay = Math.min(ctx.feeBal(f), left); left = ctx.round2(left - pay);
      f.paid = ctx.round2(Number(f.paid || 0) + pay); f.group_paid = pay; f.paid_date = o.date; f.receipt_no = no; f.receipt_group = no;
      f.pay_mode = o.mode; f.instrument_no = o.instrument || ''; f.remark = o.remark || f.remark || '';
      f.status = Number(f.paid) >= Number(f.amount) ? 'Paid' : 'Partial';
      ledger(f, pay, o.user, 'PAYMENT', no, { date: o.date, mode: o.mode, instrument: o.instrument });
      logChange(o.user, 'PAYMENT', f, before, pick(f), o.note || 'Payment received');
      applied.push({ id: f.id, paid: pay });
    }
    ctx.save();
    return { receipt: no, received: amt, applied, excess: ctx.round2(amount - amt) };
  }

  /* ---------- roles ---------- */
  const isClerk = u => !!(u && u.role === 'admin' && (D().users.find(x => Number(x.id) === Number(u.id)) || {}).clerk);
  const CLERK_BLOCK = [
    /^\/api\/setup\//, /^\/api\/academic-session/, /^\/api\/restore/, /^\/api\/backup/, /^\/api\/fee-rules/,
    /^\/api\/fees\/(settings|concession|generate-monthly|generate-admission)/, /^\/api\/fees\/\d+\/(cancel|restore|waive-late)/,
    /^\/api\/users\//, /^\/api\/safety\//, /^\/api\/payment-log\/\d+\/undo/, /^\/api\/transport\/settings/
  ];

  /* ---------- day book ---------- */
  function entries(from, to) {
    const d = D(), out = [], sd = new Map(ctx.studentsDetailed().map(s => [Number(s.id), s]));
    const feeById = new Map(d.fees.map(f => [f.id, f])), hasLedger = new Set(d.payments.map(p => p.fee_id));
    const label = f => f ? (f.fee_type === 'Admission Fee' ? 'Admission Fee' : (f.month || f.fee_type || 'Fee')) : '';
    const add = (date, no, sid, what, amt, mode, ins, by, kind, type) => {
      if (date < from || date > to) return; const s = sd.get(Number(sid)) || {};
      out.push({ date, receipt_no: no || '', student: s.name || '(deleted)', code: s.student_id || '', cls: [s.class_name, s.section_name].filter(Boolean).join('-'), what, amount: ctx.round2(amt), mode: normMode(mode), instrument: ins || '', by: by || '', kind, type: type || 'PAYMENT' });
    };
    for (const p of d.payments) add(p.date, p.receipt_no, p.student_id, label(feeById.get(p.fee_id)), p.amount, p.mode, p.instrument, p.by, 'School fee', p.type);
    for (const f of d.fees) { if (f.cancelled || hasLedger.has(f.id) || !(Number(f.paid) > 0) || !f.paid_date) continue; add(f.paid_date, f.receipt_no, f.student_id, label(f), Number(f.group_paid) || Number(f.paid), f.pay_mode, f.instrument_no, '', 'School fee'); }
    for (const t of (d.transport_fees || [])) { if (!t.paid || !t.paid_on) continue; add(t.paid_on, t.receipt_no, t.student_id, 'Transport ' + (t.month || ''), Math.max(0, Number(t.amount || 0) - Number(t.discount || 0)), t.mode, '', t.received_by, 'Transport'); }
    out.sort((a, b) => a.date.localeCompare(b.date) || String(a.receipt_no).localeCompare(String(b.receipt_no)));
    return out;
  }
  const dateOk = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || ''));

  function pageShell(title, body) {
    return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>*{box-sizing:border-box}body{margin:0;background:#eee;font-family:Arial,Helvetica,sans-serif;color:#111}.sheet{width:210mm;min-height:200mm;margin:18px auto;background:#fff;padding:14mm;border:1px solid #888;color:#111}.school{text-align:center;border-bottom:2px solid #222;padding-bottom:8px;margin-bottom:10px}.school img{height:56px}.school h1{margin:4px 0 0;font-family:Georgia,serif;font-size:22px;letter-spacing:1.5px}.school p{margin:2px 0;font-size:10px}h2{margin:10px 0 4px;font-size:17px;text-align:center;letter-spacing:.5px}table{width:100%;border-collapse:collapse;font-size:11px;margin-top:8px}th,td{border:1px solid #555;padding:5px 6px;text-align:left}th{background:#eee}td.r,th.r{text-align:right}tr.tot td{font-weight:800;background:#f4f4f4}.neg{color:#b00020}.meta{display:flex;justify-content:space-between;font-size:12px;margin:6px 0}.box{border:1px solid #555;padding:8px 10px;margin-top:10px;font-size:12px;line-height:2}.sig{display:flex;justify-content:space-between;margin-top:50px;font-size:11px}.sig div{width:30%;text-align:center;border-top:1px solid #333;padding-top:5px}.pbtn{position:fixed;right:18px;top:18px;padding:10px 16px;border:0;border-radius:8px;background:#1d4ed8;color:#fff;font-weight:700;cursor:pointer}@media print{body{background:#fff}.sheet{margin:0;border:0;width:100%;padding:6mm}.pbtn{display:none}}@page{size:A4;margin:8mm}</style></head><body><button class="pbtn" onclick="print()">Print / Save as PDF</button>${body}</body></html>`;
  }
  const schoolHead = () => `<div class="school"><img src="/assets/holyfaith-logo.png" alt=""><h1>HOLYFAITH ACADEMY</h1><p>Affiliated to CISCE 10+2, New Delhi.</p><p>01 School Road, NH 12, New Dakbanglow, Dhuliyan, Murshidabad, West Bengal - 742202</p><p>Contact: 9332280028 &nbsp;|&nbsp; E-Mail: admin@myholyfaith.org</p></div>`;

  function dailyReportHtml(date, user) {
    const rows = entries(date, date), by = {}; MODES.forEach(m => by[m] = { n: 0, amt: 0 });
    rows.forEach(r => { by[r.mode].amt += r.amount; if (r.amount > 0) by[r.mode].n++; });
    const total = rows.reduce((n, r) => n + r.amount, 0), cash = by.Cash.amt;
    const body = `<div class="sheet">${schoolHead()}<h2>DAILY COLLECTION REPORT</h2><div class="meta"><span><b>Date:</b> ${esc(date)}</span><span><b>Prepared by:</b> ${esc(user.name)}</span></div>
<table><thead><tr><th>Mode of payment</th><th class="r">Receipts</th><th class="r">Amount (₹)</th></tr></thead><tbody>${MODES.map(m => `<tr><td>${m}</td><td class="r">${by[m].n}</td><td class="r">${money(by[m].amt)}</td></tr>`).join('')}<tr class="tot"><td>TOTAL FOR THE DAY</td><td class="r">${rows.filter(r => r.amount > 0).length}</td><td class="r">${money(total)}</td></tr></tbody></table>
<div class="box"><b>Cash drawer match</b><br>Cash as per books: <b>₹ ${money(cash)}</b> &nbsp;&nbsp; Cash counted in drawer: ₹ ______________ &nbsp;&nbsp; Difference: ₹ ______________</div>
<h2 style="text-align:left;font-size:13px;margin-top:16px">Receipts of the day</h2>
<table><thead><tr><th>#</th><th>Receipt no.</th><th>Student</th><th>Class</th><th>For</th><th>Mode</th><th>Ref / Cheque no.</th><th>Received by</th><th class="r">Amount (₹)</th></tr></thead><tbody>${rows.map((r, i) => `<tr><td>${i + 1}</td><td>${esc(r.receipt_no)}</td><td>${esc(r.student)}<br><small>${esc(r.code)}</small></td><td>${esc(r.cls)}</td><td>${esc(r.what)}${r.type === 'REVERSAL' ? '<br><small>(payment edited/cleared)</small>' : ''}</td><td>${esc(r.mode)}</td><td>${esc(r.instrument)}</td><td>${esc(r.by)}</td><td class="r ${r.amount < 0 ? 'neg' : ''}">${money(r.amount)}</td></tr>`).join('') || '<tr><td colspan="9" style="padding:14px">No collections recorded on this date.</td></tr>'}</tbody></table>
<div class="sig"><div>Cashier</div><div>Accountant</div><div>Principal</div></div></div>`;
    return pageShell('Daily Collection ' + date, body);
  }

  /* ---------- student ledger ---------- */
  function ledgerHtml(st) {
    const d = D(), rows = [], feeLabel = f => f.fee_type === 'Admission Fee' ? 'Admission Fee' : `${f.fee_type || 'Fee'}${f.month ? ' – ' + f.month : ''}`;
    let seq = 0;
    const push = (date, order, desc, debit, credit, ref) => rows.push({ date: date || '0000-00-00', order, seq: seq++, desc, debit: debit || 0, credit: credit || 0, ref: ref || '' });
    const byFee = new Map(); for (const p of d.payments) { if (!byFee.has(p.fee_id)) byFee.set(p.fee_id, []); byFee.get(p.fee_id).push(p); }
    for (const f of d.fees) {
      if (Number(f.student_id) !== Number(st.id) || f.cancelled) continue;
      const disc = Number(f.discount || 0), late = Number(f.late_fee || 0), base = f.base_amount != null ? Number(f.base_amount) : Number(f.amount) + disc - late, lab = feeLabel(f);
      push(f.due_date, 0, lab, base, 0);
      if (disc > 0) push(f.due_date, 1, 'Concession – ' + lab, 0, disc, (st.fee_concession && st.fee_concession.reason) || '');
      if (late > 0) push(f.due_date, 2, 'Late fine – ' + lab, late, 0);
      const ps = byFee.get(f.id) || [];
      if (ps.length) for (const p of ps) { if (p.amount >= 0) push(p.date, 3, `Payment – ${lab} (${p.mode})`, 0, p.amount, p.receipt_no); else push(p.date, 3, `Payment reversed – ${lab}`, -p.amount, 0, p.receipt_no); }
      else if (Number(f.paid) > 0) push(f.paid_date, 3, `Payment – ${lab} (${normMode(f.pay_mode)})`, 0, Number(f.group_paid) || Number(f.paid), f.receipt_no);
    }
    for (const t of (d.transport_fees || [])) {
      if (Number(t.student_id) !== Number(st.id)) continue; const net = Math.max(0, Number(t.amount || 0) - Number(t.discount || 0));
      push(t.month + '-01', 0, 'Transport fee – ' + t.month, Number(t.amount || 0), 0);
      if (Number(t.discount) > 0) push(t.month + '-01', 1, 'Transport concession – ' + t.month, 0, Number(t.discount));
      if (t.paid) push(t.paid_on, 3, `Payment – Transport ${t.month} (${normMode(t.mode)})`, 0, net, t.receipt_no);
    }
    rows.sort((a, b) => a.date.localeCompare(b.date) || a.order - b.order || a.seq - b.seq);
    let bal = 0, td = 0, tc = 0;
    const trs = rows.map(r => { bal = ctx.round2(bal + r.debit - r.credit); td += r.debit; tc += r.credit; return `<tr><td>${r.date === '0000-00-00' ? '—' : esc(r.date)}</td><td>${esc(r.desc)}${r.ref ? `<br><small>${esc(r.ref)}</small>` : ''}</td><td class="r">${r.debit ? money(r.debit) : ''}</td><td class="r">${r.credit ? money(r.credit) : ''}</td><td class="r"><b>${money(bal)}</b></td></tr>`; }).join('');
    const body = `<div class="sheet">${schoolHead()}<h2>STUDENT FEE LEDGER</h2><div class="box" style="line-height:1.8"><b>${esc(st.name)}</b> &nbsp;•&nbsp; ID ${esc(st.student_id)} &nbsp;•&nbsp; Class ${esc([st.class_name, st.section_name].filter(Boolean).join('-'))} &nbsp;•&nbsp; Session ${esc(st.year)}<br>Guardian: ${esc(st.guardian_name || '—')} &nbsp; Printed on ${esc(today())}</div>
<table><thead><tr><th style="width:80px">Date</th><th>Particulars</th><th class="r">Charges (₹)</th><th class="r">Credits (₹)</th><th class="r">Balance (₹)</th></tr></thead><tbody>${trs || '<tr><td colspan="5" style="padding:14px">No fee entries.</td></tr>'}<tr class="tot"><td colspan="2">TOTAL</td><td class="r">${money(td)}</td><td class="r">${money(tc)}</td><td class="r">${money(bal)}</td></tr></tbody></table>
<div class="box"><b>Balance outstanding: ₹ ${money(bal)}</b> &nbsp; <small>Charges = fees, fines and transport. Credits = payments and concessions. Payment reversals appear as charges.</small></div>
<div class="sig"><div>Guardian</div><div>Accountant</div><div>Principal</div></div></div>`;
    return pageShell('Fee Ledger – ' + st.name, body);
  }

  /* ---------- attendance alerts ---------- */
  function attendanceAlerts(u) {
    const d = D(), by = new Map(), out = [];
    for (const a of d.attendance) { if (!a.date) continue; if (!by.has(Number(a.student_id))) by.set(Number(a.student_id), []); by.get(Number(a.student_id)).push(a); }
    const sent = new Map(d.alert_sent.map(x => [x.key, x])), limit = new Date(Date.now() - 6 * 86400000), lim = ctx.localDate(limit);
    for (const st of ctx.scope(u)) {
      if (String(st.status || 'Active').toLowerCase() !== 'active') continue;
      const recs = (by.get(Number(st.id)) || []).sort((a, b) => b.date.localeCompare(a.date)); let n = 0;
      for (const r of recs) { if (String(r.status).toLowerCase() === 'absent') n++; else break; }
      if (n < 2 || recs[0].date < lim) continue;
      const g = d.users.find(x => Number(x.id) === Number(st.guardian_id)) || {}, key = `${st.id}:${recs[0].date}`;
      out.push({ key, student_id: st.id, name: st.name, code: st.student_id, cls: st.class_name, sec: st.section_name, guardian: st.guardian_name || g.name || '', phone: st.phone || st.guardian_phone || g.phone || '', days: n, since: recs[n - 1].date, last: recs[0].date, sent: sent.has(key) ? sent.get(key) : null });
    }
    return out.sort((a, b) => b.last.localeCompare(a.last) || b.days - a.days);
  }

  /* ---------- off-site backup ---------- */
  async function offsite(buf, name) {
    const s = settings(); if (!s.offsite_dir) return null;
    try {
      fs.mkdirSync(s.offsite_dir, { recursive: true });
      fs.writeFileSync(path.join(s.offsite_dir, name), buf);
      const files = fs.readdirSync(s.offsite_dir).filter(x => /^schoolhub-.*\.json$/.test(x)).sort();
      while (files.length > 30) { try { fs.unlinkSync(path.join(s.offsite_dir, files.shift())); } catch { } }
      s.last_offsite = { at: new Date().toISOString(), ok: true, where: s.offsite_dir, name }; ctx.save(); return s.last_offsite;
    } catch (e) { s.last_offsite = { at: new Date().toISOString(), ok: false, where: s.offsite_dir, error: e.message }; ctx.save(); throw e; }
  }

  /* ---------- main router ---------- */
  const forbid = (res, msg) => ctx.json(res, 403, { error: msg || 'Permission denied' });
  const num = x => Number(x);

  async function handle(req, res, p, url) {
    if (!p.startsWith('/api/')) return false;
    const m = req.method;
    ensure();
    const u0 = (m !== 'GET' && m !== 'HEAD') ? await ctx.current(req) : null;

    /* clerk gate + fee-change hook */
    if (u0 && u0.role === 'admin') {
      if (isClerk(u0)) {
        const blocked = CLERK_BLOCK.some(r => r.test(p)) || (m === 'DELETE' && !/^\/api\/(messages|attachments)/.test(p));
        if (blocked) return forbid(res, 'This action is not allowed for a clerk account. Please ask the administrator.'), true;
        if (m === 'PUT' && /^\/api\/fees\/\d+$/.test(p)) {
          let v; try { v = await ctx.body(req); } catch { v = {}; } req.__json = v;
          const f = D().fees.find(x => x.id === num(p.split('/').pop()));
          if (f && v.amount !== undefined && ctx.round2(v.amount) !== ctx.round2(f.amount)) return forbid(res, 'Clerks can receive payments but cannot change the fee amount.'), true;
        }
      }
      if ((m === 'POST' || m === 'PUT') && /^\/api\/fees(\/|$)/.test(p)) {
        const before = snapAll(), orig = res.end.bind(res);
        res.end = function (chunk, ...rest) {
          try {
            if (res.statusCode === 200) {
              const remap = afterFees(before, u0);
              if (remap.size && chunk) { let s = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk); for (const [o, n] of remap) s = s.split(o).join(n); chunk = Buffer.from(s, 'utf8'); }
            }
          } catch (e) { console.error('Payment log hook failed:', e.message); }
          return orig(chunk, ...rest);
        };
      }
    }

    /* ---- context ---- */
    if (m === 'GET' && p === '/api/features/context') {
      const u = await ctx.auth(req, res); if (!u) return true;
      return ctx.json(res, 200, { clerk: isClerk(u), role: u.role, receipt_prefix: settings().receipt_prefix }), true;
    }

    /* ---- day book & daily report ---- */
    if (m === 'GET' && p === '/api/day-book') {
      const u = await ctx.auth(req, res, ['admin']); if (!u) return true;
      const from = url.searchParams.get('from') || today(), to = url.searchParams.get('to') || from;
      if (!dateOk(from) || !dateOk(to)) return ctx.json(res, 400, { error: 'Invalid date' }), true;
      const rows = entries(from, to), by = {}; MODES.forEach(k => by[k] = 0); rows.forEach(r => by[r.mode] += r.amount);
      return ctx.json(res, 200, { from, to, rows, by_mode: by, total: ctx.round2(rows.reduce((n, r) => n + r.amount, 0)) }), true;
    }
    if (m === 'GET' && p === '/api/reports/daily-collection') {
      const u = await ctx.auth(req, res, ['admin']); if (!u) return true;
      const date = url.searchParams.get('date') || today(); if (!dateOk(date)) return ctx.json(res, 400, { error: 'Invalid date' }), true;
      return ctx.send(res, 200, dailyReportHtml(date, u)), true;
    }

    /* ---- student ledger ---- */
    if (m === 'GET' && /^\/api\/student-ledger\/\d+$/.test(p)) {
      const u = await ctx.auth(req, res); if (!u) return true;
      const st = ctx.studentForUser(u, num(p.split('/').pop())); if (!st) return forbid(res), true;
      return ctx.send(res, 200, ledgerHtml(st)), true;
    }

    /* ---- payment log + undo ---- */
    if (m === 'GET' && p === '/api/payment-log') {
      const u = await ctx.auth(req, res, ['admin']); if (!u) return true;
      const sd = new Map(ctx.studentsDetailed().map(s => [Number(s.id), s])), lim = Math.min(500, num(url.searchParams.get('limit')) || 150);
      return ctx.json(res, 200, D().payment_log.slice(-lim).reverse().map(l => ({ ...l, student: (sd.get(Number(l.student_id)) || {}).name || '(deleted)' }))), true;
    }
    if (m === 'POST' && /^\/api\/payment-log\/\d+\/undo$/.test(p)) {
      const u = await ctx.auth(req, res, ['admin']); if (!u) return true;
      const d = D(), l = d.payment_log.find(x => x.id === num(p.split('/')[3]));
      if (!l) return ctx.json(res, 404, { error: 'Log entry not found' }), true;
      if (l.undone || l.type === 'UNDO') return ctx.json(res, 400, { error: 'This entry cannot be undone' }), true;
      const f = d.fees.find(x => x.id === l.fee_id); if (!f) return ctx.json(res, 404, { error: 'Fee record no longer exists' }), true;
      if (!same(pick(f), l.after)) return ctx.json(res, 409, { error: 'This fee was changed again after this entry. Undo the newer change first.' }), true;
      const cur = pick(f), delta = ctx.round2(Number(l.before.paid || 0) - Number(cur.paid || 0));
      for (const k of FIELDS) { if (l.before[k] === undefined) delete f[k]; else f[k] = l.before[k]; }
      if (!l.before.paid_date) f.paid_date = ''; if (!l.before.receipt_no) f.receipt_no = '';
      if (delta !== 0) ledger(f, delta, u, 'UNDO', cur.receipt_no, { date: today(), mode: cur.pay_mode, instrument: cur.instrument_no });
      l.undone = true; l.undone_by = u.name; l.undone_at = new Date().toISOString();
      logChange(u, 'UNDO', f, cur, pick(f), `Undid log #${l.id}`);
      ctx.audit(u, 'UNDO_PAYMENT_CHANGE', `Log #${l.id} fee ${f.id}`); ctx.save();
      return ctx.json(res, 200, { ok: true }), true;
    }

    /* ---- safety settings / clerks / off-site ---- */
    if (p.startsWith('/api/safety/')) {
      const u = await ctx.auth(req, res, ['admin']); if (!u) return true; if (isClerk(u)) return forbid(res), true;
      const d = D(), s = settings();
      if (m === 'GET' && p === '/api/safety/settings') return ctx.json(res, 200, { receipt_prefix: s.receipt_prefix, counters: s.counters, offsite_dir: s.offsite_dir || '', last_offsite: s.last_offsite, storage_driver: ctx.storage.driver, clerks: d.users.filter(x => x.role === 'admin' && x.clerk).map(x => ({ id: x.id, name: x.name, username: x.username })), admins: d.users.filter(x => x.role === 'admin' && !x.clerk).map(x => ({ id: x.id, name: x.name, username: x.username })) }), true;
      if (m === 'PUT' && p === '/api/safety/settings') {
        const v = await ctx.body(req), pre = String(v.receipt_prefix ?? s.receipt_prefix).trim().toUpperCase();
        if (!/^[A-Z0-9-]{1,10}$/.test(pre)) return ctx.json(res, 400, { error: 'Receipt prefix: 1–10 letters/numbers (e.g. HFA)' }), true;
        s.receipt_prefix = pre; s.offsite_dir = String(v.offsite_dir || '').trim();
        ctx.audit(u, 'SAFETY_SETTINGS', `prefix ${pre}; off-site folder ${s.offsite_dir || 'none'}`); ctx.save(); return ctx.json(res, 200, { ok: true }), true;
      }
      if (m === 'POST' && p === '/api/safety/offsite-now') {
        if (!s.offsite_dir) return ctx.json(res, 400, { error: 'Set an off-site folder first and press Save.' }), true;
        try { const buf = Buffer.from(await ctx.backupPayload()), name = `schoolhub-manual-${new Date().toISOString().replace(/[:.]/g, '-')}.json`; const r = await offsite(buf, name); ctx.audit(u, 'OFFSITE_BACKUP', name); return ctx.json(res, 200, { ok: true, result: r }), true; }
        catch (e) { return ctx.json(res, 500, { error: 'Copy failed: ' + e.message }), true; }
      }
      if (m === 'POST' && p === '/api/safety/clerks') {
        const v = await ctx.body(req), name = String(v.name || '').trim(), un = String(v.username || '').trim(), pw = String(v.password || '');
        if (!name || !un) return ctx.json(res, 400, { error: 'Name and username are required' }), true;
        if (pw.length < 8) return ctx.json(res, 400, { error: 'Password must be at least 8 characters' }), true;
        if (d.users.some(x => String(x.username).toLowerCase() === un.toLowerCase())) return ctx.json(res, 409, { error: 'That username is already taken' }), true;
        const adm = d.users.find(x => x.role === 'admin' && !x.clerk) || {};
        d.users.push({ id: nid(d.users), username: un, password: ctx.hashPassword(pw), role: 'admin', clerk: true, name, email: '', phone: String(v.phone || ''), dise_code: adm.dise_code || '', must_change_password: true });
        ctx.audit(u, 'CREATE_CLERK', un); ctx.save(); return ctx.json(res, 200, { ok: true }), true;
      }
      if (m === 'DELETE' && /^\/api\/safety\/clerks\/\d+$/.test(p)) {
        const id = num(p.split('/').pop()), c = d.users.find(x => x.id === id && x.clerk); if (!c) return ctx.json(res, 404, { error: 'Clerk not found' }), true;
        d.users = d.users.filter(x => x.id !== id); ctx.audit(u, 'DELETE_CLERK', c.username); ctx.save(); return ctx.json(res, 200, { ok: true }), true;
      }
      return ctx.json(res, 404, { error: 'Not found' }), true;
    }

    /* ---- payment proofs ---- */
    if (p === '/api/payment-proofs' || p.startsWith('/api/payment-proofs/')) {
      const u = await ctx.auth(req, res, []); if (!u) return true; const d = D();
      const sd = new Map(ctx.studentsDetailed().map(s => [Number(s.id), s]));
      const view = x => { const s = sd.get(Number(x.student_id)) || {}; return { ...x, image: undefined, has_image: !!x.image, student: s.name || '(deleted)', code: s.student_id || '', cls: [s.class_name, s.section_name].filter(Boolean).join('-') }; };
      if (m === 'GET' && p === '/api/payment-proofs') {
        let list = d.payment_proofs; if (u.role === 'guardian') list = list.filter(x => Number(x.guardian_id) === Number(u.id)); else if (u.role !== 'admin') return forbid(res), true;
        return ctx.json(res, 200, list.slice().reverse().map(view)), true;
      }
      if (m === 'POST' && p === '/api/payment-proofs') {
        if (u.role !== 'guardian') return forbid(res, 'Only guardians can upload payment proofs'), true;
        const v = await ctx.body(req), st = ctx.studentForUser(u, num(v.student_id)), amt = ctx.round2(v.amount), img = String(v.image || '');
        if (!st) return forbid(res), true; if (!(amt > 0) || amt > 1000000) return ctx.json(res, 400, { error: 'Enter the amount you paid' }), true;
        if (!/^data:image\/(jpeg|png|webp);base64,/.test(img) || img.length > 2500000) return ctx.json(res, 400, { error: 'Attach a screenshot image (JPG/PNG, under ~1.8 MB)' }), true;
        const ref = String(v.ref || '').trim().slice(0, 40);
        if (ref && d.payment_proofs.some(x => x.status !== 'Rejected' && String(x.ref).toLowerCase() === ref.toLowerCase())) return ctx.json(res, 409, { error: 'This UPI reference has already been submitted.' }), true;
        const item = { id: nid(d.payment_proofs), student_id: st.id, guardian_id: u.id, guardian: u.name, amount: amt, ref, note: String(v.note || '').slice(0, 200), paid_on: dateOk(v.paid_on) ? v.paid_on : today(), image: img, status: 'Pending', created_at: new Date().toISOString() };
        d.payment_proofs.push(item); ctx.audit(u, 'PROOF_UPLOADED', `₹${amt} for ${st.name}`); ctx.save(); return ctx.json(res, 200, { ok: true, proof: view(item) }), true;
      }
      const im = p.match(/^\/api\/payment-proofs\/(\d+)\/image$/);
      if (m === 'GET' && im) {
        const x = d.payment_proofs.find(q => q.id === num(im[1])); if (!x || !x.image) return ctx.json(res, 404, { error: 'Not found' }), true;
        if (u.role !== 'admin' && !(u.role === 'guardian' && Number(x.guardian_id) === Number(u.id))) return forbid(res), true;
        const mm = x.image.match(/^data:(image\/[a-z]+);base64,(.*)$/s); return ctx.send(res, 200, Buffer.from(mm[2], 'base64'), { 'Content-Type': mm[1], 'Cache-Control': 'private, max-age=300' }), true;
      }
      const ac = p.match(/^\/api\/payment-proofs\/(\d+)\/(approve|reject)$/);
      if (m === 'POST' && ac) {
        if (u.role !== 'admin') return forbid(res), true;
        const x = d.payment_proofs.find(q => q.id === num(ac[1])); if (!x) return ctx.json(res, 404, { error: 'Proof not found' }), true;
        if (x.status !== 'Pending') return ctx.json(res, 400, { error: 'Already ' + x.status.toLowerCase() }), true;
        const v = await ctx.body(req);
        if (ac[2] === 'reject') { x.status = 'Rejected'; x.reason = String(v.reason || '').slice(0, 150); x.decided_by = u.name; x.decided_at = new Date().toISOString(); ctx.audit(u, 'PROOF_REJECTED', `#${x.id} ${x.reason}`); ctx.save(); return ctx.json(res, 200, { ok: true }), true; }
        const amt = v.amount !== undefined && v.amount !== '' ? ctx.round2(v.amount) : x.amount;
        const r = applyPayment(x.student_id, amt, { mode: 'UPI', instrument: x.ref, date: x.paid_on || today(), user: u, remark: 'UPI proof #' + x.id, note: 'Approved UPI payment proof #' + x.id });
        if (r.error) return ctx.json(res, 400, { error: r.error }), true;
        x.status = 'Approved'; x.approved_amount = r.received; x.receipt_no = r.receipt; x.decided_by = u.name; x.decided_at = new Date().toISOString();
        ctx.audit(u, 'PROOF_APPROVED', `#${x.id} ₹${r.received} receipt ${r.receipt}`); ctx.save(); return ctx.json(res, 200, { ok: true, receipt: r.receipt, received: r.received, excess: r.excess }), true;
      }
      return ctx.json(res, 404, { error: 'Not found' }), true;
    }

    /* ---- attendance alerts ---- */
    if (m === 'GET' && p === '/api/attendance-alerts') {
      const u = await ctx.auth(req, res); if (!u) return true;
      return ctx.json(res, 200, attendanceAlerts(u)), true;
    }
    if (m === 'POST' && p === '/api/attendance-alerts/sent') {
      const u = await ctx.auth(req, res, ['admin', 'teacher']); if (!u) return true;
      const v = await ctx.body(req), key = String(v.key || ''), d = D();
      if (!attendanceAlerts(u).some(a => a.key === key)) return forbid(res), true;
      if (!d.alert_sent.some(x => x.key === key)) d.alert_sent.push({ key, at: new Date().toISOString(), by: u.name });
      ctx.save(); return ctx.json(res, 200, { ok: true }), true;
    }
    return false;
  }

  return { handle, offsite, nextReceipt };
};

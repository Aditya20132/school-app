@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo SchoolHub V5000 - EXE Builder
echo No Visual Studio / Python / C++ required
echo ============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js LTS first.
  pause
  exit /b 1
)
node -v
if exist SchoolHub-V5000.exe del /f /q SchoolHub-V5000.exe
if exist sea-prep.blob del /f /q sea-prep.blob

echo.
echo Creating single-executable blob...
node --experimental-sea-config sea-config.json
if errorlevel 1 goto fail

echo.
echo Copying Node runtime...
node -e "require('fs').copyFileSync(process.execPath,'SchoolHub-V5000.exe')"
if errorlevel 1 goto fail

echo.
echo Injecting application into EXE...
npx --yes postject SchoolHub-V5000.exe NODE_SEA_BLOB sea-prep.blob --sentinel-fuse NODE_SEA_FUSE_fce680ab2cc467b6e072b8b5df1996b2
if errorlevel 1 goto fail

del /f /q sea-prep.blob >nul 2>nul

echo.
echo ============================================
echo SUCCESS!
echo SchoolHub-V5000.exe has been created.
echo Double-click the EXE to start SchoolHub.
echo Your editable database is stored in the data folder.
echo ============================================
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. See the error above.
pause
exit /b 1

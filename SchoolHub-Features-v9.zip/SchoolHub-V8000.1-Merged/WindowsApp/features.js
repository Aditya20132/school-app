/* SchoolHub feature pack (client). Loaded after app.js and premium.js. */
(function () {
  'use strict';
  const money = n => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const el = id => document.getElementById(id);
  const fmtDT = s => { try { return new Date(s).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) } catch { return s || '' } };
  const waPhone = p => { let ph = String(p || '').replace(/\D/g, ''); if (ph.length === 10) ph = '91' + ph; return ph.length >= 11 ? ph : '' };
  const wa = (ph, msg) => 'https://wa.me/' + ph + '?text=' + encodeURIComponent(msg);

  /* ================= navigation ================= */
  const FNAV = {
    admin: [['Finance', 'Day Book'], ['Finance', 'Payment Log'], ['Finance', 'Payment Proofs'], ['Finance', 'Student Ledger'], ['Communication', 'Attendance Alerts'], ['System', 'Safety & Roles']],
    teacher: [['Teaching', 'Attendance Alerts']],
    guardian: [['My Family', 'Pay by UPI'], ['My Family', 'Student Ledger']]
  };
  Object.assign(V8000_ICONS, { 'Day Book': '▤', 'Payment Log': '↺', 'Payment Proofs': '✔', 'Student Ledger': '≣', 'Attendance Alerts': '🔔', 'Safety & Roles': '🛡', 'Pay by UPI': '₹' });
  for (const role of Object.keys(FNAV)) {
    const list = V8000_NAV[role]; if (!list) continue;
    for (const [g, n] of FNAV[role]) {
      if (list.some(x => x[1] === n)) continue;
      let idx = -1; list.forEach((x, i) => { if (x[0] === g) idx = i });
      if (idx < 0) list.push([g, n]); else list.splice(idx + 1, 0, [g, n]);
    }
  }
  window.F_CLERK = false;
  const CLERK_HIDE = ['Academic Setup', 'Academic Years', 'Settings', 'Safety & Roles', 'Audit Log', 'Teachers'];
  const _renderNav = renderNav;
  renderNav = function () {
    _renderNav.apply(this, arguments);
    if (me && me.role === 'admin') {
      api('/api/features/context').then(c => {
        window.F_CLERK = !!c.clerk; if (!c.clerk) return;
        document.querySelectorAll('#nav button').forEach(b => { if (CLERK_HIDE.includes(b.dataset.page)) b.remove() });
        const r = el('userRole'); if (r) r.textContent = 'Clerk (fee collection)';
        startClerkObserver();
      }).catch(() => { });
    }
  };
  function startClerkObserver() {
    const hide = () => {
      document.querySelectorAll('#content button, #content a').forEach(b => {
        const t = (b.textContent || '').trim();
        if (/^(Delete|Remove)\b/i.test(t) || t === 'Class Fee Settings' || t === 'Concessions' || /^Generate monthly fees/i.test(t)) b.style.display = 'none';
      });
    };
    new MutationObserver(hide).observe(el('content'), { childList: true, subtree: true }); hide();
  }

  /* ================= page registry ================= */
  const PAGES = {};
  const _show = show;
  show = async function (p) {
    if (PAGES[p]) { setActive(p); try { return await PAGES[p]() } catch (e) { toast(e.message) } return; }
    return _show.apply(this, arguments);
  };

  /* ================= WhatsApp queue (opens one chat per click) ================= */
  window.fxQueue = function (items, title, skipped) {
    document.getElementById('fxQ')?.remove();
    if (!items.length) return toast('Nobody to message' + (skipped ? ` (${skipped} without a valid number)` : ''));
    let i = 0;
    const box = document.createElement('div'); box.id = 'fxQ'; box.className = 'fx-modal';
    document.body.append(box);
    const draw = () => {
      if (i >= items.length) { box.innerHTML = `<div class="fx-box"><h3>All done ✔</h3><p class="muted">${items.length} WhatsApp chat(s) opened. Press Send in each chat.</p><button class="primary" id="fxqx">Close</button></div>`; el('fxqx').onclick = () => box.remove(); return; }
      const it = items[i];
      box.innerHTML = `<div class="fx-box"><h3>${esc(title)}</h3><p class="muted">${i + 1} of ${items.length}${skipped ? ` • ${skipped} skipped (no valid number)` : ''}</p><div class="fx-prog"><i style="width:${Math.round(i / items.length * 100)}%"></i></div><p><b>${esc(it.label)}</b><br><small class="muted">+${esc(it.phone)}</small></p><div class="fx-msg">${esc(it.msg)}</div><div class="fx-row"><button class="primary" id="fxqo">Open WhatsApp ▶</button><button class="smallbtn" id="fxqs">Skip</button><button class="smallbtn" id="fxqc">Stop</button></div><p class="muted" style="font-size:12px">Each click opens one prefilled chat — press Send there, come back and click again. (Browsers only allow one new window per click.)</p></div>`;
      el('fxqo').onclick = () => { window.open(wa(it.phone, it.msg), '_blank'); if (it.after) it.after(); i++; draw() };
      el('fxqs').onclick = () => { i++; draw() };
      el('fxqc').onclick = () => box.remove();
    };
    draw();
  };

  /* overdue defaulters -> queue */
  window.defWaAll = function () {
    const rows = defaultersFiltered().filter(r => r.over > 0);
    if (!rows.length) return toast('No overdue students in the current filter');
    const items = []; let skipped = 0;
    for (const r of rows) {
      const ph = waPhone(r.phone); if (!ph) { skipped++; continue }
      items.push({ phone: ph, label: `${r.name} (${r.cls}${r.sec ? '-' + r.sec : ''}) — ${money(r.due)}`, msg: `Dear ${r.guardian || 'Parent / Guardian'}, this is a reminder from Holyfaith Academy. Fees of ₹${Number(r.due).toLocaleString('en-IN')} are pending for ${r.name} (Class ${r.cls}${r.sec ? '-' + r.sec : ''})${r.months ? `, ${r.months} month${r.months > 1 ? 's' : ''} pending` : ''}${r.over ? `, of which ₹${Number(r.over).toLocaleString('en-IN')} is overdue` : ''}. Kindly pay at the school office at the earliest. Thank you.` });
    }
    fxQueue(items, 'Fee reminders — overdue', skipped);
  };
  window.openLedger = id => window.open('/api/student-ledger/' + id, '_blank');

  /* ================= Day Book ================= */
  PAGES['Day Book'] = async function () {
    const t = today();
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Day Book &amp; Daily Collection</h3><p class="muted">Every receipt by date — school fees and transport. Use the printable report to close the day against the cash drawer.</p></div></div>
<div class="toolbar"><label>From <input type="date" id="fdFrom" value="${t}"></label><label>To <input type="date" id="fdTo" value="${t}"></label><select id="fdMode"><option value="">All modes</option><option>Cash</option><option>UPI</option><option>Cheque</option><option>Bank</option><option>Other</option></select><button class="primary" id="fdGo">Load</button><button class="smallbtn" id="fdPrint">🖨 Print daily report</button><button class="smallbtn" id="fdCsv">Export CSV</button></div></div>
<div class="cards" id="fdCards"></div><div class="panel"><div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Receipt no.</th><th>Student</th><th>For</th><th>Mode</th><th>Ref</th><th>By</th><th style="text-align:right">Amount</th></tr></thead><tbody id="fdRows"></tbody></table></div></div>`;
    const load = async () => { const d = await api(`/api/day-book?from=${el('fdFrom').value}&to=${el('fdTo').value}`); window.__fxdb = d; draw() };
    const draw = () => {
      const d = window.__fxdb; if (!d) return; const m = el('fdMode').value, rows = d.rows.filter(r => !m || r.mode === m);
      const by = {}; ['Cash', 'UPI', 'Cheque', 'Bank', 'Other'].forEach(k => by[k] = 0); rows.forEach(r => by[r.mode] += r.amount);
      el('fdCards').innerHTML = Object.entries(by).map(([k, v]) => `<div class="card"><div class="label">${k.toUpperCase()}</div><div class="metric">${money(v)}</div></div>`).join('') + `<div class="card"><div class="label">TOTAL</div><div class="metric green">${money(rows.reduce((n, r) => n + r.amount, 0))}</div></div>`;
      el('fdRows').innerHTML = rows.map(r => `<tr><td>${esc(r.date)}</td><td>${esc(r.receipt_no)}</td><td><b>${esc(r.student)}</b><br><small>${esc(r.code)} • ${esc(r.cls)}</small></td><td>${esc(r.what)}${r.type === 'REVERSAL' || r.type === 'UNDO' ? ' <small style="color:#dc2626">(' + (r.type === 'UNDO' ? 'undo' : 'edited/cleared') + ')</small>' : ''}</td><td>${esc(r.mode)}</td><td>${esc(r.instrument)}</td><td>${esc(r.by)}</td><td style="text-align:right;${r.amount < 0 ? 'color:#dc2626' : ''}"><b>${money(r.amount)}</b></td></tr>`).join('') || '<tr><td colspan="8" class="muted" style="padding:18px">No receipts in this range.</td></tr>';
    };
    el('fdGo').onclick = () => load().catch(e => toast(e.message)); el('fdMode').onchange = draw;
    el('fdPrint').onclick = () => window.open('/api/reports/daily-collection?date=' + el('fdFrom').value, '_blank');
    el('fdCsv').onclick = () => { const d = window.__fxdb; if (!d) return; v7202DownloadCSV(d.rows.filter(r => !el('fdMode').value || r.mode === el('fdMode').value).map(r => ({ Date: r.date, 'Receipt no': r.receipt_no, Student: r.student, 'Student ID': r.code, Class: r.cls, For: r.what, Mode: r.mode, Reference: r.instrument, 'Received by': r.by, Amount: r.amount })), `day-book-${d.from}_${d.to}.csv`) };
    await load();
  };

  /* ================= Payment log + undo ================= */
  PAGES['Payment Log'] = async function () {
    const rows = await api('/api/payment-log?limit=300');
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Payment Edit Log</h3><p class="muted">Who received, changed or cleared a payment, and when. ${window.F_CLERK ? '' : 'Administrators can undo a change while the fee has not been changed again.'}</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Student / Fee</th><th>Paid: before → after</th><th>Receipt</th><th></th></tr></thead><tbody>${rows.map(l => `<tr><td>${fmtDT(l.ts)}</td><td>${esc(l.user)}</td><td><b>${esc(l.type)}</b><br><small class="muted">${esc(l.note)}${l.undone ? ' • undone by ' + esc(l.undone_by) : ''}</small></td><td>${esc(l.student)}<br><small>${esc(l.fee_label)}</small></td><td>${money(l.before && l.before.paid)} → <b>${money(l.after && l.after.paid)}</b>${l.before && l.after && l.before.amount !== l.after.amount ? `<br><small>fee ${money(l.before.amount)} → ${money(l.after.amount)}</small>` : ''}</td><td>${esc((l.after && l.after.receipt_no) || (l.before && l.before.receipt_no) || '')}</td><td>${!window.F_CLERK && !l.undone && l.type !== 'UNDO' ? `<button class="smallbtn" data-undo="${l.id}">Undo</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="7" class="muted" style="padding:18px">No payment changes recorded yet. New payments and edits will appear here.</td></tr>'}</tbody></table></div></div>`;
    $('#content').onclick = async e => { const b = e.target.closest('[data-undo]'); if (!b) return; if (!confirm('Undo this change and restore the previous payment values?')) return; try { await api(`/api/payment-log/${b.dataset.undo}/undo`, { method: 'POST', body: '{}' }); clear('fees'); toast('Change undone'); PAGES['Payment Log']() } catch (er) { toast(er.message) } };
  };

  /* ================= Student ledger picker ================= */
  PAGES['Student Ledger'] = async function () {
    clear('students'); const s = await data('students');
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Student Fee Ledger</h3><p class="muted">Every fee, concession, fine, transport charge and payment in date order — printable to settle a disputed balance.</p></div></div><div class="toolbar"><input id="slq" placeholder="Search student name or ID..." style="min-width:260px"></div><div class="table-wrap"><table class="table"><tbody id="slRows"></tbody></table></div></div>`;
    const draw = () => { const q = el('slq').value.toLowerCase(); el('slRows').innerHTML = s.filter(x => !q || (x.name + ' ' + x.student_id).toLowerCase().includes(q)).slice(0, 200).map(x => `<tr><td><b>${esc(x.name)}</b><br><small>${esc(x.student_id)} • ${esc(x.class_name)}${x.section_name ? '-' + esc(x.section_name) : ''}</small></td><td style="text-align:right"><button class="smallbtn" onclick="openLedger(${x.id})">Open ledger</button></td></tr>`).join('') || '<tr><td class="muted" style="padding:16px">No student found.</td></tr>' };
    el('slq').oninput = draw; draw();
  };

  /* ================= Payment proofs ================= */
  function compress(file, max = 1280, q = .72) {
    return new Promise((res, rej) => {
      const r = new FileReader(); r.onerror = () => rej(Error('Could not read the image'));
      r.onload = () => { const im = new Image(); im.onerror = () => rej(Error('This file is not an image')); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', q)) }; im.src = r.result };
      r.readAsDataURL(file);
    });
  }
  const statusChip = s => `<span style="padding:2px 8px;border-radius:99px;font-size:12px;font-weight:700;background:${s === 'Approved' ? '#dcfce7;color:#166534' : s === 'Rejected' ? '#fee2e2;color:#991b1b' : '#fef3c7;color:#92400e'}">${esc(s)}</span>`;

  PAGES['Pay by UPI'] = async function () {
    clear('students', 'fees'); const [kids, fees, proofs] = await Promise.all([data('students'), data('fees'), api('/api/payment-proofs')]);
    const due = id => fees.filter(f => Number(f.student_id) === Number(id) && !f.cancelled).reduce((n, f) => n + Number(f.balance || 0), 0);
    $('#content').innerHTML = `<div class="panel form-panel"><div class="panel-head"><div><h3>Pay by UPI — upload proof</h3><p class="muted">Pay using the school's UPI ID / QR (ask the office if you do not have it), then upload the payment screenshot here. The office will check it and your receipt will appear below.</p></div></div>
<div class="grid2"><label>Child<select id="pfKid">${kids.map(k => `<option value="${k.id}">${esc(k.name)} — due ${money(due(k.id))}</option>`).join('')}</select></label><label>Amount paid (₹)<input id="pfAmt" type="number" min="1" step="0.01"></label><label>UPI reference / UTR no.<input id="pfRef" maxlength="40" placeholder="e.g. 4123 4567 8901"></label><label>Date of payment<input id="pfDate" type="date" value="${today()}"></label><label style="grid-column:1/-1">Note (optional)<input id="pfNote" maxlength="200"></label><label style="grid-column:1/-1">Screenshot<input id="pfFile" type="file" accept="image/*"></label></div><div class="toolbar"><button class="primary" id="pfGo">Submit for approval</button></div></div>
<div class="panel"><div class="panel-head"><h3>My submissions</h3></div><div class="table-wrap"><table class="table"><thead><tr><th>Submitted</th><th>Child</th><th>Amount</th><th>Ref</th><th>Status</th><th></th></tr></thead><tbody>${proofs.map(p => `<tr><td>${fmtDT(p.created_at)}</td><td>${esc(p.student)}</td><td>${money(p.amount)}</td><td>${esc(p.ref)}</td><td>${statusChip(p.status)}${p.reason ? `<br><small class="muted">${esc(p.reason)}</small>` : ''}</td><td>${p.status === 'Approved' && p.receipt_no ? `<button class="smallbtn" onclick="printGroupReceipt('${esc(p.receipt_no)}')">Receipt ${esc(p.receipt_no)}</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="6" class="muted" style="padding:16px">Nothing submitted yet.</td></tr>'}</tbody></table></div></div>`;
    const fill = () => { const d = due(el('pfKid').value); if (d > 0) el('pfAmt').value = d }; el('pfKid').onchange = fill; fill();
    el('pfGo').onclick = async () => {
      try {
        const f = el('pfFile').files[0]; if (!f) return toast('Attach the payment screenshot'); const btn = el('pfGo'); btn.disabled = true;
        const image = await compress(f);
        await api('/api/payment-proofs', { method: 'POST', body: JSON.stringify({ student_id: el('pfKid').value, amount: el('pfAmt').value, ref: el('pfRef').value, paid_on: el('pfDate').value, note: el('pfNote').value, image }) });
        toast('Submitted — the office will approve it shortly'); PAGES['Pay by UPI']();
      } catch (e) { toast(e.message); el('pfGo').disabled = false }
    };
  };
  PAGES['Payment Proofs'] = async function () {
    const rows = await api('/api/payment-proofs'), pend = rows.filter(r => r.status === 'Pending');
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Payment Proofs (${pend.length} pending)</h3><p class="muted">Guardians upload UPI screenshots. Approving applies the money to the oldest dues and issues a numbered receipt. Check the amount against your bank / UPI app before approving.</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Submitted</th><th>Student</th><th>Guardian</th><th>Amount</th><th>UPI ref</th><th>Proof</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(r => `<tr><td>${fmtDT(r.created_at)}<br><small class="muted">paid ${esc(r.paid_on)}</small></td><td><b>${esc(r.student)}</b><br><small>${esc(r.code)} • ${esc(r.cls)}</small></td><td>${esc(r.guardian)}${r.note ? `<br><small class="muted">${esc(r.note)}</small>` : ''}</td><td><b>${money(r.amount)}</b></td><td>${esc(r.ref)}</td><td><a href="/api/payment-proofs/${r.id}/image" target="_blank">View screenshot</a></td><td>${statusChip(r.status)}${r.status === 'Approved' ? `<br><small>${esc(r.receipt_no)}</small>` : ''}${r.reason ? `<br><small class="muted">${esc(r.reason)}</small>` : ''}</td><td>${r.status === 'Pending' ? `<button class="primary" data-ok="${r.id}" data-amt="${r.amount}">Approve</button> <button class="smallbtn" data-no="${r.id}">Reject</button>` : r.status === 'Approved' && r.receipt_no ? `<button class="smallbtn" onclick="printGroupReceipt('${esc(r.receipt_no)}')">Receipt</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="8" class="muted" style="padding:18px">No proofs submitted yet.</td></tr>'}</tbody></table></div></div>`;
    $('#content').onclick = async e => {
      const ok = e.target.closest('[data-ok]'), no = e.target.closest('[data-no]');
      try {
        if (ok) { const a = prompt('Amount to credit (₹):', ok.dataset.amt); if (a === null) return; const r = await api(`/api/payment-proofs/${ok.dataset.ok}/approve`, { method: 'POST', body: JSON.stringify({ amount: a }) }); clear('fees'); toast(`Approved ${money(r.received)} — receipt ${r.receipt}${r.excess > 0 ? ` (₹${r.excess} exceeded the dues and was not applied)` : ''}`); PAGES['Payment Proofs']() }
        if (no) { const reason = prompt('Reason for rejecting (shown to the guardian):', 'Payment not received in our account'); if (reason === null) return; await api(`/api/payment-proofs/${no.dataset.no}/reject`, { method: 'POST', body: JSON.stringify({ reason }) }); PAGES['Payment Proofs']() }
      } catch (er) { toast(er.message) }
    };
  };

  /* ================= Attendance alerts ================= */
  const alertMsg = a => `Dear ${a.guardian || 'Parent / Guardian'}, this is Holyfaith Academy. ${a.name} (Class ${a.cls}${a.sec ? '-' + a.sec : ''}) has been absent for ${a.days} school days in a row (since ${a.since}). Please let us know the reason, or contact the class teacher. Thank you.`;
  PAGES['Attendance Alerts'] = async function () {
    const rows = await api('/api/attendance-alerts'); window.__fxal = rows; const pend = rows.filter(r => !r.sent);
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Attendance Alerts</h3><p class="muted">Students absent on 2 or more school days in a row (latest absence within the last week). Message the guardian on WhatsApp; the alert is marked as sent.</p></div><div class="panel-actions"><button class="primary" id="alAll">WhatsApp all pending (${pend.length})</button></div></div><div class="table-wrap"><table class="table"><thead><tr><th>Student</th><th>Guardian</th><th>Absent</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(a => `<tr><td><b>${esc(a.name)}</b><br><small>${esc(a.code)} • ${esc(a.cls)}${a.sec ? '-' + esc(a.sec) : ''}</small></td><td>${esc(a.guardian || '—')}<br><small class="muted">${esc(a.phone || 'No number')}</small></td><td><b>${a.days} days</b><br><small class="muted">${esc(a.since)} → ${esc(a.last)}</small></td><td>${a.sent ? `✔ sent ${fmtDT(a.sent.at)}<br><small class="muted">${esc(a.sent.by)}</small>` : '<span style="color:#dc2626">Not sent</span>'}</td><td><button class="smallbtn" data-wa="${esc(a.key)}">WhatsApp</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted" style="padding:18px">No student has been absent two days in a row. 🎉</td></tr>'}</tbody></table></div></div>`;
    const mark = key => api('/api/attendance-alerts/sent', { method: 'POST', body: JSON.stringify({ key }) }).catch(() => { });
    $('#content').onclick = e => { const b = e.target.closest('[data-wa]'); if (!b) return; const a = rows.find(x => x.key === b.dataset.wa), ph = waPhone(a.phone); if (!ph) return toast('No WhatsApp number saved for this guardian'); window.open(wa(ph, alertMsg(a)), '_blank'); mark(a.key).then(() => setTimeout(PAGES['Attendance Alerts'], 600)) };
    el('alAll').onclick = () => { const items = [], sk = []; pend.forEach(a => { const ph = waPhone(a.phone); if (!ph) sk.push(a); else items.push({ phone: ph, label: `${a.name} — absent ${a.days} days`, msg: alertMsg(a), after: () => mark(a.key) }) }); fxQueue(items, 'Attendance alerts', sk.length) };
  };
  /* guardian dashboard banner */
  const _dash = dashboard;
  dashboard = async function () {
    await _dash.apply(this, arguments);
    if (!me || me.role !== 'guardian') return;
    try { const a = await api('/api/attendance-alerts'); if (a.length) $('#content').insertAdjacentHTML('afterbegin', `<div class="panel" style="border-left:4px solid #dc2626"><div class="panel-head"><div><h3>Attendance alert</h3><p class="muted">${a.map(x => `${esc(x.name)} has been absent for ${x.days} school days in a row (since ${esc(x.since)}).`).join('<br>')}</p></div></div></div>`) } catch { }
  };

  /* ================= Safety & roles ================= */
  PAGES['Safety & Roles'] = async function () {
    const s = await api('/api/safety/settings'), yr = Object.keys(s.counters).pop();
    const lo = s.last_offsite;
    $('#content').innerHTML = `<div class="panel form-panel"><div class="panel-head"><div><h3>Receipt numbering</h3><p class="muted">New receipts are numbered <b>${esc(s.receipt_prefix)}/${esc(yr || '2026-27')}/0001</b>, <b>0002</b>… and restart each academic session. Older receipts keep their numbers.</p></div></div><div class="toolbar"><label>Prefix <input id="sfPre" value="${esc(s.receipt_prefix)}" maxlength="10" style="width:110px"></label>${Object.entries(s.counters).map(([k, v]) => `<span class="muted">${esc(k)}: ${v} issued</span>`).join(' • ')}</div></div>
<div class="panel form-panel"><div class="panel-head"><div><h3>Backup copy in a second place</h3><p class="muted">Every automatic backup (startup and daily) is also copied to this folder, keeping the latest 30. Point it at a <b>Google Drive for desktop</b>, OneDrive or Dropbox folder, a network share or a USB drive so a dead PC does not lose the fee records.${s.storage_driver !== 'local' && s.storage_driver !== 'db' ? ` Cloudflare R2 is also active (${esc(s.storage_driver)}).` : ''}</p></div></div><div class="toolbar"><input id="sfDir" value="${esc(s.offsite_dir)}" placeholder="e.g. G:\\My Drive\\SchoolHub-Backups" style="min-width:340px"><button class="primary" id="sfSave">Save</button><button class="smallbtn" id="sfNow">Copy a backup there now</button></div>${lo ? `<p class="${lo.ok ? 'muted' : ''}" style="${lo.ok ? '' : 'color:#dc2626'}">Last copy: ${fmtDT(lo.at)} — ${lo.ok ? '✔ ' + esc(lo.name) : '✖ ' + esc(lo.error)}</p>` : '<p class="muted">No off-site copy made yet.</p>'}</div>
<div class="panel form-panel"><div class="panel-head"><div><h3>Clerk accounts</h3><p class="muted">A clerk signs in on the <b>Administrator</b> tab but can only collect fees and add/edit students. Clerks cannot delete students, change class fees, concessions or fee rules, cancel fees, edit a fee amount, restore backups, undo payments or manage users.</p></div></div>
<div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Username</th><th></th></tr></thead><tbody>${s.clerks.map(c => `<tr><td>${esc(c.name)}</td><td>${esc(c.username)}</td><td><button class="smallbtn" data-delclerk="${c.id}">Remove</button></td></tr>`).join('') || '<tr><td colspan="3" class="muted">No clerk accounts yet.</td></tr>'}</tbody></table></div>
<div class="toolbar"><input id="ckName" placeholder="Clerk name"><input id="ckUser" placeholder="Username"><input id="ckPass" type="text" placeholder="Temporary password (8+ chars)"><button class="primary" id="ckAdd">Add clerk</button></div><p class="muted">The clerk must change the temporary password at first sign-in.</p></div>`;
    el('sfSave').onclick = async () => { try { await api('/api/safety/settings', { method: 'PUT', body: JSON.stringify({ receipt_prefix: el('sfPre').value, offsite_dir: el('sfDir').value }) }); toast('Saved'); PAGES['Safety & Roles']() } catch (e) { toast(e.message) } };
    el('sfNow').onclick = async () => { try { await api('/api/safety/settings', { method: 'PUT', body: JSON.stringify({ receipt_prefix: el('sfPre').value, offsite_dir: el('sfDir').value }) }); await api('/api/safety/offsite-now', { method: 'POST', body: '{}' }); toast('Backup copied'); PAGES['Safety & Roles']() } catch (e) { toast(e.message); PAGES['Safety & Roles']() } };
    el('ckAdd').onclick = async () => { try { await api('/api/safety/clerks', { method: 'POST', body: JSON.stringify({ name: el('ckName').value, username: el('ckUser').value, password: el('ckPass').value }) }); toast('Clerk added'); clear('users'); PAGES['Safety & Roles']() } catch (e) { toast(e.message) } };
    $('#content').onclick = async e => { const b = e.target.closest('[data-delclerk]'); if (!b || !confirm('Remove this clerk account?')) return; try { await api('/api/safety/clerks/' + b.dataset.delclerk, { method: 'DELETE' }); clear('users'); PAGES['Safety & Roles']() } catch (er) { toast(er.message) } };
  };

  /* ================= printing is always light ================= */
  let saved = null;
  const toLight = () => { const r = document.documentElement; if (saved) return; saved = [r.dataset.theme, r.dataset.mode]; r.dataset.theme = 'light'; r.dataset.mode = 'light'; };
  const fromLight = () => { if (!saved) return; const r = document.documentElement; r.dataset.theme = saved[0]; r.dataset.mode = saved[1]; saved = null; };
  window.addEventListener('beforeprint', toLight); window.addEventListener('afterprint', fromLight);
  try { matchMedia('print').addEventListener('change', e => e.matches ? toLight() : fromLight()) } catch { }
})();

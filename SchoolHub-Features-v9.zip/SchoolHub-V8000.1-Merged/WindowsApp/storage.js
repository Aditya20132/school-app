const fs = require('node:fs');
const path = require('node:path');
const { PassThrough, Readable } = require('node:stream');

// STORAGE_DRIVER:
//   hybrid (recommended) : files <= R2_MIN_BYTES go into PostgreSQL, bigger files go to Cloudflare R2.
//                          Attachments and backups always pass target:'r2' and go to R2 whatever their size.
//   s3                   : everything goes to Cloudflare R2 (any S3-compatible bucket).
//   db                   : everything goes into PostgreSQL.
//   local                : everything goes to a local folder (preview / testing only).
const hasR2Config = Boolean(process.env.S3_BUCKET && process.env.S3_ENDPOINT && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY);
const defaultDriver = process.env.PREVIEW_MODE === 'true' ? 'local' : (hasR2Config ? 'hybrid' : 'db');
const driver = String(process.env.STORAGE_DRIVER || defaultDriver).toLowerCase();
const useS3 = driver === 's3' || driver === 'hybrid';
const bucket = process.env.S3_BUCKET || '';
const endpoint = process.env.S3_ENDPOINT || '';
const localRoot = process.env.LOCAL_STORAGE_DIR || path.join(__dirname, 'data', 'objects');
const R2_MIN_BYTES = Number(process.env.R2_MIN_BYTES ?? 512000); // 500 KB. Set 0 to send every file to R2.

if (!['hybrid', 's3', 'db', 'local'].includes(driver)) throw new Error('STORAGE_DRIVER must be hybrid, s3, db or local.');
if (useS3 && (!bucket || !endpoint || !process.env.S3_ACCESS_KEY_ID || !process.env.S3_SECRET_ACCESS_KEY)) {
  throw new Error('Cloudflare R2 is required. Set S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY (or use STORAGE_DRIVER=local for testing).');
}

let client = null, Upload = null, S3 = null;
if (useS3) {
  S3 = require('@aws-sdk/client-s3');
  ({ Upload } = require('@aws-sdk/lib-storage'));
  client = new S3.S3Client({
    region: process.env.S3_REGION || 'auto',
    endpoint,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
    requestChecksumCalculation: 'WHEN_REQUIRED',
    responseChecksumValidation: 'WHEN_REQUIRED',
    credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY }
  });
}

function safeKey(key) {
  return String(key || '').replace(/^\/+/, '').replace(/\.\.(?:\/|\\)/g, '').slice(0, 1024);
}
function ensureLocal(key) {
  const full = path.join(localRoot, safeKey(key));
  fs.mkdirSync(path.dirname(full), { recursive: true });
  return full;
}
const notFound = () => { const e = new Error('File not found'); e.name = 'NoSuchKey'; e.code = 'ENOENT'; return e; };

// ---- PostgreSQL object table (small files) ----
const DB_MAX_BYTES = Number(process.env.DB_STORAGE_MAX_BYTES || 20 * 1024 * 1024);
let dbPool = null, dbReady = null;
function filePool() {
  if (!dbPool) {
    const { Pool } = require('pg');
    if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required for database file storage.');
    dbPool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false }, max: 3 });
  }
  return dbPool;
}
function ensureFileTable() {
  if (!dbReady) {
    dbReady = filePool().query(`CREATE TABLE IF NOT EXISTS storage_objects (
      key TEXT PRIMARY KEY, content_type TEXT, size INTEGER NOT NULL, data BYTEA NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`
    ).catch((e) => { dbReady = null; throw e; });
  }
  return dbReady;
}
async function readAll(stream) {
  const chunks = []; let total = 0;
  for await (const c of stream) { total += c.length; if (total > DB_MAX_BYTES) throw new Error('File is too large.'); chunks.push(c); }
  return Buffer.concat(chunks);
}

async function putLocal(key, stream) {
  const file = ensureLocal(key);
  await new Promise((resolve, reject) => {
    const out = fs.createWriteStream(file);
    stream.pipe(out); out.on('finish', resolve); out.on('error', reject); stream.on('error', reject);
  });
  return { key, size: fs.statSync(file).size, where: 'local' };
}
async function putDb(key, stream, contentType) {
  const buf = await readAll(stream);
  await ensureFileTable();
  await filePool().query(
    `INSERT INTO storage_objects (key, content_type, size, data) VALUES ($1,$2,$3,$4)
     ON CONFLICT (key) DO UPDATE SET content_type=EXCLUDED.content_type, size=EXCLUDED.size, data=EXCLUDED.data, created_at=NOW()`,
    [key, contentType, buf.length, buf]);
  return { key, size: buf.length, where: 'db' };
}
async function putR2(key, stream, contentType, contentLength) {
  const upload = new Upload({
    client,
    params: { Bucket: bucket, Key: key, Body: stream, ContentType: contentType, ...(contentLength ? { ContentLength: contentLength } : {}) },
    queueSize: 2, partSize: 5 * 1024 * 1024, leavePartsOnError: false
  });
  await upload.done();
  return { key, size: contentLength || null, where: 'r2' };
}

// target: 'r2' forces Cloudflare R2 (attachments, backups). Otherwise hybrid decides by size.
async function putStream(key, stream, { contentType = 'application/octet-stream', contentLength = undefined, target = 'auto' } = {}) {
  key = safeKey(key);
  if (driver === 'local') return putLocal(key, stream);
  if (driver === 'db') return putDb(key, stream, contentType);
  if (driver === 's3') return putR2(key, stream, contentType, contentLength);
  if (target === 'r2' || !contentLength || contentLength > R2_MIN_BYTES) return putR2(key, stream, contentType, contentLength);
  return putDb(key, stream, contentType);
}
async function putBuffer(key, buffer, opts = {}) {
  const stream = PassThrough();
  const p = putStream(key, stream, { ...opts, contentLength: buffer.length });
  stream.end(buffer);
  return p;
}

async function getDb(key) {
  await ensureFileTable();
  const r = await filePool().query('SELECT content_type, size, data FROM storage_objects WHERE key=$1', [key]);
  if (!r.rowCount) throw notFound();
  const row = r.rows[0];
  return { Body: Readable.from([row.data]), ContentLength: row.size, ContentType: row.content_type || undefined };
}
async function getObject(key) {
  key = safeKey(key);
  if (driver === 'local') {
    const file = ensureLocal(key);
    if (!fs.existsSync(file)) throw notFound();
    return { Body: fs.createReadStream(file), ContentLength: fs.statSync(file).size, ContentType: undefined };
  }
  if (driver === 'db') return getDb(key);
  if (driver === 'hybrid') { try { return await getDb(key); } catch (e) { if (e.name !== 'NoSuchKey') throw e; } }
  return client.send(new S3.GetObjectCommand({ Bucket: bucket, Key: key }));
}
async function readBuffer(key) {
  const obj = await getObject(key);
  const chunks = [];
  for await (const c of obj.Body) chunks.push(c);
  return Buffer.concat(chunks);
}

async function deleteObject(key) {
  key = safeKey(key);
  if (driver === 'local') { try { fs.unlinkSync(ensureLocal(key)); } catch {} return; }
  if (driver === 'db' || driver === 'hybrid') { await ensureFileTable(); await filePool().query('DELETE FROM storage_objects WHERE key=$1', [key]); }
  if (useS3) await client.send(new S3.DeleteObjectCommand({ Bucket: bucket, Key: key }));
}

// List objects that live in R2 (or local folder) under a prefix -> [{key,size,lastModified}]
async function listObjects(prefix) {
  prefix = safeKey(prefix);
  if (driver === 'local') {
    const dir = path.join(localRoot, path.dirname(prefix)); const base = path.basename(prefix);
    if (!fs.existsSync(dir)) return [];
    return fs.readdirSync(dir).filter((n) => n.startsWith(base)).map((n) => {
      const st = fs.statSync(path.join(dir, n));
      return st.isFile() ? { key: path.posix.join(path.dirname(prefix), n), size: st.size, lastModified: st.mtime } : null;
    }).filter(Boolean);
  }
  if (driver === 'db') {
    await ensureFileTable();
    const r = await filePool().query('SELECT key, size, created_at FROM storage_objects WHERE key LIKE $1', [prefix + '%']);
    return r.rows.map((x) => ({ key: x.key, size: Number(x.size), lastModified: x.created_at }));
  }
  const out = []; let token;
  do {
    const r = await client.send(new S3.ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, ContinuationToken: token }));
    for (const o of r.Contents || []) out.push({ key: o.Key, size: Number(o.Size || 0), lastModified: o.LastModified });
    token = r.IsTruncated ? r.NextContinuationToken : undefined;
  } while (token);
  return out;
}

// Hybrid only: copy small files that live in PostgreSQL into R2 under the SAME key (incremental).
// If the database is ever lost, getObject() finds the copy in R2 automatically.
async function mirrorDbObjectsToR2(prefix = 'malancha/') {
  if (driver !== 'hybrid') return { copied: 0, skipped: 0 };
  await ensureFileTable();
  const have = new Set((await listObjects(prefix)).map((o) => o.key));
  const keys = await filePool().query('SELECT key FROM storage_objects WHERE key LIKE $1', [prefix + '%']);
  let copied = 0, skipped = 0;
  for (const { key } of keys.rows) {
    if (have.has(key)) { skipped++; continue; }
    const r = await filePool().query('SELECT content_type, data FROM storage_objects WHERE key=$1', [key]);
    if (!r.rowCount) continue;
    await putR2(key, Readable.from([r.rows[0].data]), r.rows[0].content_type || 'application/octet-stream', r.rows[0].data.length);
    copied++;
  }
  return { copied, skipped };
}

// Hybrid only: files already sitting in PostgreSQL that are bigger than R2_MIN_BYTES are moved to R2.
// The database copy is deleted only after the R2 upload succeeded. Safe to run repeatedly.
async function moveLargeDbObjectsToR2() {
  if (driver !== 'hybrid') return { moved: 0, freed: 0 };
  await ensureFileTable();
  const big = await filePool().query('SELECT key, size FROM storage_objects WHERE size > $1', [R2_MIN_BYTES]);
  let moved = 0, freed = 0;
  for (const { key, size } of big.rows) {
    const r = await filePool().query('SELECT content_type, data FROM storage_objects WHERE key=$1', [key]);
    if (!r.rowCount) continue;
    await putR2(key, Readable.from([r.rows[0].data]), r.rows[0].content_type || 'application/octet-stream', r.rows[0].data.length);
    await filePool().query('DELETE FROM storage_objects WHERE key=$1', [key]);
    moved++; freed += Number(size);
  }
  return { moved, freed };
}

module.exports = { driver, R2_MIN_BYTES, putStream, putBuffer, getObject, readBuffer, deleteObject, listObjects, mirrorDbObjectsToR2, moveLargeDbObjectsToR2, safeKey };

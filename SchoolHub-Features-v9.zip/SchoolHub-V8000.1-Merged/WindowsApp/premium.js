/* Holyfaith SchoolHub — premium icon layer.
   Replaces emoji / unicode-glyph icons with one consistent set of line icons.
   Purely visual: it never touches data, handlers or layout logic. */
(function(){
'use strict';

/* ---------- icon set (24px grid, stroke icons) ---------- */
var P={
home:'<path d="M3.5 10.5 12 3.5l8.5 7V20a1 1 0 0 1-1 1H15v-6H9v6H4.5a1 1 0 0 1-1-1z"/>',
users:'<circle cx="9" cy="8.5" r="3.3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 5.4a3.3 3.3 0 0 1 0 6.2M18.2 14.5c1.7.9 2.8 2.7 2.8 5.5"/>',
user:'<circle cx="12" cy="8" r="3.6"/><path d="M5 20.5c0-3.9 3.1-7 7-7s7 3.1 7 7"/>',
cap:'<path d="M2.5 9.5 12 5l9.5 4.5L12 14z"/><path d="M6.5 11.8V16c0 1.4 2.5 2.8 5.5 2.8s5.5-1.4 5.5-2.8v-4.2"/><path d="M21.5 9.5V14"/>',
board:'<path d="M3.5 4.5h17M5.5 4.5v10h13v-10M12 14.5V20M8.5 20h7"/>',
clipcheck:'<rect x="5.5" y="4.5" width="13" height="16.5" rx="2"/><path d="M9 4.5h6V7H9z"/><path d="m9.5 13.8 1.9 1.9 3.3-3.7"/>',
file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
filechart:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 17v-3M12 17v-5M15 17v-2"/>',
book:'<path d="M5 5a2 2 0 0 1 2-2h12v15H7a2 2 0 0 0-2 2z"/><path d="M5 20a1 1 0 0 0 1 1h13v-3"/>',
bookopen:'<path d="M12 6.8C10.5 5.3 8 4.6 3.5 4.6v13c4.5 0 7 .6 8.5 2.1 1.5-1.5 4-2.1 8.5-2.1v-13c-4.5 0-7 .7-8.5 2.2z"/><path d="M12 6.8v12.9"/>',
award:'<circle cx="12" cy="9" r="5.5"/><path d="m8.8 13.4-1.3 7.6 4.5-2.4 4.5 2.4-1.3-7.6"/>',
sliders:'<path d="M4 7h8M16 7h4M4 17h3M11 17h9"/><circle cx="14" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
calendar:'<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
history:'<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1L3.5 8.5"/><path d="M3.5 4v4.5H8M12 7.5V12l3 2"/>',
megaphone:'<path d="M4 10.5v3a1 1 0 0 0 1 1h2.5l7.5 4.5V5L7.5 9.5H5a1 1 0 0 0-1 1z"/><path d="M18.5 9a4.2 4.2 0 0 1 0 6"/>',
pencil:'<path d="M4 20l1-4.2L16.3 4.5a2.1 2.1 0 0 1 3 3L8 18.8z"/><path d="m14.5 6.3 3.2 3.2"/>',
mail:'<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="m3.8 7.6 8.2 5.6 8.2-5.6"/>',
chart:'<path d="M5.5 20v-6M12 20V5M18.5 20v-9M3 20.5h18"/>',
shield:'<path d="M12 3 4.5 6v5.6c0 4.5 3 7.9 7.5 9.4 4.5-1.500 7.5-4.900 7.500-9.400V6z"/><path d="m9 12 2.200 2.200L15.500 10"/>',
database:'<ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v6c0 1.700 3.400 3 7.500 3s7.500-1.300 7.500-3V6M4.500 12v6c0 1.700 3.400 3 7.500 3s7.500-1.300 7.500-3v-6"/>',
download:'<path d="M12 4v11M7.5 10.800 12 15.300l4.500-4.500M5 20h14"/>',
bus:'<rect x="4" y="3.500" width="16" height="13.500" rx="2.500"/><path d="M4 11h16M8 20v-3M16 20v-3"/><path d="M8 14h.01M16 14h.01"/>',
car:'<path d="M3.500 15.500V11l2-5a1.500 1.500 0 0 1 1.400-1h10.200a1.500 1.500 0 0 1 1.400 1l2 5v4.500"/><path d="M3.500 15.500h17v2.500a1 1 0 0 1-1 1h-1.500a1 1 0 0 1-1-1v-1M3.500 15.500V18a1 1 0 0 0 1 1H6a1 1 0 0 0 1-1v-1"/><path d="M7.500 12.500h.01M16.500 12.500h.01"/>',
wallet:'<rect x="3" y="6" width="18" height="13.500" rx="2.500"/><path d="M3 10.500h18M16.500 15h.01"/>',
pin:'<path d="M12 21s-6.500-5.500-6.500-11a6.500 6.500 0 0 1 13 0c0 5.500-6.500 11-6.500 11z"/><circle cx="12" cy="10" r="2.300"/>',
route:'<circle cx="6" cy="18" r="2"/><circle cx="18" cy="6" r="2"/><path d="M8 18h7a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h7"/>',
search:'<circle cx="11" cy="11" r="6.500"/><path d="m20 20-4.200-4.200"/>',
lock:'<rect x="5" y="10.500" width="14" height="10" rx="2.500"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.500"/>',
logout:'<path d="M10 4H6.500A2.500 2.500 0 0 0 4 6.500v11A2.500 2.500 0 0 0 6.500 20H10M15.500 8l4 4-4 4M19.500 12H9.500"/>',
print:'<path d="M7 9V4h10v5"/><path d="M7 17H5.500A1.500 1.500 0 0 1 4 15.500v-5A1.500 1.500 0 0 1 5.500 9h13a1.500 1.500 0 0 1 1.500 1.500v5a1.500 1.500 0 0 1-1.500 1.500H17"/><path d="M7 14h10v6H7z"/>',
menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',
star:'<path d="m12 3.500 2.600 5.400 5.900.8-4.300 4.100 1 5.800L12 16.800 6.800 19.600l1-5.800-4.300-4.100 5.900-.8z"/>',
sun:'<circle cx="12" cy="12" r="3.800"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.600 5.600 7 7M17 17l1.400 1.400M5.600 18.400 7 17M17 7l1.400-1.400"/>',
moon:'<path d="M20 14.500A8.500 8.500 0 0 1 9.500 4a8.500 8.500 0 1 0 10.500 10.500z"/>',
arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
swap:'<path d="M4 8h14M14 4l4 4-4 4M20 16H6M10 12l-4 4 4 4"/>',
refresh:'<path d="M20 12a8 8 0 1 1-2.400-5.700M20 4v4.500h-4.500"/>',
key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8.500-8.500M16 7l3 3M14 9l2 2"/>',
clip:'<path d="m20 11.500-8.200 8.200a5 5 0 0 1-7-7l8.700-8.700a3.300 3.300 0 0 1 4.700 4.700l-8.800 8.800a1.700 1.700 0 0 1-2.400-2.400l8-8"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5.500M12 7.800v.01"/>',
check:'<path d="m5 12.500 4.500 4.500L19 7.500"/>',
checkc:'<circle cx="12" cy="12" r="9"/><path d="m8 12.300 2.800 2.800L16 9.500"/>',
x:'<path d="M6 6l12 12M18 6 6 18"/>',
alert:'<path d="M12 3.800 2.800 19.500h18.400z"/><path d="M12 10v4.500M12 17.300v.01"/>',
seat:'<path d="M7 4h6a2 2 0 0 1 2 2v7H7z"/><path d="M5 13h13a1.500 1.500 0 0 1 1.500 1.500V20M7 13v7M5 20h14"/>',
doc:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
table:'<rect x="3.500" y="4.500" width="17" height="15" rx="2"/><path d="M3.500 10h17M9.500 10v9.500M3.500 15h17"/>',
bookmark:'<path d="M7 4h10v16.500l-5-3.500-5 3.500z"/>',
upload:'<path d="M12 20V9M7.500 13.500 12 9l4.500 4.500M5 4h14"/>',
undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
sparkle:'<path d="M12 3.500c.8 4.600 2.900 6.700 7.500 7.500-4.600.8-6.700 2.900-7.500 7.500-.8-4.600-2.900-6.700-7.500-7.500 4.600-.8 6.700-2.900 7.500-7.500z"/>'
};
function svg(n){return '<svg viewBox="0 0 24 24" aria-hidden="true">'+(P[n]||P.info)+'</svg>'}
function ico(n){return '<i class="ico" aria-hidden="true">'+svg(n)+'</i>'}
window.PremiumIcons={svg:svg,ico:ico};

/* ---------- name maps ---------- */
var PAGE={
'Dashboard':'home','Analytics':'chart','Reports':'filechart','Get the App':'download',
'Students':'cap','Student Details':'user','Teachers':'board','Guardians':'users','Teacher Attendance':'clipcheck',
'My Attendance & Leave':'calendar','Academic Setup':'sliders','Academic Years':'calendar','Timetable':'table',
'Homework':'pencil','Announcements':'megaphone','Calendar':'calendar','Settings':'sliders','Audit Log':'shield',
'Subjects':'book','Attendance':'clipcheck','Examinations':'file','Report Cards':'award','Results':'award',
'My Children':'users','Messages':'mail','Backup & Restore':'database','Family Overview':'users',
'Library':'bookopen','Books':'book','Issue & Return':'swap','Overdue & Fines':'clock','Reservations':'bookmark',
'Borrower History':'history','Library Reports':'filechart','Library Settings':'sliders',
'Fees':'wallet','Defaulters':'alert','Transport':'bus','Vehicles':'car','Student Transport':'user','Transport Fees':'wallet','Transport Settings':'sliders'
};
/* glyph / emoji (first code point) -> icon, or '' to drop */
var GLYPH={
'⌂':'home','♙':'user','♟':'users','▣':'file','▤':'file','▥':'file','▦':'table','◈':'book','◫':'calendar','◆':'megaphone','◷':'clock',
'⚙':'sliders','✓':'check','✔':'check','✅':'checkc','✕':'x','✖':'x','✗':'x','×':'x','★':'star','✎':'pencil','✉':'mail','✦':'sparkle',
'⚠':'alert','⏰':'clock','➜':'arrow','⇄':'swap','⟳':'refresh','⇩':'download','⬇':'download','⬆':'upload','↥':'upload','↩':'undo','↻':'refresh','⌕':'search','⏳':'clock','☀':'sun','☾':'moon','₹':'',
'🚌':'bus','🚐':'car','🚗':'car','🧒':'user','💳':'wallet','💺':'seat','📍':'pin','🛣':'route','🌅':'sun','🌇':'clock','📅':'calendar','🗓':'calendar',
'🧑':'users','👨':'user','👩':'user','👪':'users','👧':'user','🎓':'cap','🏫':'cap','📚':'bookopen','📖':'book','📕':'doc','📘':'doc','📗':'doc','📙':'doc',
'📄':'doc','📜':'award','📊':'chart','📈':'chart','🔎':'search','🔑':'key','💾':'database','💬':'mail','📎':'clip','🏆':'award','📝':'pencil',
'💼':'wallet','🏠':'home','🛠':'sliders','✈':'',
'👋':'','🎉':'','👍':'','🤝':''
};
var EMOJI=/(?![©®™‼⁉↔↕])(?:\p{Extended_Pictographic}|[✓✔✕✖✗★✦⌂♙♟▣▤▥▦◈◫◆◷✎✉⇄⟳⇩➜☀☾⚙⌕↥↩↻⏳⬆⬇])(?:\uFE0F|\u200D\p{Extended_Pictographic}\uFE0F?|\uFE0F?\u200D(?:\p{Extended_Pictographic})\uFE0F?)*\uFE0F?/gu;
function key(g){return Array.from(g)[0]}
function iconFor(g){var k=key(g); return Object.prototype.hasOwnProperty.call(GLYPH,k)?GLYPH[k]:'info'}

/* ---------- containers whose whole content is an icon glyph ---------- */
var ICON_BOXES='.v-stat-icon,.v-tip-icon,.lib-stat-ico,.lib-rank>span:first-child,.v-action>span:first-child,.v-head-btn,.chat-empty>div:first-child,.chat-av.ico-only';
function boxName(el){
  var t=(el.textContent||'').trim(); if(!t) return null;
  if(el.matches('.v-action>span')){var b=el.parentNode.querySelector('b'); var nm=b&&b.textContent.trim(); if(nm&&PAGE[nm]) return PAGE[nm]}
  if(el.matches('.v-stat-icon')){ if(t==='₹') return null; if(el.parentNode.classList.contains('attendance')) return 'clipcheck'; if(el.parentNode.classList.contains('people')) return 'cap'; return 'chart' }
  if(el.matches('.v-tip-icon')) return t==='✓'?'checkc':'sparkle';
  if(el.matches('.chat-empty>div:first-child')) return 'mail';
  var m=t.match(EMOJI); if(!m||m[0].length!==t.length&&t.replace(EMOJI,'').trim()) return null;
  var n=iconFor(m[0]); return n||null;
}
function doBox(el){
  if(el.__pi) return; var n=boxName(el); if(!n) return;
  el.__pi=1; el.innerHTML=svg(n); el.classList.add('pi-box');
}

/* ---------- nav ---------- */
function doNav(btn){
  var pg=btn.getAttribute('data-page'); var ic=btn.querySelector('.nav-ico');
  if(!ic){ic=document.createElement('span');ic.className='nav-ico';btn.insertBefore(ic,btn.firstChild)}
  var want=PAGE[pg]||'info'; if(ic.getAttribute('data-n')===want) return;
  ic.setAttribute('data-n',want); ic.innerHTML=svg(want);
  /* legacy markup put the label in the button text; wrap bare text so it can't collide with the icon */
}

/* ---------- text-node sweep (headings/options: drop; everywhere else: convert) ---------- */
var SKIP='script,style,textarea,input,.bubble,.chat-msgs,.chat-prev,.chat-name,.id-card-modern,[class*="id-card"],[class*="hprc"],.slip,[data-noicon]';
var DROP_IN=/^(OPTION|H1|H2|H3|H4|TITLE|LABEL|SMALL)$/;
function doText(tn){
  var s=tn.nodeValue; if(!s||!EMOJI.test(s)){EMOJI.lastIndex=0;return} EMOJI.lastIndex=0;
  var p=tn.parentNode; if(!p||(p.closest&&p.closest(SKIP))) return;
  if(p.closest&&p.closest('.v-hero h1')){tn.nodeValue=s.replace(EMOJI,'').replace(/\s+$/,'');return}
  var drop=DROP_IN.test(p.nodeName)||(p.closest&&p.closest('h1,h2,h3,h4,option'));
  if(drop){tn.nodeValue=s.replace(EMOJI,'').replace(/^\s+/,'').replace(/\s{2,}/g,' ');return}
  var frag=document.createDocumentFragment(),last=0,m; EMOJI.lastIndex=0;
  while((m=EMOJI.exec(s))){
    var n=iconFor(m[0]);
    if(m.index>last) frag.appendChild(document.createTextNode(s.slice(last,m.index)));
    if(n){var w=document.createElement('span');w.innerHTML=ico(n);frag.appendChild(w.firstChild)}
    last=m.index+m[0].length;
    if(!n&&s.charAt(last)===' ')last++;
  }
  EMOJI.lastIndex=0;
  if(last<s.length) frag.appendChild(document.createTextNode(s.slice(last)));
  p.replaceChild(frag,tn);
}

function sweep(root){
  if(!root) return;
  if(root.nodeType===3){doText(root);return}
  if(root.nodeType!==1) return;
  if(root.matches&&root.matches('#nav button[data-page]')) doNav(root);
  if(root.matches&&root.matches(ICON_BOXES)) doBox(root);
  var q=root.querySelectorAll?root.querySelectorAll('#nav button[data-page],'+ICON_BOXES+',[data-ico]'):[];
  for(var i=0;i<q.length;i++){
    var e=q[i];
    if(e.hasAttribute('data-ico')){ if(!e.__pi){e.__pi=1;e.innerHTML=svg(e.getAttribute('data-ico'));e.classList.add('ico')} }
    else if(e.matches('#nav button[data-page]')) doNav(e);
    else doBox(e);
  }
  var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null),t,list=[];
  while((t=w.nextNode())){ if(t.nodeValue&&t.nodeValue.length<4000&&/[^\x00-\u2000]/.test(t.nodeValue)) list.push(t) }
  for(var j=0;j<list.length;j++) doText(list[j]);
  /* the sign-in icon (and any other i[data-ico]) keep the .ico box */
}

/* ---------- observe ---------- */
var busy=false, pending=[];
function flush(){
  busy=true;
  try{ pending.splice(0).forEach(function(n){ if(n.isConnected) sweep(n) }) }catch(e){}
  busy=false;
}
var raf=null;
var mo=new MutationObserver(function(ms){
  if(busy) return;
  for(var i=0;i<ms.length;i++){
    var m=ms[i];
    if(m.type==='childList') m.addedNodes.forEach(function(n){ pending.push(n) });
    else if(m.type==='characterData') pending.push(m.target);
  }
  if(pending.length&&!raf){raf=requestAnimationFrame(function(){raf=null;flush()})}
});
function start(){
  sweep(document.body);
  mo.observe(document.body,{childList:true,subtree:true,characterData:true});
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start); else start();

/* theme-colour meta follows the display mode */
function syncMeta(){
  var m=document.querySelector('meta[name="theme-color"]'); if(!m) return;
  m.setAttribute('content',(getComputedStyle(document.documentElement).getPropertyValue('--p-side').trim()||'#0f1b2d'));
}
new MutationObserver(syncMeta).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-mode']});
syncMeta();
})();

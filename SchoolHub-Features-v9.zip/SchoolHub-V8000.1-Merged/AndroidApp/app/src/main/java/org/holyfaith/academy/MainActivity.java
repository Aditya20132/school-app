package org.holyfaith.academy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "holyfaith_app";
    private static final String KEY_URL = "school_url";
    private SharedPreferences prefs;
    private WebView webView;
    private EditText urlInput;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String saved = prefs.getString(KEY_URL, "");
        if (saved == null || saved.trim().isEmpty()) showUrlSetup();
        else loadSchool(saved.trim());
    }

    private void showUrlSetup() {
        webView = null;
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(26), dp(24), dp(28));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(org.holyfaith.academy.R.drawable.holyfaith_logo);
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(150)));

        TextView title = text("HOLYFAITH ACADEMY", 25, true);
        title.setTextColor(Color.rgb(12, 54, 92));
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2, 0, 8));

        TextView version = text("School Management App • V8.000", 14, false);
        version.setTextColor(Color.DKGRAY); version.setGravity(Gravity.CENTER);
        root.addView(version, lp(-1, -2, 0, 24));

        TextView heading = text("Connect to School Website", 20, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, lp(-1, -2, 0, 8));

        TextView info = text("Enter the HTTPS address of your online Holyfaith Academy website. You can change this later from the app menu.", 15, false);
        info.setTextColor(Color.DKGRAY); info.setGravity(Gravity.CENTER);
        root.addView(info, lp(-1, -2, 0, 18));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("https://your-school-website.com/");
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setText(prefs.getString(KEY_URL, ""));
        root.addView(urlInput, lp(-1, dp(56), 0, 14));

        Button save = new Button(this);
        save.setText("SAVE & OPEN SCHOOL");
        save.setOnClickListener(v -> saveAndOpen());
        root.addView(save, lp(-1, dp(52), 0, 12));

        TextView note = text("Tip: Use HTTPS. Example: https://school.example.com/", 13, false);
        note.setTextColor(Color.GRAY); note.setGravity(Gravity.CENTER);
        root.addView(note, lp(-1, -2, 0, 12));

        setContentView(scroll);
        urlInput.requestFocus();
    }

    private void saveAndOpen() {
        String url = urlInput.getText().toString().trim();
        if (!url.matches("(?i)^https://.+")) {
            Toast.makeText(this, "Please enter a valid HTTPS website URL.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!url.endsWith("/")) url += "/";
        prefs.edit().putString(KEY_URL, url).apply();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        loadSchool(url);
    }

    private void loadSchool(String url) {
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " HolyfaithAcademy/8.000");
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }
        });
        webView.loadUrl(url);
        invalidateOptionsMenu();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        if (webView != null) {
            menu.add("Website Settings").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            menu.add("Reload").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        }
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        String title = item.getTitle().toString();
        if (title.equals("Website Settings")) { showChangeUrlDialog(); return true; }
        if (title.equals("Reload")) { if (webView != null) webView.reload(); return true; }
        return super.onOptionsItemSelected(item);
    }

    private void showChangeUrlDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://your-school-website.com/");
        input.setText(prefs.getString(KEY_URL, ""));
        input.setSelectAllOnFocus(true);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("School Website URL")
                .setMessage("Change the website used by this APK. HTTPS is required.")
                .setView(input)
                .setPositiveButton("Save & Open", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String url = input.getText().toString().trim();
            if (!url.matches("(?i)^https://.+")) {
                input.setError("Enter a valid HTTPS URL");
                return;
            }
            if (!url.endsWith("/")) url += "/";
            prefs.edit().putString(KEY_URL, url).apply();
            dialog.dismiss();
            loadSchool(url);
        }));
        dialog.show();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL); return t;
    }
    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h); p.setMargins(0, top, 0, bottom); return p;
    }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}

@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo   HOLYFAITH ACADEMY - SCHOOLHUB V8000.1 PREVIEW
echo ================================================
echo.

set "NODE_EXE=%~dp0tools\node\node.exe"
if exist "%NODE_EXE%" goto START

where node >nul 2>&1
if %errorlevel%==0 goto START

echo Node.js is not installed. Downloading portable Node.js automatically...
echo Please wait...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\get-node.ps1"
if not exist "%NODE_EXE%" (
  echo.
  echo ERROR: Could not prepare Node.js.
  echo Please check your Internet connection and run this file again.
  pause
  exit /b 1
)

:START
echo Starting SchoolHub V8000.1 in PREVIEW MODE...
echo.
start "Holyfaith Academy V8000.1 Server" cmd /k call "%~dp0RUN-SERVER-PREVIEW.bat"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000"
echo.
echo Browser opened at http://localhost:3000
echo Keep the black server window open while previewing.
echo Close the server window when you are finished.
endlocal

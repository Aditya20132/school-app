@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "OUT=%~dp0BUILD-OUTPUT"
if not exist "%OUT%" mkdir "%OUT%"

echo =====================================================
echo HOLYFAITH ACADEMY - BUILD ALL
echo =====================================================
echo This builds the Windows EXE and Android DEBUG APK.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Downloading a portable Node.js copy automatically...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\get-node.ps1"
  if errorlevel 1 goto fail
  set "PATH=%~dp0tools\node;%PATH%"
)

REM IMPORTANT: Do not use the system Java or a newer Android Studio JBR here.
REM Gradle 8.10.2 fails with Java 25 (class file major version 69).
REM Use the portable Java 21 supplied by this package so the build is predictable.
echo Preparing Java 21 for the Android build...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\get-jdk21.ps1"
if errorlevel 1 goto fail
set "JAVA_HOME=%~dp0tools\jdk21"
set "PATH=%JAVA_HOME%\bin;%PATH%"
echo Java used for Android build:
"%JAVA_HOME%\bin\java.exe" -version

if not defined ANDROID_HOME if defined ANDROID_SDK_ROOT set "ANDROID_HOME=%ANDROID_SDK_ROOT%"
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not defined ANDROID_HOME if exist "%USERPROFILE%\AppData\Local\Android\Sdk" set "ANDROID_HOME=%USERPROFILE%\AppData\Local\Android\Sdk"

if not defined ANDROID_HOME (
  echo.
  echo Android SDK was not found.
  echo Install Android Studio, open SDK Manager, and install Android SDK Platform 35.
  goto fail
)

echo Android SDK: %ANDROID_HOME%

if not exist "%ANDROID_HOME%\platforms\android-35" (
  echo.
  echo Android SDK Platform 35 is missing.
  echo In Android Studio: More Actions ^> SDK Manager ^> SDK Platforms ^> Android 15/API 35.
  goto fail
)

set "ANDROID_DIR=%~dp0AndroidApp"
set "WIN_DIR=%~dp0WindowsApp"

if not exist "%ANDROID_DIR%\gradlew.bat" (
  echo Preparing Gradle wrapper...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\prepare-gradle.ps1"
  if errorlevel 1 goto fail
)

if not exist "%ANDROID_DIR%\local.properties" echo sdk.dir=%ANDROID_HOME:\=/%> "%ANDROID_DIR%\local.properties"

echo.
echo [1/2] Building Android APK...
cd /d "%ANDROID_DIR%"
call gradlew.bat assembleDebug
if errorlevel 1 goto fail
copy /y "app\build\outputs\apk\debug\app-debug.apk" "%OUT%\Holyfaith-Academy.apk" >nul
if errorlevel 1 goto fail

echo Android APK created: %OUT%\Holyfaith-Academy.apk

echo.
echo [2/2] Building Windows EXE...
cd /d "%WIN_DIR%"
call MAKE-EXE.bat
if errorlevel 1 goto fail
copy /y "SchoolHub-V5000.exe" "%OUT%\Holyfaith-Academy.exe" >nul
if errorlevel 1 goto fail

echo Windows EXE created: %OUT%\Holyfaith-Academy.exe

cd /d "%~dp0"
echo.
echo =====================================================
echo BUILD COMPLETE
echo =====================================================
echo Files are in:
echo %OUT%
echo.
echo Android: Holyfaith-Academy.apk
echo Windows: Holyfaith-Academy.exe
echo.
pause
exit /b 0

:fail
cd /d "%~dp0"
echo.
echo =====================================================
echo BUILD FAILED
echo =====================================================
echo Read the message above, fix the missing requirement, then run BUILD-ALL.bat again.
echo =====================================================
pause
exit /b 1

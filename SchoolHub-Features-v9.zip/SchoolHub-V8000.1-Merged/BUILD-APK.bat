@echo off
cd /d "%~dp0"
call BUILD-ALL.bat

'use strict';
/* SchoolHub website + online admissions (server).
   - Serves the public school website at /site/
   - POST /api/site/admission (+ document uploads) -> stored as an admission request, admin + clerk are notified
   - Customer Messages tab API: list / approve / reject / resend e-mail / mark admitted
   - Approval e-mail is sent from the school Gmail through SMTP (no extra package), falling back to Brevo if set up
   Everything lives in the existing school-data JSON (db.admissions, db.site_settings). Documents go through storage.js. */
const crypto = require('node:crypto');
const tls = require('node:tls');
const path = require('node:path');

module.exports = function (ctx) {
  const D = () => ctx.db();
  const json = (res, s, o, h) => ctx.json(res, s, o, h);
  const txt = (v, n = 200) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, n);
  const esc = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const emailOk = e => { const t = String(e || '').trim(); return t.length <= 120 && !/[\r\n]/.test(t) && /^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$/.test(t); };
  const mobileOk = v => /^[6-9]\d{9}$/.test(String(v || '').replace(/\D/g, '').slice(-10)) && String(v || '').replace(/\D/g, '').length >= 10;
  const last10 = v => String(v || '').replace(/\D/g, '').slice(-10);
  const isClerk = u => !!(u && (D().users.find(x => Number(x.id) === Number(u.id)) || {}).clerk);
  const nid = arr => arr.length ? Math.max(...arr.map(x => Number(x.id) || 0)) + 1 : 1;

  /* ---------- settings ---------- */
  const DEFAULT_BODY = 'Dear {parent},\n\nWe are delighted to tell you that the admission request for {student} (Class {class}) at Holyfaith Academy has been approved. Your reference number is {ref}.\n\nOur admission office will call you shortly on the number you gave us to complete the remaining formalities and guide you through the next steps. Please keep the original documents ready.\n\nIf you have any question in the meantime, tap the button below to contact us.\n\nWarm regards,\nAdmission Office\nHolyfaith Academy';
  function S() {
    const d = D(); if (!Array.isArray(d.admissions)) d.admissions = []; if (!Array.isArray(d.site_settings)) d.site_settings = [];
    if (!d.site_settings.length) d.site_settings.push({ id: 1 });
    const s = d.site_settings[0];
    s.contact_phone = s.contact_phone ?? '+91 93322 80028';
    s.school_email = s.school_email ?? 'admin@myholyfaith.org';
    s.gmail_user = s.gmail_user ?? 'holyfaithacademy096@gmail.com';
    s.gmail_pass = s.gmail_pass ?? '';
    s.email_enabled = s.email_enabled !== false;
    s.mail_provider = ['auto', 'gmail', 'brevo'].includes(s.mail_provider) ? s.mail_provider : 'auto';
    s.email_subject = s.email_subject || 'Your admission request is approved – Holyfaith Academy';
    s.email_body = s.email_body || DEFAULT_BODY;
    s.application_note = s.application_note ?? '';
    return s;
  }

  /* ---------- mail: Gmail SMTP over TLS (port 465), minimal client ---------- */
  const b64 = s => Buffer.from(s, 'utf8').toString('base64');
  const wrap76 = s => s.replace(/(.{76})/g, '$1\r\n');
  function buildMime({ fromName, from, to, subject, html, text }) {
    const bd = 'hfa_' + crypto.randomBytes(12).toString('hex');
    const enc = v => '=?UTF-8?B?' + b64(v) + '?=';
    const head = [
      `From: ${enc(fromName)} <${from}>`, `To: <${to}>`, `Subject: ${enc(subject.replace(/[\r\n]+/g, ' '))}`,
      `Date: ${new Date().toUTCString()}`, `Message-ID: <${crypto.randomBytes(12).toString('hex')}@holyfaith.local>`,
      'MIME-Version: 1.0', `Content-Type: multipart/alternative; boundary="${bd}"`
    ].join('\r\n');
    const part = (type, body) => `--${bd}\r\nContent-Type: ${type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap76(b64(body))}\r\n`;
    return head + '\r\n\r\n' + part('text/plain', text) + part('text/html', html) + `--${bd}--\r\n`;
  }
  function smtpSend(o) {
    return new Promise((resolve, reject) => {
      const host = process.env.SMTP_HOST || 'smtp.gmail.com', port = Number(process.env.SMTP_PORT || 465);
      let finished = false, buf = '', cb = null;
      const sock = tls.connect({ host, port, servername: host, rejectUnauthorized: process.env.SMTP_TEST_INSECURE !== '1' });
      const done = (e, v) => { if (finished) return; finished = true; try { sock.destroy(); } catch { } e ? reject(e) : resolve(v); };
      sock.setTimeout(20000, () => done(new Error('The mail server did not answer in time')));
      sock.on('error', e => done(new Error('Could not reach the mail server: ' + e.message)));
      sock.on('data', d => { buf += d.toString('utf8'); check(); });
      function check() {
        const lines = buf.split('\r\n'); if (lines.length < 2) return;
        const full = lines.slice(0, -1), last = full[full.length - 1];
        if (/^\d{3} /.test(last) && cb) { const f = cb; cb = null; buf = lines[lines.length - 1]; f(Number(last.slice(0, 3)), full.join(' | ')); }
      }
      const expect = ok => new Promise((res, rej) => { cb = (code, t) => ok.includes(code) ? res(t) : rej(new Error(code === 535 ? 'Gmail refused the login. Use a 16-character App Password (2-step verification must be on), not the normal password.' : 'Mail server said: ' + t.slice(0, 180))); });
      const cmd = (line, ok) => { const p = expect(ok); sock.write(line + '\r\n'); return p; };
      (async () => {
        await expect([220]);
        await cmd('EHLO holyfaith.local', [250]);
        await cmd('AUTH LOGIN', [334]); await cmd(b64(o.user), [334]); await cmd(b64(o.pass), [235]);
        await cmd(`MAIL FROM:<${o.user}>`, [250]); await cmd(`RCPT TO:<${o.to}>`, [250, 251]);
        await cmd('DATA', [354]);
        const msg = buildMime({ fromName: o.fromName, from: o.user, to: o.to, subject: o.subject, html: o.html, text: o.text }).replace(/\r\n\./g, '\r\n..');
        const p = expect([250]); sock.write(msg + '\r\n.\r\n'); await p;
        try { await cmd('QUIT', [221]); } catch { }
        done(null, true);
      })().catch(done);
    });
  }
  async function sendMail(to, subject, html, text) {
    const s = S(), prov = s.mail_provider || 'auto';
    if (!emailOk(to)) throw new Error('The applicant e-mail address is not valid');
    const gmailOk = !!(s.gmail_pass && emailOk(s.gmail_user)), brevoOk = !!(ctx.emailReady && ctx.emailReady() && ctx.brevoSend);
    if (prov === 'brevo') { if (!brevoOk) throw new Error('Brevo is not set up. Open Settings > E-mail (Brevo), save the API key and a verified sender, then try again.'); return ctx.brevoSend(to, to, subject, html, text); }
    if (prov === 'gmail' || (prov === 'auto' && gmailOk)) { if (!gmailOk) throw new Error('Gmail is not set up. Save the Gmail App Password in Website Settings, or choose Brevo.'); return smtpSend({ user: s.gmail_user.trim(), pass: s.gmail_pass.replace(/\s+/g, ''), fromName: 'Holyfaith Academy', to, subject, html, text }); }
    if (brevoOk) return ctx.brevoSend(to, to, subject, html, text);
    throw new Error('E-mail is not set up yet. Open Website Settings and choose Brevo or save a Gmail App Password.');
  }
  const fill = (t, a, s) => String(t).replace(/\{(student|parent|class|ref|phone)\}/g, (_, k) => ({ student: a.full_name, parent: a.father_name || a.mother_name || 'Parent / Guardian', class: a.class_applying, ref: a.ref, phone: s.contact_phone }[k] || ''));
  function approvalEmail(a) {
    const s = S(), phone = s.contact_phone, tel = 'tel:' + String(phone).replace(/[^\d+]/g, '');
    const body = fill(s.email_body, a, s), subject = fill(s.email_subject, a, s);
    const paras = esc(body).split(/\n{2,}/).map(p => `<p style="margin:0 0 16px;line-height:1.65">${p.replace(/\n/g, '<br>')}</p>`).join('');
    const html = `<!doctype html><html><body style="margin:0;background:#f3f1fb;font-family:Segoe UI,Arial,sans-serif;color:#1f1b3a"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:28px 12px"><table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#fff;border-radius:14px;overflow:hidden"><tr><td style="background:#5b21b6;padding:22px 28px;color:#fff"><div style="font-size:20px;font-weight:700">Holyfaith Academy</div><div style="font-size:13px;opacity:.85">Educating for Excellence, Preparing for Life</div></td></tr><tr><td style="padding:28px"><div style="display:inline-block;background:#dcfce7;color:#166534;font-weight:600;font-size:13px;padding:5px 12px;border-radius:999px;margin-bottom:16px">Admission approved &middot; Ref ${esc(a.ref)}</div>${paras}<table role="presentation" cellpadding="0" cellspacing="0" style="margin:22px 0 6px"><tr><td style="background:#6d28d9;border-radius:999px"><a href="${esc(tel)}" style="display:inline-block;padding:14px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:16px">&#128222; Contact Us &nbsp;&middot;&nbsp; ${esc(phone)}</a></td></tr></table><p style="font-size:12px;color:#6b6788;margin:14px 0 0">Tap the button on your phone to call us directly.</p></td></tr><tr><td style="background:#f8f7fd;padding:14px 28px;font-size:12px;color:#6b6788">This message was sent because an admission request was made for ${esc(a.full_name)} on our website.</td></tr></table></td></tr></table></body></html>`;
    return { subject, html, text: body + `\n\nContact Us: ${phone}\n` };
  }

  /* ---------- helpers ---------- */
  const publicView = a => { const { token, ...rest } = a; return rest; };
  const adminIds = () => D().users.filter(u => u.role === 'admin').map(u => u.id);
  const hits = new Map();
  function limited(key, max, ms) {
    const now = Date.now(), arr = (hits.get(key) || []).filter(t => now - t < ms);
    if (arr.length >= max) { hits.set(key, arr); return true; } arr.push(now); hits.set(key, arr); return false;
  }
  setInterval(() => { const now = Date.now(); for (const [k, v] of hits) { const f = v.filter(t => now - t < 3600e3); f.length ? hits.set(k, f) : hits.delete(k); } }, 600e3).unref?.();
  function readRaw(req, max) {
    return new Promise((resolve, reject) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > max) { reject(Object.assign(new Error('too large'), { code: 413 })); req.destroy(); return; } ch.push(c); }); req.on('end', () => resolve(Buffer.concat(ch))); req.on('error', reject); });
  }
  const DOC_KINDS = { photo: 'Passport photo', signature: 'Signature of student', birth_certificate: 'Birth certificate', aadhaar_copy: 'Aadhaar card copy', marksheet: 'Previous marksheet / TC' };
  const FILE_MAX = 3 * 1024 * 1024;
  const sniff = b => b.slice(0, 4).equals(Buffer.from([0xff, 0xd8, 0xff, b[3]])) ? 'image/jpeg' : b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) ? 'image/png' : b.slice(0, 4).toString() === '%PDF' ? 'application/pdf' : (b.slice(0, 4).toString() === 'RIFF' && b.slice(8, 12).toString() === 'WEBP') ? 'image/webp' : '';
  const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'application/pdf': 'pdf', 'image/webp': 'webp' };
  const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Not known'];
  const STAY = ['Day Scholar', 'Day Boarding', 'Boarder (Hostel)'];
  const GENDER = ['Male', 'Female', 'Other'];

  function validateForm(v) {
    const e = [], o = {
      full_name: txt(v.full_name, 80), dob: txt(v.dob, 10), gender: txt(v.gender, 10), aadhaar: String(v.aadhaar || '').replace(/\D/g, ''),
      father_name: txt(v.father_name, 80), mother_name: txt(v.mother_name, 80), email: txt(v.email, 120).toLowerCase(), mobile: last10(v.mobile),
      emergency_contact: last10(v.emergency_contact), blood_group: txt(v.blood_group, 10), address: txt(v.address, 400),
      prev_school: txt(v.prev_school, 120), last_grade: txt(v.last_grade, 40), score: txt(v.score, 20), prev_class: txt(v.prev_class, 40),
      class_applying: txt(v.class_applying, 40), stay_type: txt(v.stay_type, 30), message: txt(v.message, 1500)
    };
    if (o.full_name.length < 2) e.push('Student full name is required');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(o.dob) || isNaN(new Date(o.dob)) || new Date(o.dob) > new Date()) e.push('Enter a valid date of birth');
    if (!GENDER.includes(o.gender)) e.push('Select gender');
    if (o.aadhaar.length !== 12) e.push('Aadhaar number must be 12 digits');
    if (o.father_name.length < 2) e.push("Father's name is required");
    if (o.mother_name.length < 2) e.push("Mother's name is required");
    if (!emailOk(o.email)) e.push('Enter a valid e-mail address');
    if (!mobileOk(o.mobile)) e.push('Enter a valid 10-digit parent mobile number');
    if (!mobileOk(o.emergency_contact)) e.push('Enter a valid 10-digit emergency contact number');
    if (o.blood_group && !BLOOD.includes(o.blood_group)) e.push('Select a valid blood group');
    if (o.address.length < 8) e.push('Permanent home address is required');
    if (!o.class_applying) e.push('Select the class applying for');
    if (!STAY.includes(o.stay_type)) e.push('Select Day Scholar, Day Boarding or Boarder');
    return { e, o };
  }

  /* ---------- routes ---------- */
  const routes = [];
  const route = (method, pat, roles, fn) => routes.push({ method, pat: pat instanceof RegExp ? pat : new RegExp('^' + pat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'), roles, fn });

  route('GET', '/api/site/info', false, async ({ res }) => { const s = S(); json(res, 200, { phone: s.contact_phone, email: s.school_email, note: s.application_note }, { 'Cache-Control': 'no-store' }); });

  route('POST', '/api/site/admission', false, async ({ req, res, v }) => {
    const ip = ctx.clientIp(req);
    if (limited('adm:' + ip, 6, 3600e3)) return json(res, 429, { error: 'Too many submissions from this connection. Please try again in an hour or call the school.' });
    const b = await v();
    if (txt(b.website, 50)) return json(res, 200, { ok: true, id: 0, token: 'x', ref: 'ADM-0000' }); /* honeypot: bots fill the hidden field */
    const { e, o } = validateForm(b);
    if (e.length) return json(res, 400, { error: e[0], errors: e });
    const d = D(); S(); const year = new Date().getFullYear();
    const seq = d.admissions.filter(a => String(a.ref || '').startsWith('ADM-' + year)).length + 1;
    const dup = d.admissions.find(a => a.status === 'pending' && a.aadhaar === o.aadhaar);
    if (dup) return json(res, 409, { error: 'An admission request for this Aadhaar number is already waiting for approval. The school will contact you.' });
    const rec = { id: nid(d.admissions), ref: `ADM-${year}-${String(seq).padStart(4, '0')}`, ...o, docs: [], status: 'pending', token: crypto.randomBytes(16).toString('hex'), created_at: new Date().toISOString(), email_status: '', ip };
    d.admissions.push(rec); ctx.save();
    ctx.notify?.(adminIds(), { title: 'New admission request', body: `${o.full_name} – Class ${o.class_applying} (${rec.ref})`, url: '/', tag: 'admission' })?.catch?.(() => { });
    json(res, 200, { ok: true, id: rec.id, token: rec.token, ref: rec.ref });
  });

  routes.push({
    method: 'POST', pat: /^\/api\/site\/admission\/(\d+)\/file$/, roles: false, fn: async ({ req, res, mm, url }) => {
      const ip = ctx.clientIp(req); if (limited('admf:' + ip, 40, 3600e3)) return json(res, 429, { error: 'Too many uploads. Please try again later.' });
      const a = D().admissions.find(x => x.id === Number(mm[1])), kind = url.searchParams.get('kind') || '', tok = url.searchParams.get('token') || '';
      if (!a || !DOC_KINDS[kind] || tok.length !== 32 || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(String(a.token).padEnd(32, '0').slice(0, 32)))) return json(res, 403, { error: 'Upload not allowed' });
      if (a.status !== 'pending' || Date.now() - new Date(a.created_at) > 3 * 3600e3) return json(res, 403, { error: 'This application is closed for uploads' });
      if (a.docs.length >= 8) return json(res, 400, { error: 'Too many documents' });
      const len = Number(req.headers['content-length'] || 0);
      if (!len) return json(res, 411, { error: 'File size is required' });
      if (len > FILE_MAX) return json(res, 413, { error: 'Each file must be under 3 MB' });
      let buf; try { buf = await readRaw(req, FILE_MAX); } catch (e) { return json(res, e.code || 400, { error: 'File is too large' }); }
      const mime = buf.length > 12 ? sniff(buf) : '';
      if (!mime) return json(res, 400, { error: 'Only JPG, PNG, WEBP or PDF files are accepted' });
      const key = `admissions/${a.id}/${kind}-${Date.now()}.${EXT[mime]}`;
      try { await ctx.storage.putBuffer(key, buf, { contentType: mime }); } catch (e) { console.error('Admission file save failed:', e.message); return json(res, 500, { error: 'Could not save the file. Please try again.' }); }
      a.docs = a.docs.filter(x => x.kind !== kind); a.docs.push({ kind, label: DOC_KINDS[kind], key, mime, size: buf.length, name: txt(decodeURIComponent(String(req.headers['x-file-name'] || kind)).replace(/[^\w.\- ]/g, '_'), 80) });
      ctx.save(); json(res, 200, { ok: true });
    }
  });

  /* Customer Messages (admin + clerk) */
  const STAFF = ['admin'];
  route('GET', '/api/admissions', STAFF, async ({ res }) => { S(); json(res, 200, { items: D().admissions.slice().reverse().map(publicView), pending: D().admissions.filter(a => a.status === 'pending').length }); });
  route('GET', '/api/admissions/count', STAFF, async ({ res }) => { S(); json(res, 200, { pending: D().admissions.filter(a => a.status === 'pending').length }); });
  route('GET', /^\/api\/admissions\/(\d+)\/file\/(\d+)$/, STAFF, async ({ res, mm }) => {
    const a = D().admissions.find(x => x.id === Number(mm[1])), f = a && a.docs[Number(mm[2])]; if (!f) return json(res, 404, { error: 'Not found' });
    try { const obj = await ctx.storage.getObject(f.key); res.writeHead(200, { 'Content-Type': f.mime, 'Content-Disposition': `inline; filename="${f.kind}.${EXT[f.mime]}"`, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox" }); obj.Body.pipe(res); }
    catch { json(res, 404, { error: 'The file is unavailable' }); }
  });
  async function deliver(a, u) {
    try { const m = approvalEmail(a); await sendMail(a.email, m.subject, m.html, m.text); a.email_status = 'sent'; a.email_sent_at = new Date().toISOString(); a.email_error = ''; }
    catch (e) { a.email_status = 'failed'; a.email_error = String(e.message || e).slice(0, 220); }
    ctx.save(); return a.email_status;
  }
  route('POST', /^\/api\/admissions\/(\d+)\/approve$/, STAFF, async ({ res, u, mm }) => {
    const a = D().admissions.find(x => x.id === Number(mm[1])); if (!a) return json(res, 404, { error: 'Not found' });
    if (a.status === 'admitted') return json(res, 400, { error: 'Already admitted' });
    a.status = 'approved'; a.reviewed_by = u.name; a.reviewed_at = new Date().toISOString(); a.reject_reason = '';
    ctx.audit(u, 'ADMISSION_APPROVE', `${a.ref} ${a.full_name}`);
    const st = S().email_enabled ? await deliver(a, u) : (a.email_status = 'off', 'off'); ctx.save();
    json(res, 200, { ok: true, email: st, email_error: a.email_error || '', item: publicView(a) });
  });
  route('POST', /^\/api\/admissions\/(\d+)\/reject$/, STAFF, async ({ res, u, mm, v }) => {
    const a = D().admissions.find(x => x.id === Number(mm[1])), b = await v(); if (!a) return json(res, 404, { error: 'Not found' });
    if (a.status === 'admitted') return json(res, 400, { error: 'Already admitted' });
    a.status = 'rejected'; a.reviewed_by = u.name; a.reviewed_at = new Date().toISOString(); a.reject_reason = txt(b.reason, 300);
    ctx.audit(u, 'ADMISSION_REJECT', `${a.ref} ${a.full_name}`); json(res, 200, { ok: true, item: publicView(a) });
  });
  route('POST', /^\/api\/admissions\/(\d+)\/resend$/, STAFF, async ({ res, u, mm }) => {
    const a = D().admissions.find(x => x.id === Number(mm[1])); if (!a || !['approved', 'admitted'].includes(a.status)) return json(res, 400, { error: 'Only approved requests can be e-mailed' });
    const st = await deliver(a, u); ctx.audit(u, 'ADMISSION_EMAIL', `${a.ref} ${st}`); json(res, 200, { ok: st === 'sent', email: st, email_error: a.email_error || '', item: publicView(a) });
  });
  route('POST', /^\/api\/admissions\/(\d+)\/admitted$/, STAFF, async ({ res, u, mm }) => {
    const a = D().admissions.find(x => x.id === Number(mm[1])); if (!a) return json(res, 404, { error: 'Not found' });
    if (a.status !== 'approved') return json(res, 400, { error: 'Approve the request first' });
    a.status = 'admitted'; a.admitted_at = new Date().toISOString(); ctx.audit(u, 'ADMISSION_ADMITTED', `${a.ref} ${a.full_name}`); json(res, 200, { ok: true, item: publicView(a) });
  });
  route('DELETE', /^\/api\/admissions\/(\d+)$/, STAFF, async ({ res, u, mm }) => {
    if (isClerk(u)) return json(res, 403, { error: 'A clerk account cannot delete requests.' });
    const d = D(), a = d.admissions.find(x => x.id === Number(mm[1])); if (!a) return json(res, 404, { error: 'Not found' });
    for (const f of a.docs) { try { await ctx.storage.deleteObject(f.key); } catch { } }
    d.admissions = d.admissions.filter(x => x !== a); ctx.audit(u, 'ADMISSION_DELETE', a.ref); json(res, 200, { ok: true });
  });

  /* Website & Admissions settings (administrator only, not clerk) */
  const settingsView = () => { const s = S(); return { contact_phone: s.contact_phone, school_email: s.school_email, gmail_user: s.gmail_user, gmail_pass_set: !!s.gmail_pass, gmail_pass_last4: s.gmail_pass ? s.gmail_pass.replace(/\s/g, '').slice(-4) : '', email_enabled: s.email_enabled, email_subject: s.email_subject, email_body: s.email_body, application_note: s.application_note, mail_provider: s.mail_provider, brevo_ready: !!(ctx.emailReady && ctx.emailReady()), brevo_sender: (ctx.emailSender && ctx.emailSender()) || '' }; };
  route('GET', '/api/site/settings', STAFF, async ({ res, u }) => { if (isClerk(u)) return json(res, 403, { error: 'Only the administrator can open these settings.' }); json(res, 200, settingsView()); });
  route('PUT', '/api/site/settings', STAFF, async ({ res, u, v }) => {
    if (isClerk(u)) return json(res, 403, { error: 'Only the administrator can change these settings.' });
    const b = await v(), s = S();
    const phone = txt(b.contact_phone, 25); if (!/^\+?[\d\s\-()]{7,20}$/.test(phone)) return json(res, 400, { error: 'Enter a valid contact phone number, for example +91 93322 80028' });
    const gm = txt(b.gmail_user, 120).toLowerCase(); if (gm && !emailOk(gm)) return json(res, 400, { error: 'The sender Gmail address is not valid' });
    const se = txt(b.school_email, 120); if (se && !emailOk(se)) return json(res, 400, { error: 'The school e-mail shown on the website is not valid' });
    s.contact_phone = phone; s.school_email = se; s.gmail_user = gm; s.email_enabled = b.email_enabled !== false && b.email_enabled !== 'off';
    s.mail_provider = ['auto', 'gmail', 'brevo'].includes(b.mail_provider) ? b.mail_provider : 'auto';
    if (b.clear_gmail_pass === true) s.gmail_pass = '';
    else if (String(b.gmail_pass || '').trim()) s.gmail_pass = String(b.gmail_pass).replace(/\s+/g, '').slice(0, 64);
    s.email_subject = txt(b.email_subject, 150) || 'Your admission request is approved – Holyfaith Academy';
    s.email_body = String(b.email_body ?? '').slice(0, 3000).trim() || DEFAULT_BODY; s.application_note = txt(b.application_note, 200);
    ctx.audit(u, 'SET_SITE_SETTINGS', `phone ${s.contact_phone}, mail via ${s.mail_provider}`); json(res, 200, { ok: true, settings: settingsView() });
  });
  route('POST', '/api/site/settings/test', STAFF, async ({ res, u, v }) => {
    if (isClerk(u)) return json(res, 403, { error: 'Only the administrator can send a test.' });
    const b = await v(), to = txt(b.email, 120); if (!emailOk(to)) return json(res, 400, { error: 'Enter a valid e-mail address to send the test to' });
    try { const m = approvalEmail({ ref: 'ADM-TEST-0000', full_name: 'Test Student', father_name: 'Parent', class_applying: 'V' }); await sendMail(to, '[TEST] ' + m.subject, m.html, m.text); json(res, 200, { ok: true }); }
    catch (e) { json(res, 502, { error: e.message }); }
  });

  /* ---------- public website files ---------- */
  const SITE_FILE = /^(index\.html|site\.css|site\.js|img\/[A-Za-z0-9._-]+\.(?:jpg|png|webp))$/;
  async function serveSite(req, res, p) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return false;
    if (p === '/site') { res.writeHead(302, { Location: '/site/' }); res.end(); return true; }
    if (!p.startsWith('/site/')) return false;
    const rel = p === '/site/' ? 'index.html' : p.slice(6);
    if (!SITE_FILE.test(rel)) { json(res, 404, { error: 'Not found' }); return true; }
    const b = ctx.asset('site/' + rel); if (!b) { json(res, 404, { error: 'Not found' }); return true; }
    ctx.send(res, 200, b, { 'Content-Type': ctx.mime[path.extname(rel)] || 'text/plain', 'Cache-Control': rel.startsWith('img/') ? 'public, max-age=86400' : 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    return true;
  }
  async function handle(req, res, p, url) {
    if (await serveSite(req, res, p)) return true;
    if (!p.startsWith('/api/site/') && !p.startsWith('/api/admissions')) return false;
    for (const r of routes) {
      if (r.method !== req.method) continue; const mm = p.match(r.pat); if (!mm) continue;
      let u = null; if (r.roles !== false) { u = await ctx.auth(req, res, r.roles || []); if (!u) return true; }
      try { await r.fn({ req, res, u, mm, url, p, v: () => ctx.body(req) }); }
      catch (e) { console.error('Site route error', p, e); if (!res.headersSent) json(res, 500, { error: 'Something went wrong. Please try again.' }); }
      return true;
    }
    return false;
  }
  return { handle, _test: { smtpSend, buildMime, approvalEmail, validateForm, sniff } };
};

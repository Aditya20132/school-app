/* SchoolHub: Customer Messages (online admission requests) + Website Settings. Loaded after v10.js. */
(function () {
  'use strict';
  const E = v => String(v == null ? '' : v).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  const CM = 'Customer Messages', WS = 'Website Settings';
  const fmt = d => { try { return new Date(d).toLocaleString([], { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) } catch { return d || '' } };
  let filter = 'pending', items = [];

  /* ---------- navigation entries (administrator and clerk both have role "admin") ---------- */
  try {
    const list = V8000_NAV && V8000_NAV.admin;
    if (list) {
      if (!list.some(x => x[1] === CM)) { let i = -1; list.forEach((x, k) => { if (x[0] === 'Communication') i = k }); i < 0 ? list.push(['Communication', CM]) : list.splice(i + 1, 0, ['Communication', CM]); }
      if (!list.some(x => x[1] === WS)) { let i = -1; list.forEach((x, k) => { if (x[0] === 'System') i = k }); i < 0 ? list.push(['System', WS]) : list.splice(i, 0, ['System', WS]); }
    }
    if (typeof V8000_ICONS === 'object') Object.assign(V8000_ICONS, { [CM]: '✉', [WS]: '🌐' });
  } catch (e) { console.warn('site-admin nav', e); }

  const _show = show;
  show = async function (p) {
    if (p === CM) { setActive(p); try { return await renderCM() } catch (e) { toast(e.message) } return; }
    if (p === WS) { setActive(p); try { return await renderWS() } catch (e) { toast(e.message) } return; }
    return _show.apply(this, arguments);
  };

  /* ---------- badge with the number of waiting requests ---------- */
  async function badge() {
    if (typeof me === 'undefined' || !me || me.role !== 'admin') return;
    try {
      const c = await api('/api/admissions/count'), b = document.querySelector('#nav button[data-page="' + CM + '"]'); if (!b) return;
      let s = b.querySelector('.cm-badge'); if (!c.pending) { s && s.remove(); return; }
      if (!s) { s = document.createElement('span'); s.className = 'cm-badge'; b.appendChild(s); } s.textContent = c.pending;
    } catch { }
  }
  const _rn = renderNav;
  renderNav = function () { _rn.apply(this, arguments); setTimeout(badge, 150); };
  setInterval(badge, 45000);

  /* ---------- Customer Messages ---------- */
  const STATUS = { pending: ['Waiting for approval', 'cm-st-pending'], approved: ['Approved', 'cm-st-ok'], rejected: ['Rejected', 'cm-st-no'], admitted: ['Admitted', 'cm-st-adm'] };
  const row = (k, v) => v ? `<div><span>${k}</span>${E(v)}</div>` : '';
  function card(a) {
    const st = STATUS[a.status] || ['', ''];
    const docs = (a.docs || []).map((d, i) => `<a class="cm-doc" target="_blank" rel="noopener" href="/api/admissions/${a.id}/file/${i}">${E(d.label)}</a>`).join('') || '<em class="muted">No documents uploaded</em>';
    const mail = a.status === 'approved' || a.status === 'admitted' ? (a.email_status === 'sent' ? `<div class="cm-mail ok">✓ Approval e-mail sent ${E(fmt(a.email_sent_at))}</div>` : a.email_status === 'failed' ? `<div class="cm-mail bad">E-mail not sent: ${E(a.email_error)}</div>` : a.email_status === 'off' ? '<div class="cm-mail bad">E-mail sending is switched off in Website Settings</div>' : '') : '';
    const btn = (cls, act, t) => `<button class="cm-btn ${cls}" data-act="${act}" data-id="${a.id}">${t}</button>`;
    let acts = '';
    if (a.status === 'pending') acts = btn('go', 'approve', '✓ Approve') + btn('no', 'reject', 'Reject');
    if (a.status === 'approved') acts = btn('go', 'admit', 'Admit as student') + btn('', 'admitted', 'Mark as admitted') + btn('', 'resend', a.email_status === 'sent' ? 'Resend e-mail' : 'Send e-mail again') + btn('no', 'reject', 'Reject');
    if (a.status === 'rejected') acts = btn('go', 'approve', 'Approve instead');
    if (a.status === 'admitted') acts = btn('', 'resend', 'Resend e-mail');
    if (a.status !== 'admitted') acts += '';
    return `<article class="cm-card panel" id="cm${a.id}">
      <div class="cm-msg"><div class="cm-from"><b>${E(a.full_name)}</b><small>${E(a.ref)} · ${E(fmt(a.created_at))}</small></div>
        <div class="cm-bubble">${a.message ? E(a.message).replace(/\n/g, '<br>') : '<em class="muted">No message written. The family only filled in the admission form.</em>'}</div>
        <div class="cm-contact"><a href="tel:${E(a.mobile)}">☎ ${E(a.mobile)}</a> <a href="mailto:${E(a.email)}">✉ ${E(a.email)}</a></div>
        <span class="cm-st ${st[1]}">${st[0]}</span>${a.status === 'rejected' && a.reject_reason ? `<div class="cm-mail bad">Reason: ${E(a.reject_reason)}</div>` : ''}${a.reviewed_by ? `<div class="muted" style="font-size:12px;margin-top:6px">Reviewed by ${E(a.reviewed_by)} · ${E(fmt(a.reviewed_at))}</div>` : ''}${mail}</div>
      <div class="cm-info"><h4>Student information</h4><div class="cm-grid">
        ${row('Full name', a.full_name)}${row('Date of birth', a.dob)}${row('Gender', a.gender)}${row('Aadhaar', a.aadhaar)}${row('Class applying for', a.class_applying)}${row('Admission type', a.stay_type)}
        ${row("Father's name", a.father_name)}${row("Mother's name", a.mother_name)}${row('Parent mobile', a.mobile)}${row('Emergency contact', a.emergency_contact)}${row('Email', a.email)}${row('Blood group', a.blood_group)}
        ${row('Previous school', a.prev_school)}${row('Previous class', a.prev_class)}${row('Last grade', a.last_grade)}${row('Score / percentage', a.score)}
        <div class="full"><span>Home address</span>${E(a.address)}</div></div>
        <h4>Documents</h4><div class="cm-docs">${docs}</div>
        <div class="cm-acts">${acts}</div></div></article>`;
  }
  async function renderCM() {
    const r = await api('/api/admissions'); items = r.items || [];
    const n = s => items.filter(a => a.status === s).length;
    const tabs = [['pending', 'Waiting'], ['approved', 'Approved'], ['admitted', 'Admitted'], ['rejected', 'Rejected'], ['all', 'All']].map(([k, l]) => `<button class="cm-tab ${filter === k ? 'on' : ''}" data-f="${k}">${l}${k !== 'all' ? ` <b>${n(k)}</b>` : ` <b>${items.length}</b>`}</button>`).join('');
    const shown = items.filter(a => filter === 'all' || a.status === filter);
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Customer messages</h3><p class="muted">Admission requests sent from the school website. Approve a request to e-mail the family, then call them and admit the student in one tap.</p></div><button class="cm-btn" id="cmRefresh">↻ Refresh</button></div><div class="cm-tabs">${tabs}</div></div>
      <div id="cmList">${shown.length ? shown.map(card).join('') : `<div class="panel"><p class="muted" style="margin:0">${filter === 'pending' ? 'No requests are waiting. New admission requests appear here as soon as they are submitted.' : 'Nothing in this list.'}</p></div>`}</div>`;
    document.querySelectorAll('.cm-tab').forEach(b => b.onclick = () => { filter = b.dataset.f; renderCM() });
    $('#cmRefresh').onclick = () => renderCM();
    $('#cmList').onclick = onAct; badge();
  }
  async function onAct(ev) {
    const b = ev.target.closest('[data-act]'); if (!b) return;
    const id = Number(b.dataset.id), a = items.find(x => x.id === id), act = b.dataset.act; if (!a) return;
    try {
      if (act === 'approve') {
        if (!confirm(`Approve admission for ${a.full_name}?\n\nAn e-mail will be sent to ${a.email}.`)) return;
        b.disabled = true; b.textContent = 'Approving…';
        const r = await api(`/api/admissions/${id}/approve`, { method: 'POST', body: '{}' });
        toast(r.email === 'sent' ? 'Approved. E-mail sent to the family.' : 'Approved, but the e-mail was not sent: ' + (r.email_error || r.email));
        filter = 'approved'; return renderCM();
      }
      if (act === 'reject') { const reason = prompt(`Reject ${a.full_name}? You can write a short reason (optional):`, ''); if (reason === null) return; await api(`/api/admissions/${id}/reject`, { method: 'POST', body: JSON.stringify({ reason }) }); toast('Request rejected'); filter = 'rejected'; return renderCM(); }
      if (act === 'resend') { b.disabled = true; b.textContent = 'Sending…'; const r = await api(`/api/admissions/${id}/resend`, { method: 'POST', body: '{}' }); toast(r.ok ? 'E-mail sent' : 'E-mail failed: ' + r.email_error); return renderCM(); }
      if (act === 'admitted') { if (!confirm('Mark this student as admitted?')) return; await api(`/api/admissions/${id}/admitted`, { method: 'POST', body: '{}' }); toast('Marked as admitted'); filter = 'admitted'; return renderCM(); }
      if (act === 'admit') return admit(a);
    } catch (e) { toast(e.message); renderCM(); }
  }
  const romans = { i: 1, ii: 2, iii: 3, iv: 4, v: 5, vi: 6, vii: 7, viii: 8, ix: 9, x: 10, xi: 11, xii: 12 };
  const norm = s => { let t = String(s || '').toLowerCase().replace(/class|std|standard|grade|[^a-z0-9]/g, ''); return romans[t] ? String(romans[t]) : t; };
  async function admit(a) {
    await studentForm();
    const q = n => document.querySelector(`#content [name="${n}"], [name="${n}"]`), set = (n, v) => { const el = q(n); if (el && v) el.value = v; };
    set('student_id', a.ref); set('name', a.full_name); set('dob', a.dob); set('gender', a.gender); set('guardian_name', a.father_name || a.mother_name);
    set('guardian_phone', a.mobile); set('phone', a.mobile); set('email', a.email); set('address', a.address); set('admission_date', new Date().toISOString().slice(0, 10));
    const cs = q('class_id'); if (cs) { const want = norm(a.class_applying); const o = [...cs.options].find(x => norm(x.textContent) === want); if (o) { cs.value = o.value; cs.dispatchEvent(new Event('change', { bubbles: true })); } }
    scrollTo({ top: 0, behavior: 'smooth' });
    toast('Details filled in. Check the section, save the student, then tap "Mark as admitted".');
  }

  /* ---------- Website Settings (administrator only) ---------- */
  async function renderWS() {
    let s; try { s = await api('/api/site/settings') } catch (e) { $('#content').innerHTML = `<div class="panel"><h3>Website &amp; Admissions</h3><p class="muted">${E(e.message)}</p></div>`; return; }
    $('#content').innerHTML = `<div class="panel"><div class="panel-head"><div><h3>Website &amp; admissions</h3><p class="muted">Your public website is at <a href="/site/" target="_blank" rel="noopener"><b>${E(location.origin)}/site/</b></a>. The number below is shown on the website and on the "Contact Us" button in the approval e-mail.</p></div></div>
      <form id="wsForm" class="ws-form">
        <label>Contact phone number<input name="contact_phone" value="${E(s.contact_phone)}" required placeholder="+91 93322 80028"></label>
        <label>School e-mail shown on the website<input name="school_email" type="email" value="${E(s.school_email)}"></label>
        <label>Application note (optional, shown on the admission form)<input name="application_note" value="${E(s.application_note)}" maxlength="200" placeholder="e.g. Admission test on 5 January"></label>
        <h4>Approval e-mail</h4>
        <label>Send the e-mail through
          <select name="mail_provider"><option value="auto" ${s.mail_provider === 'auto' ? 'selected' : ''}>Automatic (Gmail if a password is saved, otherwise Brevo)</option><option value="brevo" ${s.mail_provider === 'brevo' ? 'selected' : ''}>Brevo (recommended if Gmail fails)</option><option value="gmail" ${s.mail_provider === 'gmail' ? 'selected' : ''}>Gmail only</option></select></label>
        <p class="muted ws-help">${s.brevo_ready ? `Brevo is ready. E-mails sent through Brevo come from <b>${E(s.brevo_sender)}</b> (change it in Settings → E-mail (Brevo)).` : 'Brevo is not set up yet. Set it up in Settings → E-mail (Brevo): API key and a verified sender.'}</p>
        <label class="ws-check"><input type="checkbox" name="email_enabled" ${s.email_enabled ? 'checked' : ''}> Send an e-mail to the family when a request is approved</label>
        <label>Send from Gmail address<input name="gmail_user" type="email" value="${E(s.gmail_user)}" placeholder="holyfaithacademy096@gmail.com"></label>
        <label>Gmail App Password ${s.gmail_pass_set ? `<span class="ws-ok">saved (ends ${E(s.gmail_pass_last4)})</span>` : '<span class="ws-warn">not saved yet</span>'}<input name="gmail_pass" type="password" autocomplete="new-password" placeholder="${s.gmail_pass_set ? 'Leave empty to keep the saved one' : '16-character App Password'}"></label>
        ${s.gmail_pass_set ? '<label class="ws-check"><input type="checkbox" name="clear_gmail_pass"> Remove the saved Gmail App Password</label>' : ''}
        <p class="muted ws-help">Gmail does not accept the normal password here. In that Google account turn on 2-Step Verification, open <b>Google Account → Security → App passwords</b>, create one named "SchoolHub", and paste the 16 characters above.</p>
        <label>E-mail subject<input name="email_subject" value="${E(s.email_subject)}" maxlength="150"></label>
        <label>E-mail message<textarea name="email_body" rows="11">${E(s.email_body)}</textarea></label>
        <p class="muted ws-help">You can use {parent}, {student}, {class}, {ref} and {phone}. A "Contact Us" button showing your phone number is added under the message automatically.</p>
        <div class="ws-acts"><button class="cm-btn go" type="submit">Save settings</button><input id="wsTo" type="email" placeholder="Send a test e-mail to…"><button class="cm-btn" type="button" id="wsTest">Send test e-mail</button></div>
      </form></div>`;
    $('#wsForm').onsubmit = async e => {
      e.preventDefault(); const f = new FormData(e.target), o = Object.fromEntries(f.entries()); o.email_enabled = f.has('email_enabled'); o.clear_gmail_pass = f.has('clear_gmail_pass');
      try { await api('/api/site/settings', { method: 'PUT', body: JSON.stringify(o) }); toast('Settings saved'); renderWS(); } catch (er) { toast(er.message) }
    };
    $('#wsTest').onclick = async () => { const to = $('#wsTo').value.trim(); if (!to) return toast('Type an e-mail address for the test'); $('#wsTest').disabled = true; try { await api('/api/site/settings/test', { method: 'POST', body: JSON.stringify({ email: to }) }); toast('Test e-mail sent. Check the inbox (and spam).'); } catch (er) { toast(er.message) } $('#wsTest').disabled = false; };
  }

  /* ---------- sign-in screen: website + admission links ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    const f = document.querySelector('.portal-footer'); if (!f || document.getElementById('siteLinks')) return;
    f.insertAdjacentHTML('beforebegin', '<div class="site-links" id="siteLinks"><a class="site-visit" href="/site/" target="_blank" rel="noopener">Visit our website</a><a class="site-adm" href="/site/#/admission" target="_blank" rel="noopener">Get Admission</a></div>');
  });
})();

/* SchoolHub dashboard clock: a digital clock on every dashboard (admin, teacher, guardian).
   Besides showing the time, it asks the server to generate any monthly fees that have fallen due:
   when the dashboard opens, when the date changes (midnight / the 1st of a month), and every 10 minutes. */
(function () {
  if (window.__shClock) return; window.__shClock = 1;
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const p2 = n => String(n).padStart(2, '0');
  let timer = null, lastDay = '', lastSync = 0, busy = false, status = { cls: 'busy', text: 'Checking monthly fees…' };

  const dayKey = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());

  function paintTime() {
    const el = document.getElementById('shClock'); if (!el) return false;
    const d = new Date(), h = d.getHours(), h12 = h % 12 || 12;
    el.querySelector('.sh-clock-hm').textContent = p2(h12) + ':' + p2(d.getMinutes());
    el.querySelector('.sh-clock-sec').textContent = ':' + p2(d.getSeconds());
    el.querySelector('.sh-clock-ampm').textContent = h < 12 ? 'AM' : 'PM';
    el.querySelector('.sh-clock-date').textContent = DAYS[d.getDay()] + ', ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    return true;
  }
  function paintStatus() {
    const f = document.querySelector('#shClock .sh-clock-fee'); if (!f) return;
    f.className = 'sh-clock-fee ' + status.cls; f.querySelector('span').textContent = status.text;
  }

  async function sync() {
    if (busy) return; busy = true; lastSync = Date.now();
    status = { cls: 'busy', text: 'Checking monthly fees…' }; paintStatus();
    try {
      const r = await api('/api/clock');
      const isAdmin = me && me.role === 'admin';
      if (r.changed) {
        try { clear('fees', 'dashboard', 'students'); } catch { }
        status = { cls: 'new', text: isAdmin && r.created ? r.created + ' new monthly fee record' + (r.created === 1 ? '' : 's') + ' generated for ' + r.month_label : 'Monthly fees for ' + r.month_label + ' have been added' };
        if (isAdmin && typeof toast === 'function') toast(status.text);
        busy = false; paintStatus();
        if (document.getElementById('shClock')) { dashboard(); return; } /* refresh figures once; the new clock syncs again and finds nothing left to create */
      } else {
        status = { cls: '', text: 'Monthly fees are up to date for ' + r.month_label };
      }
    } catch (e) {
      status = { cls: 'err', text: 'Could not check monthly fees. Will retry shortly.' };
      lastSync = Date.now() - 9 * 60 * 1000; /* retry in about a minute */
    }
    busy = false; paintStatus();
  }

  function tick() {
    if (!paintTime()) { clearInterval(timer); timer = null; return; } /* dashboard closed */
    const dk = dayKey(new Date());
    if (dk !== lastDay) { lastDay = dk; sync(); }
    else if (Date.now() - lastSync > 10 * 60 * 1000) sync();
  }

  function mount() {
    document.getElementById('shClock')?.remove();
    const box = document.createElement('div');
    box.id = 'shClock'; box.className = 'sh-clock'; box.setAttribute('role', 'timer'); box.setAttribute('aria-label', 'Current time');
    box.innerHTML = '<div><div class="sh-clock-time"><span class="sh-clock-digits"><span class="sh-clock-hm">--:--</span><span class="sh-clock-sec">:--</span></span><span class="sh-clock-ampm"></span></div><div class="sh-clock-date"></div></div><div class="sh-clock-fee busy"><i></i><span>Checking monthly fees…</span></div>';
    const content = document.getElementById('content'); if (!content) return;
    const banner = content.querySelector('.portal-banner');
    if (banner) banner.insertAdjacentElement('afterend', box); else content.insertAdjacentElement('afterbegin', box);
    paintTime(); paintStatus();
    lastDay = dayKey(new Date()); sync();
    if (!timer) timer = setInterval(tick, 1000);
  }

  const _dash = dashboard;
  dashboard = async function () {
    await _dash.apply(this, arguments);
    if (typeof me === 'undefined' || !me) return;
    mount();
  };
})();

/* SchoolHub service worker: push notifications + a tiny offline fallback.
   It never caches API responses or pages that hold personal data. */
const SHELL = 'schoolhub-shell-v1';
const OFFLINE = '/offline.html';
self.addEventListener('install', e => { e.waitUntil(caches.open(SHELL).then(c => c.put(OFFLINE, new Response(
  '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title><body style="font-family:system-ui,sans-serif;text-align:center;padding:12vh 24px;color:#222"><h2>You are offline</h2><p>SchoolHub needs an internet connection. Please check your connection and try again.</p><button onclick="location.reload()" style="padding:10px 18px;font-size:16px">Try again</button></body>',
  { headers: { 'Content-Type': 'text/html; charset=utf-8' } }))).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== SHELL).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request; if (r.mode !== 'navigate') return;
  e.respondWith(fetch(r).catch(() => caches.match(OFFLINE)));
});
self.addEventListener('push', e => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch { d = { title: 'SchoolHub', body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'SchoolHub', { body: d.body || '', icon: '/assets/icon-192.png', badge: '/assets/icon-192.png', tag: d.tag || 'schoolhub', data: { url: d.url || '/' } }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close(); const url = (e.notification.data && e.notification.data.url) || '/';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const c of list) if ('focus' in c) { c.navigate(url).catch(() => { }); return c.focus(); }
    return self.clients.openWindow(url);
  }));
});

/* SchoolHub V10 pack (browser): notifications/PWA, online payment, fee reminders, exam timetable + admit cards,
   payroll, student diary, syllabus tracker, photo gallery, login security (2FA) and Hindi/Bengali switch.
   Loaded after app.js, premium.js and features.js; it extends their navigation and page registry. */
(function () {
  'use strict';
  const Q = s => document.querySelector(s);
  const E = x => String(x ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  const money = n => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const J = (url, method, body) => api(url, { method: method || 'POST', body: JSON.stringify(body || {}) });
  const fdate = iso => { if (!iso) return ''; const d = new Date(String(iso).slice(0, 10) + 'T00:00:00'); return isNaN(d) ? iso : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); };
  const ftime = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); };
  const todayIso = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  const opts = (list, sel, blank) => (blank !== undefined ? `<option value="">${E(blank)}</option>` : '') + list.map(o => `<option value="${E(o.id ?? o.value)}"${String(o.id ?? o.value) === String(sel) ? ' selected' : ''}>${E(o.name ?? o.label)}</option>`).join('');
  const panel = (title, sub, actions, body) => `<div class="panel"><div class="panel-head"><div><h3>${E(title)}</h3>${sub ? `<p class="muted">${sub}</p>` : ''}</div><div class="v1-row">${actions || ''}</div></div>${body}</div>`;
  const tbl = (head, rows, empty) => rows.length ? `<div class="table-wrap"><table class="table"><thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>` : `<p class="muted" style="padding:14px 4px">${empty || 'Nothing here yet.'}</p>`;
  const clsName = n => /^\d+$/.test(String(n || '')) ? 'Class ' + n : String(n || '');
  const chip = (t, kind) => `<span class="v1-chip ${kind || ''}">${E(t)}</span>`;
  const content = () => Q('#content');
  const val = id => { const e = document.getElementById(id); return e ? e.value : ''; };
  const chk = id => { const e = document.getElementById(id); return !!(e && e.checked); };
  const guard = fn => async (...a) => { try { return await fn(...a) } catch (e) { toast(e.message || 'Something went wrong') } };
  /* own modal + print helpers (the app's are private to the library module); styled by the existing .lib-modal theme rules */
  const closeModal = () => document.querySelectorAll('.v1-modal').forEach(x => x.remove());
  const modal = (title, html, wide) => {
    closeModal(); const m = document.createElement('div'); m.className = 'lib-modal v1-modal';
    m.innerHTML = `<div class="lib-modal-card${wide ? ' wide' : ''}" role="dialog" aria-modal="true"><div class="lib-modal-head"><h3>${E(title)}</h3><button type="button" class="smallbtn" data-x>Close</button></div><div class="lib-modal-body">${html}</div></div>`;
    m.addEventListener('mousedown', e => { if (e.target === m) closeModal() }); m.querySelector('[data-x]').onclick = closeModal; document.body.append(m); return m;
  };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal() });
  const printHtml = (title, body) => { const w = window.open('', '_blank', 'width=800,height=700'); if (!w) return toast('Allow pop-ups to print'); w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${E(title)}</title><style>body{font-family:Arial,sans-serif;margin:28px;color:#111}h1{font-size:20px;margin:0}h2{font-size:15px;margin:2px 0 16px;color:#444}</style></head><body>${body}<script>window.onload=()=>setTimeout(()=>window.print(),300)<\/script></body></html>`); w.document.close() };

  /* ================= navigation ================= */
  const VNAV = {
    admin: [['Finance', 'Online Payments'], ['Finance', 'Fee Reminders'], ['Academic', 'Exam Timetable'], ['Academic', 'Syllabus Tracker'], ['People', 'Payroll'], ['Communication', 'Student Diary'], ['Communication', 'Photo Gallery'], ['System', 'Login Security']],
    teacher: [['Teaching', 'Exam Timetable'], ['Teaching', 'Syllabus Tracker'], ['Teaching', 'Student Diary'], ['My Work', 'My Payslips'], ['Communication', 'Photo Gallery']],
    guardian: [['My Family', 'Pay Online'], ['My Family', 'Student Diary'], ['School', 'Exam Timetable'], ['School', 'Syllabus Tracker'], ['Communication', 'Photo Gallery']]
  };
  /* glyphs chosen from the set premium.js knows, so each item gets a proper line icon */
  Object.assign(V8000_ICONS, { 'Online Payments': '💳', 'Pay Online': '💳', 'Fee Reminders': '⏰', 'Exam Timetable': '▦', 'Syllabus Tracker': '📚', 'Payroll': '💼', 'My Payslips': '💼', 'Student Diary': '📖', 'Photo Gallery': '✦', 'Login Security': '🔑', 'Pay by UPI': '💳', 'Student Ledger': '📄', 'Payment Log': '↩', 'Attendance Alerts': '⚠', 'Safety & Roles': '🔑' });
  for (const role of Object.keys(VNAV)) {
    const list = V8000_NAV[role]; if (!list) continue;
    for (const [g, n] of VNAV[role]) {
      if (list.some(x => x[1] === n)) continue;
      let idx = -1; list.forEach((x, i) => { if (x[0] === g) idx = i });
      if (idx < 0) list.push([g, n]); else list.splice(idx + 1, 0, [g, n]);
    }
  }
  /* line icons (24px grid, same style as premium.js) for pages the theme layer has no icon for */
  const IC = {
    card: '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 10h18M7 15h4"/>',
    bell: '<path d="M6 17v-6a6 6 0 0 1 12 0v6l1.500 2h-15z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
    exam: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M8.500 10h7M8.500 14h7M8.500 18h4"/>',
    list: '<path d="M4.500 6.500 6 8l2.500-2.500M4.500 12.500 6 14l2.500-2.500M4.500 18.500 6 20l2.500-2.500"/><path d="M12 7h8M12 13h8M12 19h8"/>',
    cash: '<rect x="3" y="6.500" width="18" height="11" rx="2"/><circle cx="12" cy="12" r="2.600"/><path d="M6.500 9.500h.01M17.500 14.500h.01"/>',
    diary: '<rect x="5.500" y="3.500" width="13" height="17" rx="2"/><path d="M9 3.500v17M12 8.500h4M12 12h4"/>',
    photo: '<rect x="3.500" y="5" width="17" height="14" rx="2.500"/><circle cx="9" cy="10.500" r="1.600"/><path d="m4 17 5-4.500 4 3.500 3-2.500 4 3.500"/>',
    shield: '<path d="M12 3.500 5 6v5.500c0 4.300 3 7.400 7 9 4-1.600 7-4.700 7-9V6z"/><path d="m9 12 2.200 2.200L15.500 10"/>',
    doc: '<path d="M6 4h9l3 3v13H6z"/><path d="M9 11h6M9 15h6"/>',
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    book: '<path d="M5 4.500h11a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>',
    check: '<circle cx="12" cy="12" r="8.500"/><path d="m8.500 12.200 2.400 2.400 4.600-4.800"/>'
  };
  const NAVICO = { 'Online Payments': IC.card, 'Pay Online': IC.card, 'Pay by UPI': IC.card, 'Fee Reminders': IC.bell, 'Attendance Alerts': IC.bell, 'Exam Timetable': IC.exam, 'Syllabus Tracker': IC.list, 'Payroll': IC.cash, 'My Payslips': IC.cash, 'Student Diary': IC.diary, 'Photo Gallery': IC.photo, 'Login Security': IC.shield, 'Safety & Roles': IC.shield, 'Student Ledger': IC.doc, 'Payment Log': IC.undo, 'Day Book': IC.book, 'Payment Proofs': IC.check };
  function navIcons() {
    document.querySelectorAll('#nav button[data-page]').forEach(b => {
      const n = NAVICO[b.dataset.page]; if (!n) return; let ic = b.querySelector('.nav-ico');
      if (!ic) { ic = document.createElement('span'); ic.className = 'nav-ico'; b.insertBefore(ic, b.firstChild) }
      if (ic.getAttribute('data-v1') === b.dataset.page) return;
      ic.setAttribute('data-n', 'info'); ic.setAttribute('data-v1', b.dataset.page); ic.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${n}</svg>`;
    });
  }
  { const nv = Q('#nav'); if (nv) new MutationObserver(navIcons).observe(nv, { childList: true, subtree: true }); }
  const PAGES = {};
  const _show = show;
  show = async function (p) {
    if (PAGES[p]) { setActive(p); try { return await PAGES[p]() } catch (e) { toast(e.message) } return; }
    return _show.apply(this, arguments);
  };
  const _renderNav = renderNav;
  renderNav = function () {
    _renderNav.apply(this, arguments);
    if (!me) return;
    mountHeader(); navIcons();
    if (me.role === 'admin') api('/api/features/context').then(c => { if (c && c.clerk) document.querySelectorAll('#nav button').forEach(b => { if (['Payroll', 'Fee Reminders'].includes(b.dataset.page)) b.remove() }) }).catch(() => { });
    if (!window.__v1Booted) { window.__v1Booted = true; afterLogin(); }
    i18nApply(document.body);
  };

  /* ================= service worker, install prompt, notifications ================= */
  let deferredInstall = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; });
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => { }));
  const b64u = s => { const p = '='.repeat((4 - s.length % 4) % 4), b = (s + p).replace(/-/g, '+').replace(/_/g, '/'), r = atob(b); return Uint8Array.from([...r].map(c => c.charCodeAt(0))) };
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent), standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  async function pushState() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return 'unsupported';
    if (Notification.permission === 'denied') return 'blocked';
    try { const reg = await navigator.serviceWorker.getRegistration(); const sub = reg && await reg.pushManager.getSubscription(); return sub && Notification.permission === 'granted' ? 'on' : 'off' } catch { return 'off' }
  }
  async function enablePush() {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return toast(isIos && !standalone ? 'On iPhone: tap Share, then Add to Home Screen, open the app from the home screen and try again.' : 'This browser does not support phone notifications.');
    const perm = await Notification.requestPermission(); if (perm !== 'granted') return toast('Notifications are blocked. Allow them in your browser settings for this site.');
    const k = await api('/api/push/key'); if (!k.enabled) return toast('Notifications are not available on this server.');
    const reg = await navigator.serviceWorker.ready; let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(k.publicKey) });
    await J('/api/push/subscribe', 'POST', { subscription: sub.toJSON() }); await J('/api/push/test'); toast('Notifications are on for this device');
  }
  async function disablePush() { const reg = await navigator.serviceWorker.getRegistration(); const sub = reg && await reg.pushManager.getSubscription(); if (sub) { await J('/api/push/unsubscribe', 'POST', { endpoint: sub.endpoint }); await sub.unsubscribe() } toast('Notifications are off for this device') }
  let notifTimer = null;
  async function refreshBell() { try { const r = await api('/api/notifications'); const n = Q('#v1BellN'); if (n) { n.textContent = r.unread > 9 ? '9+' : r.unread; n.classList.toggle('hidden', !r.unread) } return r } catch { return null } }
  async function openNotif() {
    let box = Q('#v1Notif'); if (box) { box.remove(); return }
    box = document.createElement('div'); box.id = 'v1Notif'; box.innerHTML = '<p class="muted">Loading…</p>'; document.body.append(box);
    const r = await refreshBell(), st = await pushState(); if (!r) { box.innerHTML = '<p class="muted">Could not load notifications.</p>'; return }
    const act = [];
    if (st === 'off') act.push('<button class="smallbtn" data-v1="pushon">Turn on phone notifications</button>');
    if (st === 'on') act.push('<button class="smallbtn" data-v1="pushoff">Turn off on this device</button>');
    if (st === 'blocked') act.push('<span class="muted" style="font-size:12px">Notifications are blocked in your browser settings.</span>');
    if (st === 'unsupported' && isIos && !standalone) act.push('<span class="muted" style="font-size:12px">On iPhone: tap Share → Add to Home Screen, then open the app to turn on notifications.</span>');
    if (deferredInstall) act.push('<button class="smallbtn" data-v1="install">Install app</button>');
    box.innerHTML = `<div class="v1-row" style="justify-content:space-between;margin-bottom:6px"><b>Notifications</b>${r.unread ? '<button class="smallbtn" data-v1="readall">Mark all read</button>' : ''}</div><div class="v1-row" style="margin-bottom:8px">${act.join('')}</div>` +
      (r.rows.length ? r.rows.map(n => `<div class="it ${n.read ? '' : 'un'}" data-url="${E(n.url)}"><b>${E(n.title)}</b><span>${E(n.body)}</span><small>${E(ftime(n.at))}</small></div>`).join('') : '<p class="muted">No notifications yet.</p>');
    box.onclick = guard(async e => {
      const b = e.target.closest('[data-v1]'), it = e.target.closest('.it');
      if (b) { const a = b.dataset.v1; if (a === 'pushon') { await enablePush(); box.remove() } else if (a === 'pushoff') { await disablePush(); box.remove() } else if (a === 'install') { deferredInstall.prompt(); deferredInstall = null; box.remove() } else if (a === 'readall') { await J('/api/notifications/read'); box.remove(); refreshBell() } return }
      if (it) { box.remove(); await J('/api/notifications/read'); refreshBell(); goUrl(it.dataset.url) }
    });
    setTimeout(() => document.addEventListener('click', function f(ev) { const bx = Q('#v1Notif'); if (!bx) return document.removeEventListener('click', f); if (!bx.contains(ev.target) && !ev.target.closest('#v1Bell')) { bx.remove(); document.removeEventListener('click', f) } }), 0);
  }
  function goUrl(u) { const m = /#page=(.+)$/.exec(u || ''); if (!m) return; const p = decodeURIComponent(m[1]); if ([...document.querySelectorAll('#nav button')].some(b => b.dataset.page === p)) show(p) }
  function mountHeader() {
    const ta = Q('.top-actions'); if (!ta || Q('#v1Bell')) return;
    ta.insertAdjacentHTML('afterbegin', `${me.role === 'guardian' ? `<select id="v1Lang" class="v1-lang" aria-label="Language" data-notr><option value="en">English</option><option value="hi">हिन्दी</option><option value="bn">বাংলা</option></select>` : ''}<button type="button" id="v1Bell" class="disp-btn v1-bell" data-noicon aria-label="Notifications" title="Notifications"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC.bell}</svg><b id="v1BellN" class="hidden"></b></button>`);
    Q('#v1Bell').onclick = guard(openNotif); const ls = Q('#v1Lang'); if (ls) { ls.value = LANG; ls.onchange = () => setLang(ls.value) }
    clearInterval(notifTimer); refreshBell(); notifTimer = setInterval(refreshBell, 60000);
  }
  async function afterLogin() {
    goUrl(location.hash);
    if (me.role === 'admin') { try { const s = await api('/api/security/me'); if (s.required && !s.totp_enabled) twoFaLock() } catch { } }
  }

  /* ================= login with authenticator code ================= */
  function patchLogin() {
    const f = Q('#loginForm'); if (!f || f.__v1) return; f.__v1 = true;
    f.onsubmit = async e => {
      e.preventDefault();
      const body = { role: Q('#loginRole').value, dise_code: Q('#dise').value.trim(), username: Q('#username').value.trim(), password: Q('#password').value, year_id: Q('#loginYear').value };
      const o = Q('#v1Otp'); if (o && o.value.trim()) body.otp = o.value.trim();
      try {
        const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }), d = await r.json().catch(() => ({}));
        if (!r.ok) { if (d.code === 'NEED_2FA') { showOtp(d.error, !!(o && o.value)); return } throw Error(d.error || 'Login failed') }
        Q('#v1OtpWrap')?.remove(); window.__v1Booted = false; clear(); init();
      } catch (x) { toast(x.message) }
    };
  }
  function showOtp(msg, wasWrong) {
    let w = Q('#v1OtpWrap');
    if (!w) { w = document.createElement('div'); w.id = 'v1OtpWrap'; w.className = 'login-field'; w.innerHTML = '<label for="v1Otp">Authentication code</label><div class="input-icon"><input id="v1Otp" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="6-digit code or recovery code"></div><small class="muted" style="display:block;margin-top:4px">Open your authenticator app. Lost your phone? Use one recovery code.</small>'; Q('#loginSubmit').before(w) }
    const o = Q('#v1Otp'); if (wasWrong) { toast(msg); o.value = '' } o.focus();
  }
  patchLogin();

  /* ================= two-factor enrolment (shared by the page and the forced screen) ================= */
  function enrolUI(host, done) {
    host.innerHTML = `<p>Two-factor sign-in asks for a 6-digit code from an authenticator app (Google Authenticator, Microsoft Authenticator, Authy…) every time you sign in, so a stolen password alone is not enough.</p><button class="primary" id="v1Start">Set up now</button>`;
    host.querySelector('#v1Start').onclick = guard(async () => {
      const s = await J('/api/security/2fa/setup'); const q = qrcode(0, 'M'); q.addData(s.uri); q.make();
      host.innerHTML = `<ol style="padding-left:18px;line-height:1.6"><li>In your authenticator app choose <b>Add account → Scan QR code</b>.</li></ol><div class="v1-qr">${q.createSvgTag({ cellSize: 4, margin: 2, scalable: true })}</div><p class="muted" style="text-align:center;margin:4px 0">Cannot scan? Enter this key manually:</p><div class="v1-secret">${E(s.secret.match(/.{1,4}/g).join(' '))}</div><div class="v1-form" style="margin-top:12px"><label>Then type the 6-digit code shown in the app<input id="v1Code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="123456"></label><button class="primary" id="v1Enable">Turn on two-factor</button></div>`;
      host.querySelector('#v1Enable').onclick = guard(async () => {
        const r = await J('/api/security/2fa/enable', 'POST', { code: val('v1Code') });
        host.innerHTML = `<div class="v1-note warn"><b>Save your recovery codes now.</b> Each code works once if you lose your phone. They will not be shown again.</div><div class="v1-codes">${r.recovery.map(c => `<span>${E(c)}</span>`).join('')}</div><div class="v1-row"><button class="smallbtn" id="v1Copy">Copy codes</button><button class="smallbtn" id="v1Print">Print</button></div><label class="v1-check" style="margin-top:12px"><input type="checkbox" id="v1Saved"> I have saved these codes somewhere safe</label><button class="primary" id="v1Done" style="margin-top:10px" disabled>Finish</button>`;
        host.querySelector('#v1Copy').onclick = () => navigator.clipboard.writeText(r.recovery.join('\n')).then(() => toast('Copied'), () => toast('Copy failed'));
        host.querySelector('#v1Print').onclick = () => printHtml('SchoolHub recovery codes', `<h1>SchoolHub recovery codes</h1><h2>${E(me.name)} — keep these private. Each code works once.</h2><p style="font:700 18px monospace;line-height:2">${r.recovery.map(E).join('<br>')}</p>`);
        const dn = host.querySelector('#v1Done'); host.querySelector('#v1Saved').onchange = e => dn.disabled = !e.target.checked; dn.onclick = () => done();
      });
    });
  }
  function twoFaLock() {
    if (Q('#v1Lock')) return; const d = document.createElement('div'); d.id = 'v1Lock'; d.className = 'v1-lock';
    d.innerHTML = '<div class="box"><h3 style="margin-top:0">Set up two-factor sign-in</h3><div class="v1-note warn" style="margin-bottom:12px">The school now requires two-factor sign-in for administrator accounts. Please finish this once to continue.</div><div id="v1LockBody"></div><p style="margin:16px 0 0"><button class="smallbtn" id="v1LockOut">Sign out</button></p></div>';
    document.body.append(d); enrolUI(Q('#v1LockBody'), () => location.reload());
    Q('#v1LockOut').onclick = async () => { await J('/api/logout'); location.reload() };
  }
  /* any admin action blocked because 2FA is required re-opens the setup screen */
  const _fetch = window.fetch.bind(window);
  window.fetch = async function () { const r = await _fetch.apply(null, arguments); if (r.status === 403 && me && me.role === 'admin') { r.clone().json().then(d => { if (d && d.code === 'SETUP_2FA') twoFaLock() }).catch(() => { }) } return r };

  /* ================= Login Security ================= */
  PAGES['Login Security'] = async function () {
    const mine = await api('/api/security/me'); let st = null; try { st = await api('/api/security/status') } catch { }
    const myCard = panel('My two-factor sign-in', 'Protects your own account.', mine.totp_enabled ? chip('On', 'ok') : chip('Off', 'warn'), mine.totp_enabled
      ? `<p class="muted">Two-factor is on. Recovery codes left: <b>${mine.recovery_left}</b>.</p><div class="v1-row"><button class="smallbtn danger" id="v1Off">Turn off…</button></div>` : '<div id="v1Enrol"></div>');
    let body = myCard;
    if (st) {
      const s = st.settings;
      body += panel('Sign-in rules', 'Applies to every account.', '', `<div class="v1-form" style="max-width:520px"><div class="v1-two"><label>Lock after this many wrong attempts<input id="v1Max" type="number" min="3" max="20" value="${s.max_attempts}"></label><label>Lock for (minutes)<input id="v1Lock2" type="number" min="1" max="240" value="${s.lock_minutes}"></label></div><label class="v1-check"><input type="checkbox" id="v1Req" ${s.require_2fa_admin ? 'checked' : ''}> Require two-factor for all administrator accounts <small>(everyone must enrol after their next sign-in)</small></label><div><button class="primary" id="v1SaveSec">Save rules</button></div></div>`);
      body += panel('Administrator accounts', 'Reset two-factor if someone loses their phone and recovery codes.', '', tbl(['Name', 'Username', 'Role', 'Two-factor', ''], st.admins.map(a => `<tr><td>${E(a.name)}</td><td>${E(a.username)}</td><td>${a.clerk ? 'Clerk' : 'Administrator'}</td><td>${a.totp ? chip('On', 'ok') : chip('Off', 'warn')}</td><td>${a.totp ? `<button class="smallbtn danger" data-reset="${a.id}">Reset</button>` : ''}</td></tr>`)));
      body += panel('Locked right now', 'Accounts or devices blocked after too many wrong passwords.', st.locked.length ? '<button class="smallbtn" data-unlock="*">Unlock all</button>' : '', tbl(['Who', 'Time left', ''], st.locked.map(l => `<tr><td>${E(l.key.startsWith('ip:') ? 'Device/network ' + l.key.slice(3) : 'Account ' + l.key.slice(2))}</td><td>${l.mins} min</td><td><button class="smallbtn" data-unlock="${E(l.key)}">Unlock</button></td></tr>`), 'Nothing is locked.'));
      body += panel('Recent sign-in problems', '', '', tbl(['When', 'What', 'Username', 'From'], st.log.map(l => `<tr><td>${E(ftime(l.at))}</td><td>${E({ failed: 'Wrong password', locked: 'Locked out', blocked: 'Blocked while locked', '2fa_failed': 'Wrong 2FA code', ok: 'Administrator signed in' }[l.result] || l.result)}</td><td>${E(l.username || '')}</td><td>${E(l.ip || '')}</td></tr>`), 'No problems recorded.'));
    }
    content().innerHTML = `<div class="v1-wrap">${body}</div>`;
    const en = Q('#v1Enrol'); if (en) enrolUI(en, () => PAGES['Login Security']());
    const off = Q('#v1Off'); if (off) off.onclick = () => { modal('Turn off two-factor', `<div class="v1-form"><label>Your password<input id="v1P" type="password" autocomplete="current-password"></label><label>Current authenticator code<input id="v1C" inputmode="numeric" maxlength="6"></label><button class="primary danger" id="v1Go">Turn off</button></div>`); Q('#v1Go').onclick = guard(async () => { await J('/api/security/2fa/disable', 'POST', { password: val('v1P'), code: val('v1C') }); closeModal(); toast('Two-factor is off'); PAGES['Login Security']() }) };
    const sv = Q('#v1SaveSec'); if (sv) sv.onclick = guard(async () => { await J('/api/security/settings', 'PUT', { max_attempts: val('v1Max'), lock_minutes: val('v1Lock2'), require_2fa_admin: chk('v1Req') }); toast('Saved'); PAGES['Login Security']() });
    content().onclick = guard(async e => {
      const r = e.target.closest('[data-reset]'), u = e.target.closest('[data-unlock]');
      if (r && confirm('Reset two-factor for this account? They will have to set it up again.')) { await J('/api/security/2fa/reset', 'POST', { user_id: r.dataset.reset }); toast('Reset'); PAGES['Login Security']() }
      if (u) { await J('/api/security/unlock', 'POST', { key: u.dataset.unlock }); toast('Unlocked'); PAGES['Login Security']() }
    });
  };

  /* ================= online payment ================= */
  const loadRzp = () => window.Razorpay ? Promise.resolve() : new Promise((ok, no) => { const s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js'; s.onload = ok; s.onerror = () => no(Error('Could not load the payment window. Check your internet connection.')); document.head.append(s) });
  async function payNow(studentId, amount) {
    const o = await J('/api/pay/order', 'POST', { student_id: studentId, amount }); await loadRzp();
    const rz = new Razorpay({ key: o.key_id, amount: o.amount, currency: 'INR', name: o.name, description: o.description, order_id: o.order_id, prefill: o.prefill, theme: { color: '#2f2555' },
      handler: guard(async resp => { const v = await J('/api/pay/verify', 'POST', resp); clear('fees'); toast(`Payment received. Receipt ${v.receipt}`); PAGES['Pay Online']() }) });
    rz.on('payment.failed', r => toast((r.error && r.error.description) || 'Payment failed. You have not been charged.')); rz.open();
  }
  PAGES['Pay Online'] = async function () {
    const r = await api('/api/pay/mine');
    const kids = r.kids.map(k => `<div class="v1-kpi"><small>${E(k.class_name || '')} ${E(k.section_name || '')}</small><b>${E(k.name)}</b><div style="margin:6px 0">Pending: <b>${money(k.due)}</b></div>${k.due > 0 && r.enabled ? `<div class="v1-row v1-inl"><input type="number" min="1" max="${k.due}" step="1" value="${k.due}" id="v1A${k.id}" style="width:120px"><button class="primary" data-pay="${k.id}">Pay online</button></div>` : k.due > 0 ? '<small>Please pay at the school office.</small>' : chip('No dues', 'ok')}</div>`).join('');
    content().innerHTML = `<div class="v1-wrap">${panel('Pay school fees online', 'Pay by UPI, card or net banking. You get a receipt straight away.', '', (r.enabled ? '' : '<div class="v1-note warn" style="margin-bottom:12px">Online payment is not switched on yet. Please pay at the school office.</div>') + `<div class="v1-grid">${kids || '<p class="muted">No children are linked to this account.</p>'}</div>`)}${panel('My online payments', '', '', tbl(['Date', 'Student', 'Amount', 'Status', 'Receipt'], r.history.map(h => `<tr><td>${E(ftime(h.created_at))}</td><td>${E(h.student)}</td><td>${money(h.amount)}</td><td>${chip(h.status, h.status === 'Paid' ? 'ok' : h.status === 'Created' ? '' : 'warn')}</td><td>${E(h.receipt)}</td></tr>`), 'No online payments yet.'))}</div>`;
    content().onclick = guard(async e => { const b = e.target.closest('[data-pay]'); if (!b) return; const amt = Number(val('v1A' + b.dataset.pay)); if (!(amt >= 1)) return toast('Enter an amount of at least ₹1'); b.disabled = true; try { await payNow(Number(b.dataset.pay), amt) } finally { b.disabled = false } });
  };
  PAGES['Online Payments'] = async function () {
    const r = await api('/api/pay/admin'), clerk = window.F_CLERK;
    const form = clerk ? '' : panel('Razorpay settings', 'Get your Key ID and Key Secret from the Razorpay dashboard (Settings → API keys).', '', `<div class="v1-form" style="max-width:560px">${r.from_env ? '<div class="v1-note">Keys are set on the server (environment variables) and override the boxes below.</div>' : ''}<label class="v1-check"><input type="checkbox" id="v1Rz" ${r.toggle ? 'checked' : ''}> Let guardians pay online</label><div class="v1-two"><label>Key ID<input id="v1Kid" value="${E(r.key_id)}" placeholder="rzp_live_…"></label><label>Key Secret<input id="v1Ksec" type="password" placeholder="${r.has_secret ? '•••••• (saved — leave blank to keep)' : 'Paste the secret'}" autocomplete="off"></label></div><label>Webhook secret <small>(recommended — completes payments even if a parent closes the browser)</small><input id="v1Wh" type="password" placeholder="${r.has_webhook ? '•••••• (saved)' : 'Choose any long random text'}" autocomplete="off"></label><div class="v1-note">In Razorpay → Webhooks add <b>${E(location.origin)}/api/pay/webhook</b>, tick <b>payment.captured</b> and <b>order.paid</b>, and use the same webhook secret.</div><div><button class="primary" id="v1SaveRz">Save</button></div></div>`);
    content().innerHTML = `<div class="v1-wrap">${panel('Online payments', 'Money paid online is added to the fee ledger, Day Book and receipt series automatically.', chip(r.enabled ? 'Live' : 'Off', r.enabled ? 'ok' : 'warn'), tbl(['When', 'Student', 'Amount', 'Status', 'Receipt', 'Razorpay ID', 'Note'], r.rows.map(x => `<tr><td>${E(ftime(x.created_at))}</td><td>${E(x.student)}</td><td>${money(x.amount)}</td><td>${chip(x.status, x.status === 'Paid' ? 'ok' : x.status === 'Needs review' ? 'bad' : '')}</td><td>${E(x.receipt)}</td><td>${E(x.payment_id)}</td><td>${E(x.note)}</td></tr>`), 'No online payments yet.'))}${form}</div>`;
    const sv = Q('#v1SaveRz'); if (sv) sv.onclick = guard(async () => { await J('/api/pay/settings', 'PUT', { enabled: chk('v1Rz'), key_id: val('v1Kid'), key_secret: val('v1Ksec'), webhook_secret: val('v1Wh') }); toast('Saved'); PAGES['Online Payments']() });
  };

  /* ================= fee reminders ================= */
  PAGES['Fee Reminders'] = async function () {
    const r = await api('/api/reminders'), s = r.settings;
    content().innerHTML = `<div class="v1-wrap">${panel('Automatic fee reminders', 'Parents get a notification (and an SMS if you switch it on) when fees are due and again when they are overdue.', chip(s.enabled ? 'On' : 'Off', s.enabled ? 'ok' : 'warn'), `<div class="v1-form" style="max-width:640px"><label class="v1-check"><input type="checkbox" id="v1RE" ${s.enabled ? 'checked' : ''}> Send reminders automatically every day</label><div class="v1-three"><label>Send at (hour, 6–22)<input id="v1RH" type="number" min="6" max="22" value="${s.hour}"></label><label>Remind this many days before due date<input id="v1RB" type="number" min="0" max="15" value="${s.before_days}"></label><label>Repeat overdue reminder every (days)<input id="v1RO" type="number" min="1" max="30" value="${s.overdue_every}"></label></div><div class="v1-two"><label>Stop after this many overdue reminders<input id="v1RM" type="number" min="1" max="12" value="${s.max_overdue}"></label><span></span></div><label class="v1-check"><input type="checkbox" id="v1RP" ${s.push ? 'checked' : ''}> Notification in the app / phone</label><label class="v1-check"><input type="checkbox" id="v1RS" ${s.sms ? 'checked' : ''}> Also send SMS <small>(${r.sms_ready ? 'provider: ' + E(r.sms_provider) : 'set up an SMS provider in Settings first'})</small></label><label>MSG91 flow template ID <small>(only if you use MSG91; the template must use ##name##, ##student## and ##amount##)</small><input id="v1RT" value="${E(s.msg91_template || '')}"></label><div class="v1-row"><button class="primary" id="v1RSave">Save</button><button class="smallbtn" id="v1RRun">Send reminders now</button></div><div class="v1-note">Sending in India by SMS needs your sender ID and message template to be registered (DLT). If SMS fails you will see the reason in the run history below; notifications still go out.</div></div>`)}${panel('Would be sent right now', `${r.pending.length} guardian(s)${r.no_guardian ? ` • ${r.no_guardian} student(s) skipped (no guardian linked)` : ''}`, '', tbl(['Guardian', 'Children', 'Pending', 'Stage', 'Mobile'], r.pending.map(p => `<tr><td>${E(p.guardian)}</td><td>${E(p.kids.join(', '))}</td><td>${money(p.total)}</td><td>${p.overdue ? chip('Overdue', 'bad') : chip('Due', 'warn')}</td><td>${E(p.mobile || '—')}</td></tr>`), 'Nobody needs a reminder right now.'))}${panel('Run history', '', '', tbl(['When', 'How', 'Guardians', 'Devices', 'SMS sent', 'SMS failed', 'No mobile', 'Problems'], r.runs.map(x => `<tr><td>${E(ftime(x.at))}</td><td>${E(x.trigger)}</td><td>${x.guardians}</td><td>${x.push_devices}</td><td>${x.sms_sent}</td><td>${x.sms_failed}</td><td>${x.no_mobile}</td><td>${E((x.errors || []).join('; '))}</td></tr>`), 'No reminders have been sent yet.'))}</div>`;
    const body = () => ({ enabled: chk('v1RE'), hour: val('v1RH'), before_days: val('v1RB'), overdue_every: val('v1RO'), max_overdue: val('v1RM'), push: chk('v1RP'), sms: chk('v1RS'), msg91_template: val('v1RT') });
    Q('#v1RSave').onclick = guard(async () => { await J('/api/reminders', 'PUT', body()); toast('Saved'); PAGES['Fee Reminders']() });
    Q('#v1RRun').onclick = guard(async () => { if (!confirm(`Send reminders to ${r.pending.length} guardian(s) now?`)) return; await J('/api/reminders', 'PUT', body()); const x = await J('/api/reminders/run'); toast(`Sent to ${x.guardians} guardian(s)${x.sms_failed ? ` • ${x.sms_failed} SMS failed` : ''}`); PAGES['Fee Reminders']() });
  };

  /* ================= exam timetable + admit cards ================= */
  const rowHtml = (e = {}) => `<tr class="v1-er"><td><input type="date" value="${E(e.date || '')}" class="e-d"></td><td><input list="v1Subs" value="${E(e.subject_name || '')}" class="e-s" placeholder="Subject"></td><td><input type="time" value="${E(e.start || '')}" class="e-st"></td><td><input type="time" value="${E(e.end || '')}" class="e-en"></td><td><input value="${E(e.room || '')}" class="e-r" placeholder="Room" style="width:80px"></td><td><button type="button" class="smallbtn danger e-x">✕</button></td></tr>`;
  async function examForm(item) {
    const [classes, subjects, years] = await Promise.all([data('classes'), data('subjects'), data('years')]); const isT = me.role === 'teacher';
    const cls = isT ? (await data('students')).reduce((a, s) => (a.some(c => c.id === s.class_id) || a.push({ id: s.class_id, name: s.class_name || (classes.find(c => c.id === s.class_id) || {}).name }), a), []) : classes;
    const it = item || { entries: [{}, {}, {}], published: false };
    modal(item ? 'Edit exam timetable' : 'New exam timetable', `<datalist id="v1Subs">${subjects.map(s => `<option value="${E(s.name)}">`).join('')}</datalist><div class="v1-form"><div class="v1-two"><label>Exam name<input id="v1T" value="${E(it.title || '')}" placeholder="Half-Yearly 2026"></label><label>Class<select id="v1C">${opts(cls, it.class_id)}${isT ? '' : '<option value="0">All classes</option>'}</select></label></div>
<div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Subject</th><th>From</th><th>To</th><th>Room</th><th></th></tr></thead><tbody id="v1Rows">${it.entries.map(rowHtml).join('')}</tbody></table></div><div><button type="button" class="smallbtn" id="v1AddRow">+ Add paper</button></div>
<div class="v1-two"><label>Report at <small>(optional)</small><input id="v1RT" value="${E(it.reporting_time || '')}" placeholder="9:30 AM"></label><span></span></div><label>Instructions for students<textarea id="v1I" placeholder="Carry your admit card, pencil box…">${E(it.instructions || '')}</textarea></label>
<label class="v1-check"><input type="checkbox" id="v1Pub" ${it.published ? 'checked' : ''}> Publish to guardians <small>(they are notified)</small></label><label class="v1-check"><input type="checkbox" id="v1Fee" ${it.require_fee_clear ? 'checked' : ''}> Hold the admit card while fees are overdue <small>(you can allow individual students)</small></label><button class="primary" id="v1Save">Save</button></div>`, true);
    if (item && !cls.some(c => String(c.id) === String(item.class_id)) && Number(item.class_id) !== 0) { /* class not in list: keep as is */ }
    Q('#v1AddRow').onclick = () => Q('#v1Rows').insertAdjacentHTML('beforeend', rowHtml());
    Q('#v1Rows').onclick = e => { if (e.target.closest('.e-x')) e.target.closest('tr').remove() };
    Q('#v1Save').onclick = guard(async () => {
      const entries = [...document.querySelectorAll('.v1-er')].map(r => ({ date: r.querySelector('.e-d').value, subject_name: r.querySelector('.e-s').value.trim(), start: r.querySelector('.e-st').value, end: r.querySelector('.e-en').value, room: r.querySelector('.e-r').value.trim() })).filter(x => x.date && x.subject_name);
      const b = { title: val('v1T'), class_id: val('v1C'), entries, reporting_time: val('v1RT'), instructions: val('v1I'), published: chk('v1Pub'), require_fee_clear: chk('v1Fee') };
      if (item) await J('/api/exam-schedules/' + item.id, 'PUT', b); else await J('/api/exam-schedules', 'POST', b);
      closeModal(); toast('Saved'); PAGES['Exam Timetable']();
    });
  }
  const papers = s => tbl(['Date', 'Subject', 'Time', 'Room'], s.entries.map(e => `<tr><td>${E(fdate(e.date))}</td><td><b>${E(e.subject_name)}</b></td><td>${E(e.start)}${e.end ? ' – ' + E(e.end) : ''}</td><td>${E(e.room)}</td></tr>`));
  PAGES['Exam Timetable'] = async function () {
    const r = await api('/api/exam-schedules');
    if (me.role === 'guardian') {
      const cards = r.rows.map(s => `<div class="v1-wrap">${panel(s.title, `${E(clsName(s.class_name))}${s.reporting_time ? ' • Report at ' + E(s.reporting_time) : ''}`, r.kids.filter(k => !Number(s.class_id) || Number(k.class_id) === Number(s.class_id)).map(k => `<a class="smallbtn ${s.require_fee_clear && k.overdue > 0 ? 'v1-hold' : ''}" href="/api/admit-card/${s.id}/${k.id}" target="_blank" rel="noopener">Admit card — ${E(k.name)}</a>`).join(''), papers(s) + (s.instructions ? `<div class="v1-note" style="margin-top:10px"><b>Instructions:</b> ${E(s.instructions).replace(/\n/g, '<br>')}</div>` : '') + (s.require_fee_clear && r.kids.some(k => k.overdue > 0) ? '<div class="v1-note warn" style="margin-top:10px">Admit cards are held for students with overdue fees. Pay from <b>Pay Online</b> or at the office and the card will open.</div>' : ''))}</div>`).join('');
      content().innerHTML = cards || panel('Exam timetable', '', '', '<p class="muted">No exam timetable has been published yet.</p>'); return;
    }
    const sections = await data('sections');
    content().innerHTML = `<div class="v1-wrap">${panel('Exam timetables', 'Create the schedule once; guardians see it and download the admit card.', '<button class="primary" id="v1New">+ New timetable</button>', '')}${r.rows.map(s => `<div class="panel"><div class="panel-head"><div><h3>${E(s.title)} ${s.published ? chip('Published', 'ok') : chip('Draft', 'warn')} ${s.require_fee_clear ? chip('Fee hold', '') : ''}</h3><p class="muted">${E(clsName(s.class_name))}${s.reporting_time ? ' • Report at ' + E(s.reporting_time) : ''}</p></div><div class="v1-tbl-actions"><button class="smallbtn" data-ed="${s.id}">Edit</button><button class="smallbtn" data-cards="${s.id}">Print admit cards</button>${s.require_fee_clear && me.role === 'admin' ? `<button class="smallbtn" data-allow="${s.id}">Allow a student</button>` : ''}<button class="smallbtn danger" data-del="${s.id}">Delete</button></div></div>${papers(s)}</div>`).join('') || '<p class="muted">No timetable yet. Click “New timetable”.</p>'}</div>`;
    Q('#v1New').onclick = guard(() => examForm(null));
    content().onclick = guard(async e => {
      const ed = e.target.closest('[data-ed]'), cd = e.target.closest('[data-cards]'), dl = e.target.closest('[data-del]'), al = e.target.closest('[data-allow]');
      if (ed) examForm(r.rows.find(x => x.id === Number(ed.dataset.ed)));
      if (dl && confirm('Delete this timetable?')) { await J('/api/exam-schedules/' + dl.dataset.del, 'DELETE'); toast('Deleted'); PAGES['Exam Timetable']() }
      if (cd) { const s = r.rows.find(x => x.id === Number(cd.dataset.cards)); const secs = sections.filter(x => !Number(s.class_id) || Number(x.class_id) === Number(s.class_id));
        modal('Print admit cards', `<div class="v1-form"><label>Section<select id="v1Sec"><option value="0">All sections</option>${opts(secs.map(x => ({ id: x.id, name: x.name })))}</select></label>${s.require_fee_clear ? '<label class="v1-check"><input type="checkbox" id="v1Skip" checked> Skip students with overdue fees</label>' : ''}<button class="primary" id="v1Go">Open admit cards</button></div>`); Q('#v1Go').onclick = () => { window.open(`/api/admit-cards/${s.id}?section_id=${val('v1Sec')}${chk('v1Skip') ? '&skip_dues=1' : ''}`, '_blank'); closeModal() } }
      if (al) { const s = r.rows.find(x => x.id === Number(al.dataset.allow)), students = (await data('students')).filter(x => !Number(s.class_id) || Number(x.class_id) === Number(s.class_id));
        modal('Allow admit card despite dues', `<div class="v1-form"><label>Student<select id="v1St">${opts(students.map(x => ({ id: x.id, name: `${x.name} (${x.class_name || ''} ${x.section_name || ''})${(s.override_students || []).includes(x.id) ? ' ✓ allowed' : ''}` })))}</select></label><div class="v1-row"><button class="primary" id="v1Ok">Allow</button><button class="smallbtn" id="v1No">Remove permission</button></div></div>`);
        Q('#v1Ok').onclick = guard(async () => { await J(`/api/exam-schedules/${s.id}/override`, 'POST', { student_id: val('v1St'), allow: true }); closeModal(); toast('Allowed'); PAGES['Exam Timetable']() });
        Q('#v1No').onclick = guard(async () => { await J(`/api/exam-schedules/${s.id}/override`, 'POST', { student_id: val('v1St'), allow: false }); closeModal(); toast('Removed'); PAGES['Exam Timetable']() }) }
    });
  };

  /* ================= payroll ================= */
  let payTab = 'payslips', payMonth = todayIso().slice(0, 7);
  const profForm = (p = {}) => `<div class="v1-form">${p.kind === 'staff' || !p.key ? `<label>Name<input id="v1N" value="${E(p.name || '')}"></label>` : `<b>${E(p.name)}</b>`}<div class="v1-two"><label>Designation<input id="v1D" value="${E(p.designation || '')}"></label><label>Joining date<input id="v1J" type="date" value="${E(p.joining_date || '')}"></label></div><div class="v1-three"><label>Basic (₹/month)<input id="v1B" type="number" min="0" value="${p.basic || ''}"></label><label>House rent allowance<input id="v1H" type="number" min="0" value="${p.hra || ''}"></label><label>Dearness allowance<input id="v1DA" type="number" min="0" value="${p.da || ''}"></label></div><div class="v1-three"><label>Other allowance<input id="v1O" type="number" min="0" value="${p.other_allowance || ''}"></label><label>PF % of basic<input id="v1PF" type="number" min="0" max="30" step="0.5" value="${p.pf_percent || ''}"></label><label>Professional tax<input id="v1PT" type="number" min="0" value="${p.prof_tax || ''}"></label></div><label>Other fixed deduction<input id="v1OD" type="number" min="0" value="${p.other_deduction || ''}"></label>${p.key ? `<label class="v1-check"><input type="checkbox" id="v1Act" ${p.active !== false ? 'checked' : ''}> Include in payroll</label>` : ''}<button class="primary" id="v1PS">Save</button></div>`;
  const profBody = () => ({ name: val('v1N'), designation: val('v1D'), joining_date: val('v1J'), basic: val('v1B'), hra: val('v1H'), da: val('v1DA'), other_allowance: val('v1O'), pf_percent: val('v1PF'), prof_tax: val('v1PT'), other_deduction: val('v1OD'), active: document.getElementById('v1Act') ? chk('v1Act') : true });
  PAGES['Payroll'] = async function () {
    const tabs = `<div class="v1-tabs">${[['payslips', 'Payslips'], ['staff', 'Staff & salaries'], ['settings', 'Rules']].map(([k, l]) => `<button data-tab="${k}" class="${payTab === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    let body = '';
    if (payTab === 'payslips') {
      const r = await api('/api/payslips?month=' + payMonth);
      body = panel('Payslips', 'Draft payslips are calculated from salary and teacher attendance. Check, adjust, then mark as paid.', `<input type="month" id="v1M" value="${payMonth}" class="v1-lang"><button class="primary" id="v1Run">Create payslips for month</button>`, `<div class="v1-grid" style="margin-bottom:12px"><div class="v1-kpi"><small>Payslips</small><b>${r.rows.length}</b></div><div class="v1-kpi"><small>Total net pay</small><b>${money(r.total_net)}</b></div><div class="v1-kpi"><small>Paid so far</small><b>${money(r.paid_net)}</b></div></div>` + tbl(['Name', 'Role', 'Gross', 'Deductions', 'Net pay', 'LOP days', 'Status', ''], r.rows.map(p => `<tr><td>${E(p.name)}</td><td>${E(p.designation)}</td><td>${money(p.gross)}</td><td>${money(p.ded_total)}</td><td><b>${money(p.net)}</b></td><td>${p.lop_days}</td><td>${p.status === 'Paid' ? chip('Paid ' + fdate(p.paid_date), 'ok') : chip('Draft', 'warn')}</td><td><div class="v1-tbl-actions">${p.status === 'Paid' ? `<button class="smallbtn" data-unpay="${p.id}">Undo</button>` : `<button class="smallbtn" data-edit="${p.id}">Adjust</button><button class="smallbtn" data-pay="${p.id}">Mark paid</button><button class="smallbtn danger" data-del="${p.id}">Delete</button>`}<a class="smallbtn" href="/api/payslip/${p.id}/print" target="_blank" rel="noopener">Print</a></div></td></tr>`), 'No payslips for this month. Click “Create payslips for month”.'));
      content().innerHTML = `<div class="v1-wrap">${tabs}${body}</div>`;
      Q('#v1M').onchange = e => { payMonth = e.target.value || payMonth; PAGES['Payroll']() };
      Q('#v1Run').onclick = guard(async () => { const x = await J('/api/payroll/run', 'POST', { month: payMonth }); toast(`${x.made} created${x.skipped ? `, ${x.skipped} already existed` : ''}${x.no_salary ? `, ${x.no_salary} have no salary set` : ''}`); PAGES['Payroll']() });
      content().onclick = guard(async e => {
        const t = e.target.closest('[data-tab]'); if (t) { payTab = t.dataset.tab; return PAGES['Payroll']() }
        const ed = e.target.closest('[data-edit]'), pay = e.target.closest('[data-pay]'), un = e.target.closest('[data-unpay]'), dl = e.target.closest('[data-del]'), row = x => r.rows.find(p => p.id === Number(x));
        if (ed) { const p = row(ed.dataset.edit); modal('Adjust payslip — ' + p.name, `<div class="v1-form"><div class="v1-two"><label>Bonus / arrears (₹)<input id="v1Bo" type="number" min="0" value="${p.adj.bonus || ''}"></label><label>Advance recovery (₹)<input id="v1Ad" type="number" min="0" value="${p.adj.advance || ''}"></label></div><div class="v1-two"><label>Other deduction (₹)<input id="v1Od" type="number" min="0" value="${p.adj.other_ded || ''}"></label><label>Note for deduction<input id="v1Rm" value="${E(p.adj.remarks || '')}"></label></div><label>Loss-of-pay days <small>(calculated: ${p.absent_days + p.unpaid_leave_days}; change only to override)</small><input id="v1Lp" type="number" min="0" step="0.5" value="${p.adj.lop_override ?? ''}" placeholder="${p.absent_days + p.unpaid_leave_days}"></label><button class="primary" id="v1AS">Recalculate and save</button></div>`); Q('#v1AS').onclick = guard(async () => { await J('/api/payslips/' + p.id, 'PUT', { bonus: val('v1Bo'), advance: val('v1Ad'), other_ded: val('v1Od'), remarks: val('v1Rm'), lop_override: val('v1Lp') }); closeModal(); PAGES['Payroll']() }) }
        if (pay) { const p = row(pay.dataset.pay); modal('Mark as paid — ' + p.name, `<div class="v1-form"><p>Net pay <b>${money(p.net)}</b></p><div class="v1-two"><label>Date<input id="v1PD" type="date" value="${todayIso()}"></label><label>Mode<select id="v1PM">${['Bank', 'Cash', 'UPI', 'Cheque', 'Other'].map(m => `<option>${m}</option>`).join('')}</select></label></div><label>Reference <small>(optional)</small><input id="v1PR" maxlength="40"></label><button class="primary" id="v1PG">Mark paid</button></div>`); Q('#v1PG').onclick = guard(async () => { await J(`/api/payslips/${p.id}/pay`, 'POST', { paid_date: val('v1PD'), mode: val('v1PM'), ref: val('v1PR') }); closeModal(); toast('Marked paid'); PAGES['Payroll']() }) }
        if (un && confirm('Undo this payment?')) { await J(`/api/payslips/${un.dataset.unpay}/unpay`); PAGES['Payroll']() }
        if (dl && confirm('Delete this draft payslip?')) { await J('/api/payslips/' + dl.dataset.del, 'DELETE'); PAGES['Payroll']() }
      });
    } else if (payTab === 'staff') {
      const r = await api('/api/payroll/staff');
      body = panel('Staff & salaries', 'Set each person\'s monthly salary once. Teachers\' leave and absences come from Teacher Attendance.', '<button class="primary" id="v1AddS">+ Add non-teaching staff</button>', tbl(['Name', 'Role', 'Basic', 'Gross', 'Paid leave left', 'Status', ''], r.staff.map(p => `<tr><td>${E(p.name)}</td><td>${E(p.designation)}</td><td>${p.has_profile ? money(p.basic) : '—'}</td><td>${p.has_profile ? money(Number(p.basic) + Number(p.hra) + Number(p.da) + Number(p.other_allowance)) : '—'}</td><td>${p.leave ? p.leave.remaining_after + ' of ' + p.leave.entitled : '—'}</td><td>${!p.has_profile ? chip('No salary set', 'warn') : p.active ? chip('In payroll', 'ok') : chip('Excluded')}</td><td><div class="v1-tbl-actions"><button class="smallbtn" data-ps="${p.key}">${p.has_profile ? 'Edit' : 'Set salary'}</button>${p.kind === 'staff' ? `<button class="smallbtn danger" data-rm="${p.key}">Remove</button>` : ''}</div></td></tr>`)));
      content().innerHTML = `<div class="v1-wrap">${tabs}${body}</div>`;
      Q('#v1AddS').onclick = () => { modal('Add staff member', profForm({})); Q('#v1PS').onclick = guard(async () => { await J('/api/payroll/staff', 'POST', profBody()); closeModal(); PAGES['Payroll']() }) };
      content().onclick = guard(async e => {
        const t = e.target.closest('[data-tab]'); if (t) { payTab = t.dataset.tab; return PAGES['Payroll']() }
        const b = e.target.closest('[data-ps]'), rm = e.target.closest('[data-rm]');
        if (b) { const p = r.staff.find(x => x.key === b.dataset.ps); modal('Salary — ' + p.name, profForm(p)); Q('#v1PS').onclick = guard(async () => { await J('/api/payroll/staff/' + p.key, 'PUT', profBody()); closeModal(); toast('Saved'); PAGES['Payroll']() }) }
        if (rm && confirm('Remove this staff member?')) { await J('/api/payroll/staff/' + rm.dataset.rm, 'DELETE'); PAGES['Payroll']() }
      });
    } else {
      const r = await api('/api/payroll/staff'), s = r.settings;
      body = panel('Payroll rules', '', '', `<div class="v1-form" style="max-width:560px"><label>Per-day pay is calculated as monthly gross divided by<select id="v1Bs"><option value="month_days" ${s.per_day_basis === 'month_days' ? 'selected' : ''}>Number of days in the month</option><option value="exclude_sundays" ${s.per_day_basis === 'exclude_sundays' ? 'selected' : ''}>Days in the month excluding Sundays</option><option value="fixed" ${s.per_day_basis === 'fixed' ? 'selected' : ''}>A fixed number of days</option></select></label><label>Fixed days <small>(only when “fixed” is chosen)</small><input id="v1Fx" type="number" min="20" max="31" value="${s.fixed_days}"></label><div class="v1-two"><label>Paid leave per teacher per year (days)<input id="v1Pl" type="number" min="0" max="60" value="${s.paid_leave_per_year}"></label><label>Leave year starts in month<select id="v1Ly">${['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map((m, i) => `<option value="${i + 1}" ${s.leave_year_start_month === i + 1 ? 'selected' : ''}>${m}</option>`).join('')}</select></label></div><div class="v1-note">Loss of pay = days marked <b>Absent</b> in Teacher Attendance + <b>Leave</b> days beyond the yearly paid-leave allowance. Days with no attendance entry count as present. Everything can be adjusted on the draft payslip.</div><div><button class="primary" id="v1SR">Save rules</button></div></div>`);
      content().innerHTML = `<div class="v1-wrap">${tabs}${body}</div>`;
      Q('#v1SR').onclick = guard(async () => { await J('/api/payroll/settings', 'PUT', { per_day_basis: val('v1Bs'), fixed_days: val('v1Fx'), paid_leave_per_year: val('v1Pl'), leave_year_start_month: val('v1Ly') }); toast('Saved') });
      content().onclick = e => { const t = e.target.closest('[data-tab]'); if (t) { payTab = t.dataset.tab; PAGES['Payroll']() } };
    }
  };
  PAGES['My Payslips'] = async function () {
    const r = await api('/api/payroll/mine'), l = r.leave;
    content().innerHTML = `<div class="v1-wrap">${panel('My leave balance', `Leave year from ${E(fdate(r.year_start))}`, '', `<div class="v1-grid"><div class="v1-kpi"><small>Paid leave per year</small><b>${l.entitled}</b></div><div class="v1-kpi"><small>Taken before this month</small><b>${l.used_before}</b></div><div class="v1-kpi"><small>Taken this month</small><b>${l.leave}</b></div><div class="v1-kpi"><small>Paid leave remaining</small><b>${l.remaining_after}</b></div></div><p class="muted" style="margin-top:10px">Apply for leave from <b>My Attendance &amp; Leave</b>. Leave beyond the paid allowance is deducted from pay.</p>`)}${panel('My payslips', '', '', tbl(['Month', 'Net pay', 'Paid on', ''], r.payslips.map(p => `<tr><td>${E(p.month)}</td><td>${money(p.net)}</td><td>${E(fdate(p.paid_date))}</td><td><a class="smallbtn" href="/api/payslip/${p.id}/print" target="_blank" rel="noopener">Open / Print</a></td></tr>`), 'No payslips yet.'))}</div>`;
  };

  /* ================= student diary & remarks ================= */
  const DTYPE = { Praise: 'ok', Concern: 'bad', Behaviour: 'warn', Health: 'warn' };
  async function classChoices() {
    const students = await data('students');
    if (me.role === 'admin') return { classes: await data('classes'), sections: await data('sections'), students };
    const classes = [], sections = [];
    for (const s of students) { if (!classes.some(c => c.id === s.class_id)) classes.push({ id: s.class_id, name: s.class_name || ('Class ' + s.class_id) }); if (!sections.some(c => c.id === s.section_id)) sections.push({ id: s.section_id, class_id: s.class_id, name: s.section_name || ('Section ' + s.section_id) }) }
    return { classes, sections, students };
  }
  async function diaryForm(types) {
    const { classes, sections, students } = await classChoices();
    modal('New diary entry', `<div class="v1-form"><div class="v1-two"><label>Class<select id="v1Dc">${opts(classes, classes[0] && classes[0].id)}</select></label><label>Section<select id="v1Ds"></select></label></div><label>Write to<select id="v1Dst"></select></label><div class="v1-two"><label>Type<select id="v1Dt">${types.map(t => `<option>${t}</option>`).join('')}</select></label><label>Date<input id="v1Dd" type="date" value="${todayIso()}"></label></div><label>Title <small>(optional)</small><input id="v1Dti" maxlength="80"></label><label>Note<textarea id="v1Db" maxlength="1500" placeholder="Write your note for the parent…"></textarea></label><label class="v1-check"><input type="checkbox" id="v1Dv" checked> Visible to the parent <small>(they are notified and can acknowledge)</small></label><button class="primary" id="v1Dsave">Save entry</button></div>`);
    const fill = () => {
      const c = Number(val('v1Dc')), secs = sections.filter(s => !s.class_id || Number(s.class_id) === c); Q('#v1Ds').innerHTML = '<option value="0">All sections</option>' + opts(secs, '');
      const sec = Number(val('v1Ds')) || 0, list = students.filter(s => Number(s.class_id) === c && (!sec || Number(s.section_id) === sec));
      Q('#v1Dst').innerHTML = '<option value="">Whole class / section (everyone)</option>' + list.map(s => `<option value="${s.id}">${E(s.name)}${s.roll_no ? ' — roll ' + E(s.roll_no) : ''}</option>`).join('');
    };
    Q('#v1Dc').onchange = fill; Q('#v1Ds').onchange = () => { const c = Number(val('v1Dc')), sec = Number(val('v1Ds')) || 0, list = students.filter(s => Number(s.class_id) === c && (!sec || Number(s.section_id) === sec)); Q('#v1Dst').innerHTML = '<option value="">Whole class / section (everyone)</option>' + list.map(s => `<option value="${s.id}">${E(s.name)}</option>`).join('') };
    fill();
    Q('#v1Dsave').onclick = guard(async () => { const sid = val('v1Dst'); const b = { type: val('v1Dt'), date: val('v1Dd'), title: val('v1Dti'), body: val('v1Db'), visible_to_guardian: chk('v1Dv') }; if (sid) b.student_id = sid; else { b.class_id = val('v1Dc'); b.section_id = val('v1Ds') } await J('/api/diary', 'POST', b); closeModal(); toast('Saved'); PAGES['Student Diary']() });
  }
  PAGES['Student Diary'] = async function () {
    const r = await api('/api/diary'), g = me.role === 'guardian';
    const cards = r.rows.map(e => `<div class="v1-entry"><div class="v1-row"><h4>${E(e.title)}</h4>${chip(e.type, DTYPE[e.type] || '')}<span class="meta v1-grow" style="text-align:right">${E(fdate(e.date))}</span></div><p>${E(e.body)}</p><div class="meta">${e.scope === 'student' ? E(e.student) : 'Whole class ' + E(e.class_name) + ' ' + E(e.section_name)} • from ${E(e.by)}${!g ? ` • ${e.visible_to_guardian ? 'visible to parent' : 'staff only'}${e.visible_to_guardian && e.scope === 'student' ? ` • ${e.ack_count ? 'acknowledged ✓' : 'not yet acknowledged'}` : ''}${e.scope === 'class' ? ` • ${e.ack_count} acknowledged` : ''}` : ''}</div>${g ? `<div class="v1-row">${e.mine.map(k => k.acked ? `<span class="v1-chip ok">${E(k.name)}: seen ✓</span>` : `<button class="smallbtn" data-ack="${e.id}" data-st="${k.id}">I have seen this${e.mine.length > 1 ? ' — ' + E(k.name) : ''}</button>`).join('')}</div>` : (e.can_delete ? `<div><button class="smallbtn danger" data-del="${e.id}">Delete</button></div>` : '')}</div>`).join('');
    content().innerHTML = `<div class="v1-wrap">${panel('Student diary', g ? 'Notes and remarks from your child\'s teachers. Tap “I have seen this” so the teacher knows you read it.' : 'Daily notes, praise and concerns for parents. Parents are notified and can acknowledge.', g ? '' : '<button class="primary" id="v1DN">+ New entry</button>', '')}${cards || '<p class="muted">No diary entries yet.</p>'}</div>`;
    const n = Q('#v1DN'); if (n) n.onclick = guard(() => diaryForm(r.types));
    content().onclick = guard(async e => {
      const a = e.target.closest('[data-ack]'), d = e.target.closest('[data-del]');
      if (a) { await J(`/api/diary/${a.dataset.ack}/ack`, 'POST', { student_id: a.dataset.st }); toast('Thank you'); PAGES['Student Diary']() }
      if (d && confirm('Delete this entry?')) { await J('/api/diary/' + d.dataset.del, 'DELETE'); PAGES['Student Diary']() }
    });
  };

  /* ================= syllabus & lesson-plan tracker ================= */
  const sylFilter = { class_id: '', subject_id: '' };
  const SYL = ['Not started', 'In progress', 'Completed'];
  const bar = (p, late) => `<div class="v1-bar ${p >= 100 ? 'done' : late ? 'late' : ''}" title="${p}%"><i style="width:${Math.min(100, p)}%"></i></div>`;
  async function sylForm(u) {
    const { classes } = await classChoices(), subjects = await data('subjects'), it = u || { status: 'Not started', visible_to_guardian: true };
    modal(u ? 'Edit chapter / unit' : 'Add chapter / unit', `<div class="v1-form"><div class="v1-two"><label>Class<select id="v1Yc">${opts(classes, it.class_id || sylFilter.class_id)}</select></label><label>Subject<select id="v1Ys">${opts(subjects, it.subject_id || sylFilter.subject_id)}</select></label></div><label>Chapter / unit title<input id="v1Yt" value="${E(it.title || '')}" maxlength="120"></label><label>Topics covered<textarea id="v1Yp">${E(it.topics || '')}</textarea></label><div class="v1-two"><label>Planned start<input type="date" id="v1Y1" value="${E(it.planned_start || '')}"></label><label>Planned finish<input type="date" id="v1Y2" value="${E(it.planned_end || '')}"></label></div><div class="v1-two"><label>Status<select id="v1Yst">${SYL.map(s => `<option ${it.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label><label>Percent done<input type="number" id="v1Ypc" min="0" max="100" value="${it.percent || 0}"></label></div><details><summary style="cursor:pointer;font-weight:600">Lesson plan details (optional)</summary><div class="v1-form" style="margin-top:10px"><label>Learning objectives<textarea id="v1Yo">${E(it.objectives || '')}</textarea></label><label>Activities / method<textarea id="v1Ya">${E(it.activities || '')}</textarea></label><div class="v1-two"><label>Resources<input id="v1Yr" value="${E(it.resources || '')}"></label><label>Assessment<input id="v1Yas" value="${E(it.assessment || '')}"></label></div><label>Periods needed<input type="number" id="v1Yn" min="0" value="${it.periods || ''}"></label></div></details><label class="v1-check"><input type="checkbox" id="v1Yv" ${it.visible_to_guardian !== false ? 'checked' : ''}> Show to parents</label><button class="primary" id="v1Ysave">Save</button></div>`, true);
    Q('#v1Ysave').onclick = guard(async () => { const b = { class_id: val('v1Yc'), subject_id: val('v1Ys'), title: val('v1Yt'), topics: val('v1Yp'), planned_start: val('v1Y1'), planned_end: val('v1Y2'), status: val('v1Yst'), percent: val('v1Ypc'), objectives: val('v1Yo'), activities: val('v1Ya'), resources: val('v1Yr'), assessment: val('v1Yas'), periods: val('v1Yn'), visible_to_guardian: chk('v1Yv') }; if (u) await J('/api/syllabus/' + u.id, 'PUT', b); else await J('/api/syllabus', 'POST', b); closeModal(); toast('Saved'); PAGES['Syllabus Tracker']() });
  }
  PAGES['Syllabus Tracker'] = async function () {
    const g = me.role === 'guardian', qs = new URLSearchParams(); if (!g) { if (sylFilter.class_id) qs.set('class_id', sylFilter.class_id); if (sylFilter.subject_id) qs.set('subject_id', sylFilter.subject_id) }
    const [r, sum] = await Promise.all([api('/api/syllabus?' + qs), g ? { rows: [] } : api('/api/syllabus/summary')]);
    if (g) {
      const by = {}; r.rows.forEach(x => { (by[x.class_name + ' • ' + x.subject_name] = by[x.class_name + ' • ' + x.subject_name] || []).push(x) });
      content().innerHTML = `<div class="v1-wrap">${panel('Syllabus progress', 'What the class is learning and how far the teachers have reached.', '', '')}${Object.keys(by).map(k => { const l = by[k], pc = Math.round(l.reduce((a, x) => a + x.percent, 0) / l.length); return panel(k, `${pc}% of the planned syllabus covered`, '', bar(pc) + tbl(['Chapter / unit', 'Topics', 'Planned', 'Status'], l.map(x => `<tr><td><b>${E(x.title)}</b></td><td>${E(x.topics)}</td><td>${x.planned_end ? E(fdate(x.planned_end)) : ''}</td><td>${x.status === 'Completed' ? chip('Done', 'ok') : x.status === 'In progress' ? chip('Running ' + x.percent + '%', 'warn') : chip('Upcoming')}</td></tr>`))) }).join('') || '<p class="muted">The syllabus has not been added for your child\'s class yet.</p>'}</div>`; return;
    }
    const { classes } = await classChoices(), subjects = await data('subjects');
    content().innerHTML = `<div class="v1-wrap">${panel('Syllabus & lesson plans', 'Plan chapters, track progress and see which classes are running behind.', '<button class="primary" id="v1YN">+ Add chapter / unit</button>', tbl(['Class', 'Subject', 'Units', 'Done', 'Progress', 'Behind plan'], sum.rows.map(x => `<tr><td>${E(x.class_name)}</td><td>${E(x.subject_name)}</td><td>${x.total}</td><td>${x.done}</td><td style="min-width:130px">${bar(x.percent, x.behind > 0)} ${x.percent}%</td><td>${x.behind ? chip(x.behind + ' late', 'bad') : chip('On track', 'ok')}</td></tr>`), 'No chapters yet. Add the first one.'))}${panel('Chapters & units', '', `<select id="v1Fc" class="v1-lang">${opts(classes, sylFilter.class_id, 'All classes')}</select><select id="v1Fs" class="v1-lang">${opts(subjects, sylFilter.subject_id, 'All subjects')}</select>`, tbl(['Class', 'Subject', 'Chapter / unit', 'Planned finish', 'Status', ''], r.rows.map(x => `<tr><td>${E(x.class_name)}</td><td>${E(x.subject_name)}</td><td><b>${E(x.title)}</b><br><small class="muted">${E(x.topics.slice(0, 90))}</small></td><td>${x.planned_end ? E(fdate(x.planned_end)) : ''} ${x.behind ? chip('late', 'bad') : ''}</td><td>${x.can_edit ? `<select data-st="${x.id}" class="v1-lang">${SYL.map(s => `<option ${x.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>` : E(x.status)}</td><td>${x.can_edit ? `<div class="v1-tbl-actions"><button class="smallbtn" data-ed="${x.id}">Edit</button><button class="smallbtn danger" data-del="${x.id}">Delete</button></div>` : ''}</td></tr>`), 'Nothing matches.'))}</div>`;
    Q('#v1YN').onclick = guard(() => sylForm(null));
    Q('#v1Fc').onchange = e => { sylFilter.class_id = e.target.value; PAGES['Syllabus Tracker']() }; Q('#v1Fs').onchange = e => { sylFilter.subject_id = e.target.value; PAGES['Syllabus Tracker']() };
    content().onclick = guard(async e => { const ed = e.target.closest('[data-ed]'), dl = e.target.closest('[data-del]'); if (ed) sylForm(r.rows.find(x => x.id === Number(ed.dataset.ed))); if (dl && confirm('Delete this chapter?')) { await J('/api/syllabus/' + dl.dataset.del, 'DELETE'); PAGES['Syllabus Tracker']() } });
    content().onchange = guard(async e => { const s = e.target.closest('[data-st]'); if (s) { await J('/api/syllabus/' + s.dataset.st, 'PUT', { status: s.value, percent: s.value === 'In progress' ? 50 : undefined }); PAGES['Syllabus Tracker']() } });
  };

  /* ================= photo gallery ================= */
  let galAlbum = 0;
  async function prepPhoto(file) {
    if (!/^image\//.test(file.type)) throw Error(file.name + ': this is not a photo');
    if (file.type === 'image/gif') { if (file.size > 8e6) throw Error(file.name + ': too large'); return file }
    let bmp; try { bmp = await createImageBitmap(file) } catch { throw Error(file.name + ': this photo format is not supported (please use JPG or PNG)') }
    const r = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    if (r === 1 && file.size < 700000 && /jpeg|png|webp/.test(file.type)) return file;
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * r); c.height = Math.round(bmp.height * r); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    const b = await new Promise(ok => c.toBlob(ok, 'image/jpeg', 0.82)); if (!b) throw Error(file.name + ': could not be processed'); return b;
  }
  function lightbox(ids, i) {
    const d = document.createElement('div'); d.className = 'v1-light'; const show1 = () => { d.querySelector('img').src = '/api/gallery/photo/' + ids[i] };
    d.innerHTML = '<img alt=""><button class="x" aria-label="Close">✕</button><button class="p" aria-label="Previous">‹</button><button class="n" aria-label="Next">›</button>'; document.body.append(d); show1();
    const go = n => { i = (i + n + ids.length) % ids.length; show1() }, key = e => { if (e.key === 'Escape') close(); if (e.key === 'ArrowLeft') go(-1); if (e.key === 'ArrowRight') go(1) }, close = () => { d.remove(); document.removeEventListener('keydown', key) };
    d.querySelector('.x').onclick = close; d.querySelector('.p').onclick = () => go(-1); d.querySelector('.n').onclick = () => go(1); d.onclick = e => { if (e.target === d) close() }; document.addEventListener('keydown', key);
  }
  async function albumForm(al, events, classes) {
    const a = al || { date: todayIso(), class_id: 0, event_id: 0 };
    modal(al ? 'Edit album' : 'New album', `<div class="v1-form"><label>Album title<input id="v1At" value="${E(a.title || '')}" maxlength="80" placeholder="Annual Sports Day"></label><div class="v1-two"><label>Date<input id="v1Ad" type="date" value="${E(a.date)}"></label><label>Who can see it<select id="v1Ac"><option value="0">Whole school</option>${opts(classes, a.class_id)}</select></label></div><label>Linked event <small>(optional)</small><select id="v1Ae"><option value="0">None</option>${events.map(e => `<option value="${e.id}" ${Number(a.event_id) === e.id ? 'selected' : ''}>${E(e.title)} — ${E(fdate(e.date))}</option>`).join('')}</select></label><label>Description<textarea id="v1Ax" maxlength="400">${E(a.description || '')}</textarea></label><button class="primary" id="v1As">Save</button></div>`);
    Q('#v1As').onclick = guard(async () => { const b = { title: val('v1At'), date: val('v1Ad'), class_id: val('v1Ac'), event_id: val('v1Ae'), description: val('v1Ax') }; let id; if (al) { await J('/api/gallery/albums/' + al.id, 'PUT', b); id = al.id } else id = (await J('/api/gallery/albums', 'POST', b)).id; closeModal(); galAlbum = id; PAGES['Photo Gallery']() });
  }
  PAGES['Photo Gallery'] = async function () {
    const staff = me.role !== 'guardian', r = await api('/api/gallery/albums');
    if (galAlbum && r.rows.some(a => a.id === galAlbum)) {
      const d = await api('/api/gallery/albums/' + galAlbum), a = d.album, ids = d.photos.map(p => p.id);
      content().innerHTML = `<div class="v1-wrap">${panel(a.title, `${E(fdate(a.date))} • ${E(a.class_name)}${a.event_title ? ' • ' + E(a.event_title) : ''}${a.description ? '<br>' + E(a.description) : ''}`, `<button class="smallbtn" id="v1Back">← All albums</button>${a.can_edit ? '<button class="primary" id="v1Up">+ Add photos</button><button class="smallbtn" id="v1EdA">Edit album</button><button class="smallbtn danger" id="v1DelA">Delete album</button>' : ''}`, `<p id="v1UpS" class="muted"></p><div class="v1-photos">${d.photos.map((p, i) => `<div class="ph" data-i="${i}"><img loading="lazy" alt="${E(p.name)}" src="/api/gallery/photo/${p.id}">${a.can_edit ? `<button data-dp="${p.id}">Delete</button>` : ''}</div>`).join('') || '<p class="muted">No photos yet.</p>'}</div>`)}<input type="file" id="v1File" accept="image/*" multiple class="hidden"></div>`;
      Q('#v1Back').onclick = () => { galAlbum = 0; PAGES['Photo Gallery']() };
      const up = Q('#v1Up'); if (up) { up.onclick = () => Q('#v1File').click(); Q('#v1File').onchange = guard(async e => { const files = [...e.target.files]; let ok = 0; const bad = []; for (let i = 0; i < files.length; i++) { Q('#v1UpS').textContent = `Uploading ${i + 1} of ${files.length}…`; try { const b = await prepPhoto(files[i]); const x = await fetch(`/api/gallery/albums/${galAlbum}/photos`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'x-file-name': encodeURIComponent(files[i].name) }, body: b }); if (!x.ok) throw Error(((await x.json().catch(() => ({}))).error) || 'upload failed'); ok++ } catch (er) { bad.push(er.message) } } toast(`${ok} photo(s) added${bad.length ? '. ' + bad[0] : ''}`); PAGES['Photo Gallery']() }) }
      Q('#v1EdA')?.addEventListener('click', guard(async () => albumForm(a, r.events, await classOptions())));
      Q('#v1DelA')?.addEventListener('click', guard(async () => { if (!confirm('Delete this album and all its photos?')) return; await J('/api/gallery/albums/' + a.id, 'DELETE'); galAlbum = 0; PAGES['Photo Gallery']() }));
      content().onclick = guard(async e => { const dp = e.target.closest('[data-dp]'); if (dp) { e.stopPropagation(); if (confirm('Delete this photo?')) { await J('/api/gallery/photos/' + dp.dataset.dp, 'DELETE'); PAGES['Photo Gallery']() } return } const ph = e.target.closest('.ph'); if (ph) lightbox(ids, Number(ph.dataset.i)) });
      return;
    }
    galAlbum = 0;
    content().innerHTML = `<div class="v1-wrap">${panel('Photo gallery', 'Photos from school events and class activities.', staff ? '<button class="primary" id="v1NA">+ New album</button>' : '', `<div class="v1-grid">${r.rows.map(a => `<div class="v1-album" data-al="${a.id}"><div class="cv" ${a.cover ? `style="background-image:url('/api/gallery/photo/${a.cover}')"` : ''}>${a.cover ? '' : '🖼'}</div><div class="tx"><b>${E(a.title)}</b><small>${E(fdate(a.date))} • ${a.count} photo${a.count === 1 ? '' : 's'} • ${E(a.class_name)}</small></div></div>`).join('') || '<p class="muted">No albums yet.</p>'}</div>`)}</div>`;
    Q('#v1NA')?.addEventListener('click', guard(async () => albumForm(null, r.events, await classOptions())));
    content().onclick = e => { const a = e.target.closest('[data-al]'); if (a) { galAlbum = Number(a.dataset.al); PAGES['Photo Gallery']() } };
  };
  async function classOptions() { return (await classChoices()).classes }

  /* ================= Hindi / Bengali (guardians + login screen) ================= */
  let LANG = 'en'; try { LANG = localStorage.getItem('sh_lang') || 'en' } catch { }
  const SKIPTAG = /^(SCRIPT|STYLE|TEXTAREA|CODE|PRE|INPUT|NOSCRIPT)$/, ATTRS = ['placeholder', 'title', 'aria-label'];
  function trString(s) {
    const D = window.V1I18N && window.V1I18N[LANG]; if (!D) return s; const t = s.trim(); if (!t) return s;
    const hit = x => { if (D.map[x]) return D.map[x]; if (D.lc[x.toLowerCase()]) return D.lc[x.toLowerCase()]; for (const [re, fn] of D.rules) { const m = x.match(re); if (m) return fn(m) } return null };
    let r = hit(t); if (r !== null) return s.replace(t, r);
    const pre = /^[^A-Za-z0-9]+/.exec(t);                 /* "✓ Child Attendance", "＋ New", emoji prefixes */
    if (pre) { r = hit(t.slice(pre[0].length)); if (r !== null) return s.replace(t, pre[0] + r) }
    return s;
  }
  function tNode(n) { const cur = n.nodeValue, en = (n.__en !== undefined && cur === n.__tr) ? n.__en : cur, out = LANG === 'en' ? en : trString(en); if (out !== cur) n.nodeValue = out; n.__en = en; n.__tr = out }
  function tAttrs(el) { for (const a of ATTRS) { if (!el.hasAttribute(a)) continue; el.__ea = el.__ea || {}; const cur = el.getAttribute(a), rec = el.__ea[a], en = (rec && cur === rec.tr) ? rec.en : cur, out = LANG === 'en' ? en : trString(en); if (out !== cur) el.setAttribute(a, out); el.__ea[a] = { en, tr: out } } }
  function i18nApply(root) {
    if (!root || (LANG === 'en' && !i18nApply.used)) return; i18nApply.used = true;
    if (root.nodeType === 3) { if (root.parentElement && !SKIPTAG.test(root.parentElement.tagName) && !root.parentElement.closest('[data-notr]')) tNode(root); return }
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode: n => n.nodeType === 1 ? (SKIPTAG.test(n.tagName) || n.hasAttribute('data-notr') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) : NodeFilter.FILTER_ACCEPT });
    if (root.nodeType === 1) tAttrs(root);
    let n; while ((n = w.nextNode())) { if (n.nodeType === 3) tNode(n); else tAttrs(n) }
  }
  function setLang(l) {
    LANG = ['en', 'hi', 'bn'].includes(l) ? l : 'en'; try { localStorage.setItem('sh_lang', LANG) } catch { }
    document.documentElement.lang = LANG; const ls = Q('#v1Lang'); if (ls) ls.value = LANG;
    document.querySelectorAll('.v1-login-lang button').forEach(b => b.classList.toggle('on', b.dataset.l === LANG));
    i18nApply(document.body); i18nApply.used = true;
  }
  function mountLoginLang() {
    const f = Q('.portal-footer'); if (!f || Q('.v1-login-lang')) return;
    f.insertAdjacentHTML('beforebegin', '<div class="v1-login-lang" data-notr><button type="button" data-l="en">English</button><button type="button" data-l="hi">हिन्दी</button><button type="button" data-l="bn">বাংলা</button></div>');
    Q('.v1-login-lang').onclick = e => { const b = e.target.closest('button[data-l]'); if (b) setLang(b.dataset.l) };
  }
  let pending = new Set(), queued = false;
  new MutationObserver(ms => {
    if (LANG === 'en' && !i18nApply.used) return;
    for (const m of ms) { if (m.type === 'characterData') { if (m.target.nodeValue !== m.target.__tr) pending.add(m.target) } else m.addedNodes.forEach(n => pending.add(n)) }
    if (!queued && pending.size) { queued = true; requestAnimationFrame(() => { queued = false; const p = [...pending]; pending = new Set(); p.forEach(n => i18nApply(n)) }) }
  }).observe(document.body, { childList: true, subtree: true, characterData: true });
  mountLoginLang(); setLang(LANG);
  /* sign-out resets the one-time boot flag so the next sign-in mounts the header again */
  document.addEventListener('click', e => { if (e.target.closest('#logout')) { window.__v1Booted = false; Q('#v1Bell')?.remove(); Q('#v1Lang')?.remove(); Q('#v1Notif')?.remove(); clearInterval(notifTimer) } }, true);
})();

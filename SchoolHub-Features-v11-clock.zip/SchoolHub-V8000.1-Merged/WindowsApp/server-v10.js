'use strict';
/* SchoolHub V10 feature pack (server).
   1 PWA + push + in-app notifications   2 Online fee payment (Razorpay)   3 Exam timetable + admit cards
   4 Scheduled fee reminders             5 Staff payroll + teacher leave   6 Student diary & remarks
   7 Syllabus / lesson-plan tracker      8 Photo gallery                   9 Login lockout + 2FA (TOTP)
   (10 = Hindi/Bengali toggle, client only: i18n in v10.js)
   Everything is stored inside the existing school-data JSON (db.*), files go through storage.js. */
const crypto = require('node:crypto');
let webpush = null; try { webpush = require('web-push'); } catch { /* push is optional: app works without it */ }

module.exports = function (ctx) {
  const D = () => ctx.db();
  const today = () => ctx.localDate();
  const nid = arr => arr.length ? Math.max(...arr.map(x => Number(x.id) || 0)) + 1 : 1;
  const num = v => Number(v);
  const r2 = ctx.round2;
  const esc = v => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  const money = n => (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const txt = (v, n = 200) => String(v ?? '').trim().slice(0, n);
  const dateOk = s => /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && !isNaN(new Date(s + 'T00:00:00'));
  const monthOk = s => /^\d{4}-(0[1-9]|1[0-2])$/.test(String(s || ''));
  const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return ctx.localDate(d); };
  const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
  const isClerk = u => !!(u && u.role === 'admin' && (D().users.find(x => Number(x.id) === Number(u.id)) || {}).clerk);
  const userRec = id => D().users.find(x => Number(x.id) === Number(id));
  const json = (res, s, o, h) => ctx.json(res, s, o, h);
  const forbid = (res, m) => json(res, 403, { error: m || 'Permission denied' });

  /* ---------- storage of everything V10 owns ---------- */
  const ARR = ['push_subs', 'notifications', 'online_payments', 'exam_schedules', 'reminder_runs', 'payroll_staff', 'payslips',
    'diary', 'syllabus', 'albums', 'gallery_photos', 'v10_settings', 'login_log'];
  function S() {
    const d = D();
    for (const k of ARR) if (!Array.isArray(d[k])) d[k] = [];
    if (!d.v10_settings.length) d.v10_settings.push({ id: 1 });
    const s = d.v10_settings[0];
    s.cursors = s.cursors || {};
    s.razorpay = Object.assign({ enabled: false, key_id: '', key_secret: '', webhook_secret: '' }, s.razorpay || {});
    s.reminders = Object.assign({ enabled: false, hour: 10, before_days: 3, overdue_every: 7, max_overdue: 4, push: true, sms: false, msg91_template: '', last_run: '' }, s.reminders || {});
    s.security = Object.assign({ max_attempts: 5, lock_minutes: 15, require_2fa_admin: false }, s.security || {});
    s.payroll = Object.assign({ per_day_basis: 'month_days', fixed_days: 30, paid_leave_per_year: 12, leave_year_start_month: 4, school_name: 'Holyfaith Academy' }, s.payroll || {});
    return s;
  }

  /* ---------- tiny router ---------- */
  const routes = [];
  const route = (method, pat, roles, fn, opts = {}) => routes.push({ method, pat: pat instanceof RegExp ? pat : new RegExp('^' + pat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$'), roles, fn, opts });

  /* =====================================================================
     9. LOGIN SECURITY: lockout, TOTP two-factor, recovery codes
     ===================================================================== */
  const fails = new Map();           // key -> { t:[timestamps], until:number }
  const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const b32enc = buf => { let bits = '', out = ''; for (const b of buf) bits += b.toString(2).padStart(8, '0'); for (let i = 0; i < bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5).padEnd(5, '0'), 2)]; return out; };
  const b32dec = s => { let bits = ''; for (const c of String(s).toUpperCase().replace(/[^A-Z2-7]/g, '')) bits += B32.indexOf(c).toString(2).padStart(5, '0'); const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(out); };
  const hotp = (secret, counter) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(counter)); const h = crypto.createHmac('sha1', secret).update(b).digest(); const o = h[19] & 15; const n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]; return String(n % 1000000).padStart(6, '0'); };
  const totpStep = () => Math.floor(Date.now() / 30000);
  /* returns the matched time-step or -1 */
  function totpCheck(secretB32, code, lastStep = 0) {
    code = String(code || '').replace(/\s/g, ''); if (!/^\d{6}$/.test(code)) return -1;
    const sec = b32dec(secretB32), st = totpStep();
    for (let w = -1; w <= 1; w++) { const s = st + w; if (s > lastStep && crypto.timingSafeEqual(Buffer.from(hotp(sec, s)), Buffer.from(code))) return s; }
    return -1;
  }
  const hashRec = c => crypto.createHash('sha256').update('rc:' + String(c).toLowerCase().replace(/[^a-z0-9]/g, '')).digest('hex');
  const totpOn = u => !!(u && u.totp && u.totp.enabled);
  function genRecovery() { const codes = []; for (let i = 0; i < 8; i++) { const h = crypto.randomBytes(5).toString('hex'); codes.push(h.slice(0, 5) + '-' + h.slice(5)); } return codes; }
  function logLogin(entry) { const l = D().login_log; l.push({ at: new Date().toISOString(), ...entry }); if (l.length > 300) D().login_log = l.slice(-300); }
  function lockState(key) {
    const s = S().security, f = fails.get(key); if (!f) return { locked: false };
    const now = Date.now(); f.t = f.t.filter(x => now - x < s.lock_minutes * 60000);
    if (f.until && f.until > now) return { locked: true, mins: Math.ceil((f.until - now) / 60000) };
    if (f.until && f.until <= now) { f.until = 0; f.t = []; }
    return { locked: false };
  }
  function recordFail(key, why, extra = {}) {
    const s = S().security, now = Date.now(); let f = fails.get(key); if (!f) { f = { t: [], until: 0 }; fails.set(key, f); }
    f.t = f.t.filter(x => now - x < s.lock_minutes * 60000); f.t.push(now);
    const lim = key.startsWith('ip:') ? s.max_attempts * 6 : s.max_attempts;
    const justLocked = f.t.length >= lim && !f.until;
    if (f.t.length >= lim) f.until = now + s.lock_minutes * 60000;
    logLogin({ key, result: justLocked ? 'locked' : why, ...extra });
    return justLocked;
  }
  setInterval(() => { const now = Date.now(); for (const [k, f] of fails) if ((!f.until || f.until < now) && (!f.t.length || now - f.t[f.t.length - 1] > 3600000)) fails.delete(k); }, 10 * 60000).unref?.();

  async function loginGuard(req, res) {
    const v = await ctx.body(req); req.__json = v;     // original handler re-uses the parsed body
    const username = String(v.username || '').trim().toLowerCase(), ip = ctx.clientIp(req), ukey = 'u:' + username, ikey = 'ip:' + ip;
    for (const k of [ukey, ikey]) { const st = lockState(k); if (st.locked) { logLogin({ key: k, result: 'blocked', username }); json(res, 429, { error: `Too many failed attempts. Please wait ${st.mins} minute${st.mins === 1 ? '' : 's'} and try again.`, code: 'LOCKED' }); return true; } }
    const f = D().users.find(x => String(x.username || '').toLowerCase() === username);
    if (!f || !ctx.verifyPassword(String(v.password || ''), f.password)) {
      recordFail(ukey, 'failed', { username, ip }); recordFail(ikey, 'failed', { username, ip });
      return false;                                    // let the original handler send its normal 401 message
    }
    if (f.role === 'admin' && totpOn(f)) {
      const code = String(v.otp || '').trim();
      if (!code) { json(res, 401, { error: 'Enter the 6-digit code from your authenticator app.', code: 'NEED_2FA' }); return true; }
      let ok = false;
      const step = totpCheck(f.totp.secret, code, f.totp.last_step || 0);
      if (step > 0) { f.totp.last_step = step; ok = true; }
      else if (/^[a-z0-9]{5}-?[a-z0-9]{5}$/i.test(code)) { const h = hashRec(code), i = (f.totp.recovery || []).indexOf(h); if (i >= 0) { f.totp.recovery.splice(i, 1); ok = true; ctx.audit({ id: f.id, name: f.name }, '2FA_RECOVERY_USED', `${f.username}: ${f.totp.recovery.length} recovery code(s) left`); } }
      if (!ok) { recordFail(ukey, '2fa_failed', { username, ip }); recordFail(ikey, '2fa_failed', { username, ip }); json(res, 401, { error: 'That code is not valid. Check the time on your phone and try again.', code: 'NEED_2FA' }); return true; }
      ctx.save();
    }
    fails.delete(ukey);
    if (f.role === 'admin') logLogin({ key: ukey, result: 'ok', username, ip });
    return false;
  }

  /* a signed-in admin must enrol in 2FA when the school switches "require" on */
  const GATE_OK = /^\/api\/(me|logout|change-password|security\/.*|login|push\/.*|notifications.*)$/;
  async function twoFaGate(req, res, p) {
    if (!S().security.require_2fa_admin || !p.startsWith('/api/') || GATE_OK.test(p)) return false;
    const u = await ctx.current(req); if (!u || u.role !== 'admin') return false;
    if (totpOn(userRec(u.id))) return false;
    json(res, 403, { error: 'Two-factor sign-in must be set up before you can continue.', code: 'SETUP_2FA' }); return true;
  }

  route('GET', '/api/security/me', [], async ({ res, u }) => {
    const r = userRec(u.id) || {}, s = S().security;
    json(res, 200, { role: u.role, totp_enabled: totpOn(r), recovery_left: totpOn(r) ? (r.totp.recovery || []).length : 0, required: !!s.require_2fa_admin && u.role === 'admin', can_use: u.role === 'admin' });
  });
  route('POST', '/api/security/2fa/setup', ['admin'], async ({ res, u }) => {
    const r = userRec(u.id); if (!r) return json(res, 404, { error: 'Account not found' });
    if (totpOn(r)) return json(res, 400, { error: 'Two-factor is already on for this account.' });
    r.totp_pending = b32enc(crypto.randomBytes(20)); ctx.save();
    const issuer = 'Holyfaith Academy SchoolHub', uri = `otpauth://totp/${encodeURIComponent(issuer + ':' + r.username)}?secret=${r.totp_pending}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
    json(res, 200, { secret: r.totp_pending, uri });
  });
  route('POST', '/api/security/2fa/enable', ['admin'], async ({ res, u, v }) => {
    const r = userRec(u.id), b = await v(); if (!r || !r.totp_pending) return json(res, 400, { error: 'Start the setup again.' });
    const step = totpCheck(r.totp_pending, b.code, 0); if (step < 0) return json(res, 400, { error: 'That code did not match. Check your phone time and try again.' });
    const codes = genRecovery(); r.totp = { enabled: true, secret: r.totp_pending, last_step: step, recovery: codes.map(hashRec), enabled_at: new Date().toISOString() }; delete r.totp_pending;
    ctx.audit(u, '2FA_ENABLED', r.username); json(res, 200, { ok: true, recovery: codes });
  });
  route('POST', '/api/security/2fa/disable', ['admin'], async ({ res, u, v }) => {
    const r = userRec(u.id), b = await v(); if (!r || !totpOn(r)) return json(res, 400, { error: 'Two-factor is not on.' });
    if (S().security.require_2fa_admin) return json(res, 400, { error: 'Two-factor is required for administrators, so it cannot be switched off.' });
    if (!ctx.verifyPassword(String(b.password || ''), r.password)) return json(res, 400, { error: 'Password is incorrect.' });
    if (totpCheck(r.totp.secret, b.code, r.totp.last_step || 0) < 0) return json(res, 400, { error: 'Authenticator code is not valid.' });
    delete r.totp; ctx.audit(u, '2FA_DISABLED', r.username); json(res, 200, { ok: true });
  });
  route('GET', '/api/security/status', ['admin'], async ({ res }) => {
    const s = S(), now = Date.now(), locked = [];
    for (const [k, f] of fails) if (f.until && f.until > now) locked.push({ key: k, mins: Math.ceil((f.until - now) / 60000) });
    const admins = D().users.filter(x => x.role === 'admin').map(x => ({ id: x.id, name: x.name, username: x.username, clerk: !!x.clerk, totp: totpOn(x) }));
    json(res, 200, { settings: s.security, locked, admins, log: D().login_log.slice(-60).reverse(), push_ready: pushReady() });
  }, { noClerk: true });
  route('PUT', '/api/security/settings', ['admin'], async ({ res, u, v }) => {
    const b = await v(), s = S().security;
    s.max_attempts = Math.min(20, Math.max(3, num(b.max_attempts) || 5)); s.lock_minutes = Math.min(240, Math.max(1, num(b.lock_minutes) || 15));
    if (b.require_2fa_admin && !totpOn(userRec(u.id))) return json(res, 400, { error: 'Turn on two-factor for your own account first, so you do not lock yourself out.' });
    s.require_2fa_admin = !!b.require_2fa_admin; ctx.audit(u, 'SECURITY_SETTINGS', `lock after ${s.max_attempts} tries for ${s.lock_minutes} min; 2FA required: ${s.require_2fa_admin}`); json(res, 200, { ok: true, settings: s });
  }, { noClerk: true });
  route('POST', '/api/security/unlock', ['admin'], async ({ res, u, v }) => {
    const b = await v(), key = String(b.key || ''); if (key === '*') fails.clear(); else fails.delete(key);
    ctx.audit(u, 'LOGIN_UNLOCK', key); json(res, 200, { ok: true });
  }, { noClerk: true });
  route('POST', '/api/security/2fa/reset', ['admin'], async ({ res, u, v }) => {
    const b = await v(), t = userRec(b.user_id); if (!t || t.role !== 'admin') return json(res, 404, { error: 'Account not found' });
    delete t.totp; delete t.totp_pending; ctx.audit(u, '2FA_RESET', t.username); json(res, 200, { ok: true });
  }, { noClerk: true });

  /* =====================================================================
     1. NOTIFICATIONS: in-app inbox + Web Push (works on Android/desktop; iPhone after "Add to Home Screen")
     ===================================================================== */
  const pushReady = () => !!webpush;
  function vapid() {
    if (!webpush) return null; const s = S();
    if (!s.vapid) { const k = webpush.generateVAPIDKeys(); s.vapid = { pub: k.publicKey, priv: k.privateKey }; ctx.save(); }
    return s.vapid;
  }
  async function sendPush(userIds, payload) {
    const vp = vapid(); if (!vp) return 0;
    const ids = new Set(userIds.map(Number)), subs = D().push_subs.filter(x => ids.has(Number(x.user_id))); if (!subs.length) return 0;
    const opts = { TTL: 86400, vapidDetails: { subject: process.env.VAPID_SUBJECT || 'mailto:admin@holyfaith.example', publicKey: vp.pub, privateKey: vp.priv } };
    const data = JSON.stringify(payload); let sent = 0, dead = [];
    for (let i = 0; i < subs.length; i += 15) {
      await Promise.all(subs.slice(i, i + 15).map(async sub => {
        try { await webpush.sendNotification({ endpoint: sub.endpoint, keys: sub.keys }, data, opts); sent++; }
        catch (e) { if (e && (e.statusCode === 404 || e.statusCode === 410)) dead.push(sub.endpoint); else console.error('Push failed:', e && (e.statusCode || e.message)); }
      }));
    }
    if (dead.length) { D().push_subs = D().push_subs.filter(x => !dead.includes(x.endpoint)); ctx.save(); }
    return sent;
  }
  /* inbox + push. payload = { title, body, url, tag } */
  async function notify(userIds, payload) {
    userIds = [...new Set(userIds.map(Number).filter(Boolean))]; if (!userIds.length) return { users: 0, push: 0 };
    const S0 = S(), d = D(); let id = nid(d.notifications); const at = new Date().toISOString();
    for (const uid of userIds) d.notifications.push({ id: id++, user_id: uid, title: txt(payload.title, 80), body: txt(payload.body, 300), url: payload.url || '', at, read: false });
    /* keep the newest 40 per user */
    const per = new Map(); for (let i = d.notifications.length - 1; i >= 0; i--) { const n = d.notifications[i], c = (per.get(n.user_id) || 0) + 1; per.set(n.user_id, c); if (c > 40) n._drop = true; }
    if (d.notifications.some(n => n._drop)) d.notifications = d.notifications.filter(n => !n._drop);
    ctx.save(); void S0;
    const pushed = await sendPush(userIds, { title: txt(payload.title, 80), body: txt(payload.body, 200), url: payload.url || '/', tag: payload.tag || 'schoolhub' }).catch(() => 0);
    return { users: userIds.length, push: pushed };
  }
  const guardiansOf = studentIds => { const set = new Set(studentIds.map(Number)); return [...new Set(D().students.filter(s => set.has(Number(s.id)) && s.guardian_id).map(s => Number(s.guardian_id)))]; };
  const usersByRole = role => D().users.filter(u => u.role === role).map(u => u.id);

  const PUSH_HOSTS = ['googleapis.com', 'push.services.mozilla.com', 'mozilla.com', 'push.apple.com', 'notify.windows.com', 'windows.com'];
  route('GET', '/api/push/key', [], async ({ res }) => { const vp = vapid(); json(res, 200, { enabled: !!vp, publicKey: vp ? vp.pub : '' }); });
  route('POST', '/api/push/subscribe', [], async ({ res, u, v }) => {
    const b = await v(), sub = b.subscription || {}; if (!sub.endpoint || !sub.keys || !sub.keys.p256dh || !sub.keys.auth) return json(res, 400, { error: 'Invalid subscription' });
    let host = ''; try { const uu = new URL(sub.endpoint); if (uu.protocol === 'https:' && !uu.port) host = uu.hostname.toLowerCase(); } catch { }
    /* only real browser push services: stops anyone from making the server call an arbitrary address */
    if (!host || !PUSH_HOSTS.some(h => host === h || host.endsWith('.' + h))) return json(res, 400, { error: 'This browser\'s push service is not supported.' });
    const d = D(); S(); d.push_subs = d.push_subs.filter(x => x.endpoint !== sub.endpoint);
    d.push_subs.push({ id: nid(d.push_subs), user_id: u.id, role: u.role, endpoint: sub.endpoint, keys: { p256dh: sub.keys.p256dh, auth: sub.keys.auth }, created: new Date().toISOString() });
    if (d.push_subs.length > 20000) d.push_subs = d.push_subs.slice(-20000);
    ctx.save(); json(res, 200, { ok: true });
  });
  route('POST', '/api/push/unsubscribe', [], async ({ res, u, v }) => { const b = await v(); S(); D().push_subs = D().push_subs.filter(x => !(x.endpoint === b.endpoint && Number(x.user_id) === Number(u.id))); ctx.save(); json(res, 200, { ok: true }); });
  route('POST', '/api/push/test', [], async ({ res, u }) => { const r = await notify([u.id], { title: 'SchoolHub notifications are on', body: 'You will now get school updates here.', url: '/', tag: 'test' }); json(res, 200, { ok: true, ...r }); });
  route('GET', '/api/notifications', [], async ({ res, u }) => { S(); const rows = D().notifications.filter(n => Number(n.user_id) === Number(u.id)).sort((a, b) => b.id - a.id).slice(0, 40); json(res, 200, { unread: rows.filter(r => !r.read).length, rows }); });
  route('POST', '/api/notifications/read', [], async ({ res, u }) => { S(); let n = 0; for (const x of D().notifications) if (Number(x.user_id) === Number(u.id) && !x.read) { x.read = true; n++; } if (n) ctx.save(); json(res, 200, { ok: true }); });

  /* background watcher: turns new announcements / homework / absences / messages etc. into notifications.
     First run only records where things stand, so nobody is flooded with old items. */
  const maxId = arr => arr.reduce((m, x) => Math.max(m, Number(x.id) || 0), 0);
  async function pollEvents() {
    const d = D(), s = S(), c = s.cursors; S();
    const first = c.init !== true;
    const take = (key, arr) => { const last = first ? maxId(arr) : (c[key] ?? maxId(arr)); const fresh = first ? [] : arr.filter(x => Number(x.id) > last); c[key] = Math.max(last, maxId(arr)); return fresh; };
    const jobs = [];
    for (const a of take('announcements', d.announcements)) {
      const aud = String(a.audience || 'All'); let to = [];
      if (/teacher|staff/i.test(aud)) to = usersByRole('teacher'); else if (/guardian|parent/i.test(aud)) to = usersByRole('guardian'); else to = [...usersByRole('guardian'), ...usersByRole('teacher')];
      jobs.push([to, { title: 'Announcement: ' + a.title, body: a.body, url: '/#page=Announcements', tag: 'ann-' + a.id }]);
    }
    for (const h of take('homework', d.homework)) {
      const kids = d.students.filter(st => Number(st.year_id) === Number(h.year_id) && Number(st.class_id) === Number(h.class_id) && Number(st.section_id) === Number(h.section_id)).map(st => st.id);
      jobs.push([guardiansOf(kids), { title: 'New homework: ' + h.title, body: (h.due_date ? 'Due ' + h.due_date + '. ' : '') + String(h.description || ''), url: '/#page=Homework', tag: 'hw-' + h.id }]);
    }
    { /* absences marked today */
      const t = today(); c.sent_keys = c.sent_keys || [];
      const fresh = take('attendance', d.attendance).filter(a => a.status === 'Absent' && a.date === t);
      const sent = new Set(c.sent_keys);
      for (const a of fresh) { const k = 'abs|' + a.student_id + '|' + a.date; if (sent.has(k)) continue; sent.add(k); c.sent_keys.push(k); const st = d.students.find(x => Number(x.id) === Number(a.student_id)); if (st && st.guardian_id) jobs.push([[st.guardian_id], { title: st.name + ' was marked absent', body: 'Attendance for ' + a.date + ' shows absent. Please contact the class teacher if this is a mistake.', url: '/#page=Attendance', tag: k }]); }
      if (c.sent_keys.length > 3000) c.sent_keys = c.sent_keys.slice(-2000);
    }
    for (const e of take('diary', d.diary)) {
      if (!e.visible_to_guardian) continue; let kids = [];
      if (e.student_id) kids = [e.student_id]; else kids = d.students.filter(st => Number(st.class_id) === Number(e.class_id) && (!Number(e.section_id) || Number(st.section_id) === Number(e.section_id))).map(st => st.id);
      jobs.push([guardiansOf(kids), { title: 'School diary: ' + (e.title || e.type), body: e.body, url: '/#page=Student Diary', tag: 'diary-' + e.id }]);
    }
    for (const sc of d.exam_schedules) {
      if (first) { sc.notified = true; continue; }
      if (sc.published && !sc.notified) { sc.notified = true; const kids = d.students.filter(st => Number(st.class_id) === Number(sc.class_id)).map(st => st.id); jobs.push([guardiansOf(kids), { title: 'Exam timetable published', body: sc.title + ' — open Exam Timetable to see dates and download the admit card.', url: '/#page=Exam Timetable', tag: 'exam-' + sc.id }]); }
    }
    for (const al of take('albums', d.albums)) {
      let to = usersByRole('guardian'); if (Number(al.class_id)) to = guardiansOf(d.students.filter(st => Number(st.class_id) === Number(al.class_id)).map(st => st.id));
      jobs.push([to, { title: 'New photos: ' + al.title, body: 'Photos were added to the school gallery.', url: '/#page=Photo Gallery', tag: 'album-' + al.id }]);
    }
    for (const ps of d.payslips) { if (first) { ps.notified = true; continue; } if (ps.status === 'Paid' && !ps.notified && ps.user_id) { ps.notified = true; jobs.push([[ps.user_id], { title: 'Salary slip ready', body: 'Your payslip for ' + ps.month + ' is available under My Payslips.', url: '/#page=My Payslips', tag: 'ps-' + ps.id }]); } }
    if (ctx.pool()) {
      try {
        const r = await ctx.pool().query('SELECT id,sender_id,recipient_id,body FROM messages WHERE id>$1 ORDER BY id LIMIT 300', [Number(c.messages || 0)]);
        const rows = (r.rows || []).filter(m => Number(m.id) > Number(c.messages || 0)).sort((a, b) => a.id - b.id);
        const top = rows.length ? Number(rows[rows.length - 1].id) : Number(c.messages || 0);
        if (first) { const all = await ctx.pool().query('SELECT id FROM messages ORDER BY id DESC LIMIT 1'); c.messages = all.rows && all.rows[0] ? Number(all.rows[0].id) : 0; }
        else { c.messages = top; for (const m of rows) { const from = userRec(m.sender_id); jobs.push([[m.recipient_id], { title: 'Message from ' + (from ? from.name : 'school'), body: String(m.body || ''), url: '/#page=Messages', tag: 'msg-' + m.id }]); } }
      } catch (e) { /* messages table may not exist yet */ }
    }
    c.init = true; ctx.save();
    for (const [to, p] of jobs) { try { await notify(to, p); } catch (e) { console.error('Notify failed:', e.message); } }
    return jobs.length;
  }

  /* =====================================================================
     2. ONLINE FEE PAYMENT (Razorpay Checkout). Keys: env RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET /
        RAZORPAY_WEBHOOK_SECRET or Administrator > Online Payments. Money is applied through the same
        applyPayment() as the office, so receipts, Day Book, ledger and payment log all stay consistent.
     ===================================================================== */
  const rzp = () => { const r = S().razorpay, e = process.env; return { enabled: !!(e.RAZORPAY_KEY_ID || r.enabled) && !!((e.RAZORPAY_KEY_ID || r.key_id) && (e.RAZORPAY_KEY_SECRET || r.key_secret)), key_id: e.RAZORPAY_KEY_ID || r.key_id || '', secret: e.RAZORPAY_KEY_SECRET || r.key_secret || '', webhook: e.RAZORPAY_WEBHOOK_SECRET || r.webhook_secret || '', base: e.RAZORPAY_API_BASE || 'https://api.razorpay.com/v1', from_env: !!e.RAZORPAY_KEY_ID }; };
  const hmac = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('hex');
  const safeEq = (a, b) => { a = Buffer.from(String(a)); b = Buffer.from(String(b)); return a.length === b.length && crypto.timingSafeEqual(a, b); };
  const dueOf = sid => r2(D().fees.filter(f => Number(f.student_id) === Number(sid) && !f.cancelled).reduce((n, f) => n + ctx.feeBal(f), 0));

  function settleOnline(op, paymentId, via) {
    if (op.status === 'Paid') return { ok: true, receipt: op.receipt, already: true };
    const g = userRec(op.guardian_id) || { id: op.guardian_id, name: 'Guardian' };
    const r = ctx.applyPayment(op.student_id, op.amount, { mode: 'Other', instrument: 'RZP ' + paymentId, date: today(), user: { id: g.id, name: g.name + ' (online)', role: 'guardian' }, remark: 'Online payment (Razorpay)', note: 'Online payment ' + paymentId });
    op.payment_id = paymentId; op.settled_via = via; op.settled_at = new Date().toISOString();
    if (r.error) { op.status = 'Needs review'; op.note = 'Money was received but no fee could be marked paid (' + r.error + '). Refund it from the Razorpay dashboard or record it manually.'; ctx.save(); return { ok: false, error: op.note }; }
    op.status = 'Paid'; op.receipt = r.receipt; op.applied = r.received; if (r.excess > 0) { op.note = 'Excess ₹' + money(r.excess) + ' was not applied (nothing left to pay). Refund it from Razorpay.'; }
    ctx.audit({ id: g.id, name: g.name }, 'ONLINE_PAYMENT', `₹${money(r.received)} receipt ${r.receipt} (${paymentId})`);
    ctx.save();
    notify([op.guardian_id], { title: 'Payment received', body: `₹${money(r.received)} received. Receipt ${r.receipt}.`, url: '/#page=Pay Online', tag: 'pay-' + op.id }).catch(() => { });
    return { ok: true, receipt: r.receipt, received: r.received };
  }

  route('GET', '/api/pay/config', [], async ({ res }) => { const c = rzp(); json(res, 200, { enabled: c.enabled, key_id: c.enabled ? c.key_id : '' }); });
  route('GET', '/api/pay/mine', ['guardian'], async ({ res, u }) => {
    S(); const kids = ctx.scope(u).map(s => ({ id: s.id, name: s.name, class_name: s.class_name, section_name: s.section_name, due: dueOf(s.id) }));
    const hist = D().online_payments.filter(x => Number(x.guardian_id) === Number(u.id)).sort((a, b) => b.id - a.id).slice(0, 30).map(x => ({ id: x.id, student: (D().students.find(s => Number(s.id) === Number(x.student_id)) || {}).name || '', amount: x.amount, status: x.status, receipt: x.receipt || '', created_at: x.created_at, payment_id: x.payment_id || '' }));
    json(res, 200, { enabled: rzp().enabled, kids, history: hist });
  });
  route('POST', '/api/pay/order', ['guardian'], async ({ res, u, v }) => {
    const c = rzp(); if (!c.enabled) return json(res, 400, { error: 'Online payment is not switched on yet. Please pay at the school office.' });
    const b = await v(), st = ctx.studentForUser(u, num(b.student_id)); if (!st) return forbid(res);
    const due = dueOf(st.id); if (!(due > 0)) return json(res, 400, { error: 'There are no pending fees for this student.' });
    let amt = b.amount === undefined || b.amount === '' ? due : r2(b.amount); if (!(amt >= 1)) return json(res, 400, { error: 'Enter an amount of at least ₹1.' }); if (amt > due) amt = due;
    const d = D(); S();
    const open = d.online_payments.filter(x => Number(x.guardian_id) === Number(u.id) && x.status === 'Created' && Date.now() - Date.parse(x.created_at) < 600000).length; if (open >= 5) return json(res, 429, { error: 'Please finish or wait for your earlier payment attempts first.' });
    const op = { id: nid(d.online_payments), student_id: st.id, guardian_id: u.id, amount: amt, status: 'Created', created_at: new Date().toISOString() };
    let order;
    try {
      const r = await fetch(c.base + '/orders', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + Buffer.from(c.key_id + ':' + c.secret).toString('base64') }, body: JSON.stringify({ amount: Math.round(amt * 100), currency: 'INR', receipt: 'SH' + op.id, notes: { student_id: String(st.id), guardian_id: String(u.id) } }), signal: AbortSignal.timeout(15000) });
      order = await r.json().catch(() => ({})); if (!r.ok || !order.id) throw new Error((order.error && order.error.description) || ('Razorpay error ' + r.status));
    } catch (e) { console.error('Razorpay order failed:', e.message); return json(res, 502, { error: 'Could not start the payment. Please try again in a moment.' }); }
    op.order_id = order.id; d.online_payments.push(op); ctx.save();
    json(res, 200, { order_id: order.id, key_id: c.key_id, amount: Math.round(amt * 100), name: 'Holyfaith Academy', description: 'School fees — ' + st.name, prefill: { name: u.name || '', contact: String(u.phone || '').replace(/\D/g, '').slice(-10), email: u.email || '' } });
  });
  route('POST', '/api/pay/verify', ['guardian'], async ({ res, u, v }) => {
    const c = rzp(), b = await v(), oid = String(b.razorpay_order_id || ''), pid = String(b.razorpay_payment_id || ''), sig = String(b.razorpay_signature || '');
    const op = D().online_payments.find(x => x.order_id === oid && Number(x.guardian_id) === Number(u.id)); if (!op) return json(res, 404, { error: 'Payment not found' });
    if (op.status === 'Paid') return json(res, 200, { ok: true, receipt: op.receipt, received: op.applied });
    if (!pid || !safeEq(hmac(c.secret, oid + '|' + pid), sig)) { op.status = 'Failed'; ctx.save(); return json(res, 400, { error: 'Payment could not be verified. If money was deducted, it will be matched automatically or refunded.' }); }
    const r = settleOnline(op, pid, 'checkout'); json(res, r.ok ? 200 : 409, r.ok ? r : { error: r.error });
  });
  /* Razorpay webhook: also settles payments when the parent closes the browser before it returns */
  route('POST', '/api/pay/webhook', false, async ({ req, res }) => {
    const c = rzp(); if (!c.webhook) return json(res, 503, { error: 'Webhook secret is not set' });
    const raw = await new Promise((ok, no) => { let s = ''; req.on('data', x => { s += x; if (s.length > 1e6) req.destroy(); }); req.on('end', () => ok(s)); req.on('error', no); });
    if (!safeEq(hmac(c.webhook, raw), String(req.headers['x-razorpay-signature'] || ''))) return json(res, 400, { error: 'Bad signature' });
    let ev; try { ev = JSON.parse(raw); } catch { return json(res, 400, { error: 'Bad JSON' }); }
    const pay = ev && ev.payload && ev.payload.payment && ev.payload.payment.entity;
    if (pay && (ev.event === 'payment.captured' || ev.event === 'order.paid') && pay.status === 'captured') {
      const op = D().online_payments.find(x => x.order_id === pay.order_id);
      if (op && op.status !== 'Paid' && Math.round(op.amount * 100) === Number(pay.amount)) settleOnline(op, pay.id, 'webhook');
    }
    json(res, 200, { ok: true });
  });
  route('GET', '/api/pay/admin', ['admin'], async ({ res }) => {
    const c = rzp(), s = S().razorpay, d = D();
    const rows = d.online_payments.slice().sort((a, b) => b.id - a.id).slice(0, 150).map(x => { const st = d.students.find(q => Number(q.id) === Number(x.student_id)) || {}; return { id: x.id, student: st.name || '', amount: x.amount, status: x.status, receipt: x.receipt || '', payment_id: x.payment_id || '', created_at: x.created_at, note: x.note || '', via: x.settled_via || '' }; });
    json(res, 200, { enabled: c.enabled, from_env: c.from_env, key_id: c.key_id, has_secret: !!c.secret, has_webhook: !!c.webhook, toggle: !!s.enabled, rows });
  });
  route('PUT', '/api/pay/settings', ['admin'], async ({ res, u, v }) => {
    if (isClerk(u)) return forbid(res); const b = await v(), s = S().razorpay;
    if (b.key_id !== undefined) s.key_id = txt(b.key_id, 80); if (b.key_secret) s.key_secret = txt(b.key_secret, 120); if (b.webhook_secret) s.webhook_secret = txt(b.webhook_secret, 120); s.enabled = !!b.enabled;
    ctx.audit(u, 'ONLINE_PAYMENT_SETTINGS', 'enabled: ' + s.enabled); json(res, 200, { ok: true });
  });

  /* =====================================================================
     4. SCHEDULED FEE REMINDERS (push + in-app inbox + optional SMS through the existing SMS provider settings)
        stage "due":     first time a fee is within N days of its due date (or already due but not overdue) -> once
        stage "overdue": after the grace day, every X days, at most M times
     ===================================================================== */
  const inr = n => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  async function sendSms(mobile, text, vars) {
    const c = ctx.smsConfig(), enc = encodeURIComponent, sig = () => AbortSignal.timeout(12000);
    if (!ctx.smsReady(c) || c.provider === 'manual') throw new Error('SMS provider is not set up');
    if (c.provider === 'console') { console.log(`[SMS test mode] to ${mobile}: ${text}`); return; }
    if (c.provider === 'twilio') { const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${enc(c.account_sid)}/Messages.json`, { method: 'POST', headers: { Authorization: 'Basic ' + Buffer.from(c.account_sid + ':' + c.auth_key).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ To: '+91' + mobile, From: c.from_number, Body: text }), signal: sig() }); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error('Twilio: ' + (j.message || r.status)); return; }
    if (c.provider === 'fast2sms') { const r = await fetch(`https://www.fast2sms.com/dev/bulkV2?authorization=${enc(c.auth_key)}&route=q&message=${enc(text)}&language=english&flash=0&numbers=${mobile}`, { signal: sig() }); const j = await r.json().catch(() => ({})); if (!r.ok || j.return === false) throw new Error('Fast2SMS: ' + (Array.isArray(j.message) ? j.message.join(', ') : j.message || r.status)); return; }
    if (c.provider === 'msg91') { const tpl = S().reminders.msg91_template; if (!tpl) throw new Error('MSG91 needs a flow template id in Fee Reminders settings'); const r = await fetch('https://control.msg91.com/api/v5/flow/', { method: 'POST', headers: { authkey: c.auth_key, 'Content-Type': 'application/json' }, body: JSON.stringify({ template_id: tpl, short_url: '0', recipients: [{ mobiles: '91' + mobile, name: vars.name, student: vars.student, amount: vars.amount }] }), signal: sig() }); const j = await r.json().catch(() => ({})); if (!r.ok || String(j.type).toLowerCase() === 'error') throw new Error('MSG91: ' + (j.message || r.status)); return; }
    throw new Error('Unknown SMS provider');
  }
  const mobileFor = (g, kids) => { for (const x of [g.phone, ...kids.map(k => k.guardian_phone), ...kids.map(k => k.phone)]) if (ctx.validMobile(x)) return ctx.normPhone(x); return ''; };
  /* what would be sent right now? (read-only) */
  function dueMessages() {
    const R = S().reminders, rules = ctx.feeRules(), t = today(), d = D(), per = new Map(); let noGuardian = 0;
    for (const f of d.fees) {
      if (f.cancelled || !(ctx.feeBal(f) > 0)) continue;
      const st = d.students.find(s => Number(s.id) === Number(f.student_id)); if (!st || String(st.status || 'Active').toLowerCase() !== 'active') continue;
      const od = ctx.feeOverdueDate(f, rules), due = String(f.due_date || ''); let stage = '';
      if (t > od) { if (Number(f.rem_count || 0) < R.max_overdue && (!f.rem_last || daysBetween(f.rem_last, t) >= R.overdue_every)) stage = 'overdue'; }
      else if (!f.rem_due && /^\d{4}-\d{2}-\d{2}$/.test(due) && t >= addDays(due, -R.before_days)) stage = 'due';
      if (!stage) continue;
      if (!st.guardian_id) { noGuardian++; continue; }
      const key = st.guardian_id + '|' + st.id; if (!per.has(key)) per.set(key, { guardian_id: st.guardian_id, student: st, due: 0, overdue: 0, fees: [] });
      const e = per.get(key); e.due = r2(e.due + ctx.feeBal(f)); if (stage === 'overdue') e.overdue = r2(e.overdue + ctx.feeBal(f)); e.fees.push({ f, stage });
    }
    const byG = new Map(); for (const e of per.values()) { if (!byG.has(e.guardian_id)) byG.set(e.guardian_id, []); byG.get(e.guardian_id).push(e); }
    const out = [];
    for (const [gid, list] of byG) {
      const g = userRec(gid); if (!g) continue; const kids = list.map(e => e.student);
      const parts = list.map(e => `${e.student.name} ${inr(e.due)}${e.overdue ? ' (overdue ' + inr(e.overdue) + ')' : ''}`);
      const total = r2(list.reduce((n, e) => n + e.due, 0)), anyOver = list.some(e => e.overdue > 0);
      out.push({ guardian_id: gid, guardian: g.name, mobile: mobileFor(g, kids), kids: kids.map(k => k.name), total, overdue: anyOver, fees: list.flatMap(e => e.fees),
        title: anyOver ? 'Fee overdue' : 'Fee reminder', body: `Fees pending: ${parts.join(', ')}. Please pay at the school office${rzp().enabled ? ' or online from Pay Online' : ''}. — Holyfaith Academy`,
        sms: `Dear ${g.name}, fees pending: ${parts.join(', ')}. Please pay at school${rzp().enabled ? ' or online in the SchoolHub app' : ''}. Holyfaith Academy`, vars: { name: g.name, student: kids.map(k => k.name).join(', '), amount: String(total) } });
    }
    return { messages: out, no_guardian: noGuardian };
  }
  let remRunning = false;
  async function runReminders(trigger) {
    if (remRunning) return { error: 'A reminder run is already in progress' }; remRunning = true;
    try {
      const R = S().reminders, { messages, no_guardian } = dueMessages(), t = today();
      const run = { at: new Date().toISOString(), trigger, guardians: messages.length, push_devices: 0, sms_sent: 0, sms_failed: 0, no_mobile: 0, no_guardian, errors: [] };
      for (const m of messages) {
        if (R.push) { const r = await notify([m.guardian_id], { title: m.title, body: m.body, url: '/#page=Fees', tag: 'fee-' + m.guardian_id }); run.push_devices += r.push; }
        else if (true) { /* inbox only */ await notify([m.guardian_id], { title: m.title, body: m.body, url: '/#page=Fees', tag: 'fee-' + m.guardian_id }); }
        if (R.sms) { if (!m.mobile) run.no_mobile++; else { try { await sendSms(m.mobile, m.sms, m.vars); run.sms_sent++; } catch (e) { run.sms_failed++; if (run.errors.length < 5) run.errors.push(e.message); } } }
        for (const { f, stage } of m.fees) { if (stage === 'due') f.rem_due = true; else { f.rem_count = Number(f.rem_count || 0) + 1; } f.rem_last = t; }
      }
      const d = D(); S(); d.reminder_runs.push(run); if (d.reminder_runs.length > 60) d.reminder_runs = d.reminder_runs.slice(-60); R.last_run = t; ctx.save(); return run;
    } finally { remRunning = false; }
  }
  route('GET', '/api/reminders', ['admin'], async ({ res }) => { const R = S().reminders, p = dueMessages(); json(res, 200, { settings: R, sms_ready: ctx.smsReady(), sms_provider: ctx.smsConfig().provider || '', pending: p.messages.map(m => ({ guardian: m.guardian, kids: m.kids, total: m.total, overdue: m.overdue, mobile: m.mobile ? '••••••' + m.mobile.slice(-4) : '' })), no_guardian: p.no_guardian, runs: D().reminder_runs.slice(-15).reverse() }); });
  route('PUT', '/api/reminders', ['admin'], async ({ res, u, v }) => {
    const b = await v(), R = S().reminders;
    R.enabled = !!b.enabled; R.hour = Math.min(22, Math.max(6, num(b.hour) || 10)); R.before_days = Math.min(15, Math.max(0, Number.isFinite(num(b.before_days)) ? num(b.before_days) : 3)); R.overdue_every = Math.min(30, Math.max(1, num(b.overdue_every) || 7)); R.max_overdue = Math.min(12, Math.max(1, num(b.max_overdue) || 4)); R.push = b.push !== false; R.sms = !!b.sms; R.msg91_template = txt(b.msg91_template, 60);
    ctx.audit(u, 'REMINDER_SETTINGS', `${R.enabled ? 'on' : 'off'} at ${R.hour}:00`); json(res, 200, { ok: true });
  }, { noClerk: true });
  route('POST', '/api/reminders/run', ['admin'], async ({ res, u }) => { const r = await runReminders('manual by ' + u.name); json(res, r.error ? 409 : 200, r); }, { noClerk: true });

  /* =====================================================================
     3. EXAM TIMETABLE + ADMIT CARDS
     ===================================================================== */
  const teacherOk = (u, classId, sectionId = 0) => { if (u.role === 'admin') return true; const t = userRec(u.id) || {}; return u.role === 'teacher' && (Number(t.class_id) === 0 || Number(t.class_id) === Number(classId)) && (!Number(sectionId) || Number(t.section_id) === 0 || Number(t.section_id) === Number(sectionId)); };
  const overdueBal = sid => { const rules = ctx.feeRules(), t = today(); return r2(D().fees.filter(f => Number(f.student_id) === Number(sid) && !f.cancelled && ctx.feeBal(f) > 0 && t > ctx.feeOverdueDate(f, rules)).reduce((n, f) => n + ctx.feeBal(f), 0)); };
  function cleanEntries(list) {
    const out = []; for (const e of (Array.isArray(list) ? list : []).slice(0, 40)) { if (!dateOk(e.date)) continue; const sub = D().subjects.find(s => Number(s.id) === Number(e.subject_id)); const name = txt(e.subject_name || (sub && sub.name), 60); if (!name) continue; out.push({ date: e.date, subject_id: sub ? sub.id : 0, subject_name: name, start: txt(e.start, 8), end: txt(e.end, 8), room: txt(e.room, 30), max_marks: Math.max(0, num(e.max_marks) || 0) }); }
    return out.sort((a, b) => a.date.localeCompare(b.date) || String(a.start).localeCompare(String(b.start)));
  }
  const schedView = (s, u) => { const cl = D().classes.find(c => Number(c.id) === Number(s.class_id)); return { id: s.id, title: s.title, class_id: s.class_id, class_name: cl ? cl.name : 'All classes', year_id: s.year_id, entries: s.entries, instructions: s.instructions || '', published: !!s.published, require_fee_clear: !!s.require_fee_clear, override_students: u.role === 'guardian' ? undefined : (s.override_students || []), reporting_time: s.reporting_time || '' }; };
  route('GET', '/api/exam-schedules', [], async ({ res, u }) => {
    S(); let rows = D().exam_schedules.slice();
    if (u.role === 'guardian') { const cls = new Set(ctx.scope(u).map(s => Number(s.class_id))); rows = rows.filter(s => s.published && (!Number(s.class_id) || cls.has(Number(s.class_id)))); }
    else if (u.role === 'teacher') rows = rows.filter(s => teacherOk(u, s.class_id));
    const kids = u.role === 'guardian' ? ctx.scope(u).map(s => ({ id: s.id, name: s.name, class_id: s.class_id, overdue: overdueBal(s.id) })) : [];
    json(res, 200, { rows: rows.sort((a, b) => b.id - a.id).map(s => schedView(s, u)), kids });
  });
  const saveSched = async (u, v, item) => {
    const b = await v(), d = D(); const title = txt(b.title, 80); if (!title) return { error: 'Give the exam a title (for example "Half-Yearly 2026").' };
    const cid = Math.max(0, num(b.class_id) || 0); if (cid && !d.classes.some(c => Number(c.id) === cid)) return { error: 'Choose a valid class.' }; if (!teacherOk(u, cid)) return { error: 'You can only schedule exams for your own class.' };
    const entries = cleanEntries(b.entries); if (!entries.length) return { error: 'Add at least one paper with a date and subject.' };
    Object.assign(item, { title, class_id: cid, year_id: num(b.year_id) || ((d.years.find(y => y.is_current) || {}).id || 0), entries, instructions: txt(b.instructions, 1200), reporting_time: txt(b.reporting_time, 20), published: !!b.published, require_fee_clear: !!b.require_fee_clear });
    return { item };
  };
  route('POST', '/api/exam-schedules', ['admin', 'teacher'], async ({ res, u, v }) => { const d = D(); S(); const item = { id: nid(d.exam_schedules), created_by: u.id, override_students: [] }; const r = await saveSched(u, v, item); if (r.error) return json(res, 400, r); d.exam_schedules.push(item); ctx.audit(u, 'EXAM_SCHEDULE_CREATE', item.title); json(res, 200, { ok: true, id: item.id }); });
  route('PUT', /^\/api\/exam-schedules\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, v, mm }) => { const item = D().exam_schedules.find(x => x.id === num(mm[1])); if (!item) return json(res, 404, { error: 'Not found' }); if (!teacherOk(u, item.class_id)) return forbid(res); const was = item.published; const r = await saveSched(u, v, item); if (r.error) return json(res, 400, r); if (!was && item.published) item.notified = false; ctx.audit(u, 'EXAM_SCHEDULE_UPDATE', item.title); json(res, 200, { ok: true }); });
  route('DELETE', /^\/api\/exam-schedules\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm }) => { const item = D().exam_schedules.find(x => x.id === num(mm[1])); if (!item) return json(res, 404, { error: 'Not found' }); if (!teacherOk(u, item.class_id)) return forbid(res); D().exam_schedules = D().exam_schedules.filter(x => x !== item); ctx.audit(u, 'EXAM_SCHEDULE_DELETE', item.title); json(res, 200, { ok: true }); });
  route('POST', /^\/api\/exam-schedules\/(\d+)\/override$/, ['admin'], async ({ res, u, v, mm }) => { const item = D().exam_schedules.find(x => x.id === num(mm[1])); if (!item) return json(res, 404, { error: 'Not found' }); const b = await v(), sid = num(b.student_id); item.override_students = (item.override_students || []).filter(x => x !== sid); if (b.allow) item.override_students.push(sid); ctx.audit(u, 'ADMIT_OVERRIDE', `${item.title} student ${sid}: ${!!b.allow}`); json(res, 200, { ok: true }); });

  const page = (title, body, css = '') => `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>*{box-sizing:border-box}body{font:14px/1.45 "Segoe UI",Arial,sans-serif;color:#111;margin:0;padding:18px;background:#fff}h1,h2,h3{margin:0}.bar{display:flex;gap:8px;margin-bottom:14px}.bar button{padding:8px 14px;border:1px solid #888;background:#f5f5f5;border-radius:6px;cursor:pointer;font:inherit}table{border-collapse:collapse;width:100%}th,td{border:1px solid #333;padding:5px 8px;text-align:left}th{background:#eee}.r{text-align:right}.muted{color:#555}${css}@media print{.bar{display:none}body{padding:0}@page{size:A4;margin:10mm}}</style></head><body><div class="bar"><button onclick="print()">Print / Save as PDF</button><button onclick="close()">Close</button></div>${body}</body></html>`;
  const sendHtml = (res, code, html) => ctx.send(res, code, html, { 'Cache-Control': 'private, no-store' });
  const fmtD = iso => { const d = new Date(iso + 'T00:00:00'); return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ' (' + d.toLocaleDateString('en-GB', { weekday: 'short' }) + ')'; };
  function admitCard(sc, st) {
    const d = D(), g = d.users.find(x => Number(x.id) === Number(st.guardian_id)), photo = st.photo ? `<img src="${esc(st.photo)}" alt="" style="width:78px;height:96px;object-fit:cover;border:1px solid #333">` : `<div style="width:78px;height:96px;border:1px dashed #666;display:flex;align-items:center;justify-content:center;font-size:11px;color:#666">PHOTO</div>`;
    const rows = sc.entries.map(e => `<tr><td>${esc(fmtD(e.date))}</td><td><b>${esc(e.subject_name)}</b></td><td>${esc(e.start)}${e.end ? ' – ' + esc(e.end) : ''}</td><td>${esc(e.room)}</td></tr>`).join('');
    return `<section class="card"><div style="display:flex;align-items:center;gap:12px;border-bottom:2px solid #111;padding-bottom:8px"><img src="/assets/holyfaith-logo.png" alt="" style="height:54px"><div style="flex:1;text-align:center"><h2>HOLYFAITH ACADEMY</h2><div style="font-weight:700;letter-spacing:1px">ADMIT CARD — ${esc(sc.title)}</div></div></div>
<div style="display:flex;gap:14px;margin:10px 0"><div style="flex:1"><table style="border:0"><tr><td style="border:0;width:120px" class="muted">Student</td><td style="border:0"><b>${esc(st.name)}</b></td></tr><tr><td style="border:0" class="muted">Class / Section</td><td style="border:0">${esc(st.class_name)} ${esc(st.section_name)}</td></tr><tr><td style="border:0" class="muted">Roll no. / ID</td><td style="border:0">${esc(st.roll_no)} / ${esc(st.student_id)}</td></tr><tr><td style="border:0" class="muted">Guardian</td><td style="border:0">${esc(g ? g.name : st.guardian_name || '')}</td></tr>${sc.reporting_time ? `<tr><td style="border:0" class="muted">Report by</td><td style="border:0">${esc(sc.reporting_time)}</td></tr>` : ''}</table></div>${photo}</div>
<table><thead><tr><th>Date</th><th>Subject</th><th>Time</th><th>Room</th></tr></thead><tbody>${rows}</tbody></table>
${sc.instructions ? `<p style="font-size:12px;margin:8px 0 0"><b>Instructions:</b> ${esc(sc.instructions).replace(/\n/g, '<br>')}</p>` : ''}
<div style="display:flex;justify-content:space-between;margin-top:34px;font-size:12px"><span>Class Teacher</span><span>Principal</span></div></section>`;
  }
  const admitCss = '.card{border:1.5px solid #111;padding:12px;margin-bottom:14px;break-inside:avoid;page-break-inside:avoid;max-width:760px}@media print{.card{page-break-after:always;margin:0}}';
  route('GET', /^\/api\/admit-card\/(\d+)\/(\d+)$/, [], async ({ res, u, mm }) => {
    const sc = D().exam_schedules.find(x => x.id === num(mm[1])); const st = ctx.studentForUser(u, num(mm[2]));
    if (!sc || !st) return sendHtml(res, 404, page('Admit card', '<p>Admit card not found.</p>'));
    if (Number(sc.class_id) && Number(sc.class_id) !== Number(st.class_id)) return sendHtml(res, 404, page('Admit card', '<p>This exam is not for this student\'s class.</p>'));
    if (u.role === 'guardian') {
      if (!sc.published) return sendHtml(res, 403, page('Admit card', '<p>The exam timetable has not been published yet.</p>'));
      const ob = overdueBal(st.id); if (sc.require_fee_clear && ob > 0 && !(sc.override_students || []).includes(Number(st.id))) return sendHtml(res, 403, page('Admit card', `<h3>Admit card is on hold</h3><p>${esc(st.name)} has overdue fees of ₹${money(ob)}. Please clear the dues (online or at the office) and the admit card will open here.</p>`));
    }
    sendHtml(res, 200, page('Admit card — ' + st.name, admitCard(sc, st), admitCss));
  });
  route('GET', /^\/api\/admit-cards\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm, url }) => {
    const sc = D().exam_schedules.find(x => x.id === num(mm[1])); if (!sc) return sendHtml(res, 404, page('Admit cards', '<p>Not found.</p>'));
    const sec = num(url.searchParams.get('section_id')) || 0, withDues = url.searchParams.get('skip_dues') === '1';
    let kids = ctx.scope(u).filter(s => (!Number(sc.class_id) || Number(s.class_id) === Number(sc.class_id)) && (!sec || Number(s.section_id) === sec) && String(s.status || 'Active').toLowerCase() === 'active');
    const skipped = []; if (withDues) kids = kids.filter(s => { if (overdueBal(s.id) > 0 && !(sc.override_students || []).includes(Number(s.id))) { skipped.push(s.name); return false; } return true; });
    kids.sort((a, b) => (Number(a.section_id) - Number(b.section_id)) || ((Number(a.roll_no) || 0) - (Number(b.roll_no) || 0)));
    sendHtml(res, 200, page('Admit cards — ' + sc.title, (skipped.length ? `<p class="bar muted">Skipped (overdue fees): ${esc(skipped.join(', '))}</p>` : '') + (kids.map(s => admitCard(sc, s)).join('') || '<p>No students found.</p>'), admitCss));
  });

  /* =====================================================================
     5. STAFF PAYROLL + TEACHER LEAVE BALANCE
        Loss of pay = days marked Absent + Leave days beyond the yearly paid-leave allowance.
        Days with no attendance entry are counted as present. Everything stays editable on the draft payslip.
     ===================================================================== */
  const PR = () => S().payroll;
  const dim = month => new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate();
  const leaveYearStart = iso => { const sm = Number(PR().leave_year_start_month) || 4, y = Number(iso.slice(0, 4)), m = Number(iso.slice(5, 7)); return `${m >= sm ? y : y - 1}-${String(sm).padStart(2, '0')}-01`; };
  const perDayDivisor = month => { const b = PR().per_day_basis; if (b === 'fixed') return Math.max(1, Number(PR().fixed_days) || 30); const n = dim(month); if (b === 'exclude_sundays') { let c = 0; for (let i = 1; i <= n; i++) if (new Date(+month.slice(0, 4), +month.slice(5, 7) - 1, i).getDay() !== 0) c++; return c; } return n; };
  function attStats(userId, month) {
    const rows = (D().teacher_attendance || []).filter(a => Number(a.teacher_id) === Number(userId)), first = month + '-01', ys = leaveYearStart(first), entitled = Number(PR().paid_leave_per_year) || 0;
    const inM = rows.filter(a => String(a.date).slice(0, 7) === month), absent = inM.filter(a => a.status === 'Absent').length, leave = inM.filter(a => a.status === 'Leave').length;
    const usedBefore = rows.filter(a => a.status === 'Leave' && a.date >= ys && a.date < first).length, remaining = Math.max(0, entitled - usedBefore), paidLeave = Math.min(leave, remaining);
    return { absent, leave, paid_leave: paidLeave, unpaid_leave: leave - paidLeave, entitled, used_before: usedBefore, remaining_after: Math.max(0, remaining - paidLeave) };
  }
  function buildPayslip(prof, month, adj = {}) {
    const n = x => Math.max(0, r2(x)), basic = n(prof.basic), hra = n(prof.hra), da = n(prof.da), oth = n(prof.other_allowance), bonus = n(adj.bonus);
    const st = prof.user_id ? attStats(prof.user_id, month) : { absent: 0, leave: 0, paid_leave: 0, unpaid_leave: 0 };
    const gross = r2(basic + hra + da + oth), divisor = perDayDivisor(month), perDay = r2(gross / divisor);
    const lopAuto = st.absent + st.unpaid_leave, hasOv = adj.lop_override !== undefined && adj.lop_override !== null && adj.lop_override !== '', lop = hasOv ? Math.max(0, Number(adj.lop_override) || 0) : lopAuto;
    const earnings = [['Basic', basic], ['House rent allowance', hra], ['Dearness allowance', da], ['Other allowance', oth], ['Bonus / arrears', bonus]].filter(x => x[1] > 0).map(([label, amount]) => ({ label, amount }));
    const ded = []; const pf = r2(basic * (Number(prof.pf_percent) || 0) / 100); if (pf > 0) ded.push({ label: `Provident fund (${prof.pf_percent}%)`, amount: pf });
    if (n(prof.prof_tax) > 0) ded.push({ label: 'Professional tax', amount: n(prof.prof_tax) }); if (n(prof.other_deduction) > 0) ded.push({ label: 'Other fixed deduction', amount: n(prof.other_deduction) });
    const lopAmt = Math.min(gross, r2(perDay * lop)); if (lopAmt > 0) ded.push({ label: `Loss of pay (${lop} day${lop === 1 ? '' : 's'})`, amount: lopAmt });
    if (n(adj.advance) > 0) ded.push({ label: 'Advance recovery', amount: n(adj.advance) }); if (n(adj.other_ded) > 0) ded.push({ label: txt(adj.remarks, 40) || 'Other deduction', amount: n(adj.other_ded) });
    const dedTotal = r2(ded.reduce((a, x) => a + x.amount, 0)), totalEarn = r2(earnings.reduce((a, x) => a + x.amount, 0));
    return { earnings, deductions: ded, gross: totalEarn, ded_total: dedTotal, net: Math.max(0, r2(totalEarn - dedTotal)), divisor, per_day: perDay, absent_days: st.absent, leave_days: st.leave, paid_leave_days: st.paid_leave, unpaid_leave_days: st.unpaid_leave, lop_days: lop, adj: { bonus: n(adj.bonus), advance: n(adj.advance), other_ded: n(adj.other_ded), remarks: txt(adj.remarks, 80), lop_override: hasOv ? lop : null } };
  }
  const profFields = b => ({ designation: txt(b.designation, 60), basic: Math.max(0, num(b.basic) || 0), hra: Math.max(0, num(b.hra) || 0), da: Math.max(0, num(b.da) || 0), other_allowance: Math.max(0, num(b.other_allowance) || 0), pf_percent: Math.min(30, Math.max(0, num(b.pf_percent) || 0)), prof_tax: Math.max(0, num(b.prof_tax) || 0), other_deduction: Math.max(0, num(b.other_deduction) || 0), joining_date: dateOk(b.joining_date) ? b.joining_date : '' });
  const staffRows = () => {
    S(); const d = D(), month = today().slice(0, 7), out = [];
    for (const t of d.users.filter(x => x.role === 'teacher')) { const p = d.payroll_staff.find(x => Number(x.user_id) === Number(t.id)); out.push({ key: 't' + t.id, kind: 'teacher', user_id: t.id, name: t.name, employee_id: t.employee_id || '', designation: (p && p.designation) || 'Teacher', has_profile: !!p, active: p ? p.active !== false : false, basic: p ? p.basic : 0, hra: p ? p.hra : 0, da: p ? p.da : 0, other_allowance: p ? p.other_allowance : 0, pf_percent: p ? p.pf_percent : 0, prof_tax: p ? p.prof_tax : 0, other_deduction: p ? p.other_deduction : 0, joining_date: p ? p.joining_date : '', leave: attStats(t.id, month) }); }
    for (const p of d.payroll_staff.filter(x => !x.user_id)) out.push({ key: 's' + p.id, kind: 'staff', user_id: null, name: p.name, employee_id: '', designation: p.designation || '', has_profile: true, active: p.active !== false, basic: p.basic, hra: p.hra, da: p.da, other_allowance: p.other_allowance, pf_percent: p.pf_percent, prof_tax: p.prof_tax, other_deduction: p.other_deduction, joining_date: p.joining_date, leave: null });
    return out;
  };
  route('GET', '/api/payroll/staff', ['admin'], async ({ res }) => json(res, 200, { staff: staffRows(), settings: PR() }), { noClerk: true });
  route('PUT', '/api/payroll/settings', ['admin'], async ({ res, u, v }) => { const b = await v(), p = PR(); p.per_day_basis = ['month_days', 'exclude_sundays', 'fixed'].includes(b.per_day_basis) ? b.per_day_basis : 'month_days'; p.fixed_days = Math.min(31, Math.max(20, num(b.fixed_days) || 30)); p.paid_leave_per_year = Math.min(60, Math.max(0, num(b.paid_leave_per_year) || 0)); p.leave_year_start_month = Math.min(12, Math.max(1, num(b.leave_year_start_month) || 4)); ctx.audit(u, 'PAYROLL_SETTINGS', JSON.stringify({ basis: p.per_day_basis, leave: p.paid_leave_per_year })); json(res, 200, { ok: true }); }, { noClerk: true });
  route('PUT', /^\/api\/payroll\/staff\/([ts])(\d+)$/, ['admin'], async ({ res, u, v, mm }) => {
    const d = D(), b = await v(); S(); let p;
    if (mm[1] === 't') { const t = d.users.find(x => x.id === num(mm[2]) && x.role === 'teacher'); if (!t) return json(res, 404, { error: 'Teacher not found' }); p = d.payroll_staff.find(x => Number(x.user_id) === t.id); if (!p) { p = { id: nid(d.payroll_staff), user_id: t.id, name: t.name, active: true }; d.payroll_staff.push(p); } }
    else { p = d.payroll_staff.find(x => x.id === num(mm[2]) && !x.user_id); if (!p) return json(res, 404, { error: 'Staff member not found' }); if (b.name) p.name = txt(b.name, 60); }
    Object.assign(p, profFields(b)); if (b.active !== undefined) p.active = !!b.active; ctx.audit(u, 'PAYROLL_PROFILE', p.name); json(res, 200, { ok: true });
  }, { noClerk: true });
  route('POST', '/api/payroll/staff', ['admin'], async ({ res, u, v }) => { const d = D(), b = await v(); S(); const name = txt(b.name, 60); if (!name) return json(res, 400, { error: 'Enter the staff member\'s name.' }); const p = { id: nid(d.payroll_staff), user_id: null, name, active: true, ...profFields(b) }; d.payroll_staff.push(p); ctx.audit(u, 'PAYROLL_STAFF_ADD', name); json(res, 200, { ok: true, key: 's' + p.id }); }, { noClerk: true });
  route('DELETE', /^\/api\/payroll\/staff\/s(\d+)$/, ['admin'], async ({ res, u, mm }) => { const d = D(), p = d.payroll_staff.find(x => x.id === num(mm[1]) && !x.user_id); if (!p) return json(res, 404, { error: 'Not found' }); if (d.payslips.some(x => x.staff_id === p.id)) { p.active = false; ctx.audit(u, 'PAYROLL_STAFF_DEACTIVATE', p.name); return json(res, 200, { ok: true, deactivated: true }); } d.payroll_staff = d.payroll_staff.filter(x => x !== p); ctx.audit(u, 'PAYROLL_STAFF_DELETE', p.name); json(res, 200, { ok: true }); }, { noClerk: true });
  route('POST', '/api/payroll/run', ['admin'], async ({ res, u, v }) => {
    const b = await v(), month = String(b.month || ''); if (!monthOk(month)) return json(res, 400, { error: 'Choose a month.' }); const d = D(); S();
    let made = 0, skipped = 0, noProfile = 0;
    for (const p of d.payroll_staff) {
      if (p.active === false) continue; if (!(Number(p.basic) > 0)) { noProfile++; continue; }
      if (d.payslips.some(x => x.staff_id === p.id && x.month === month)) { skipped++; continue; }
      const t = p.user_id ? userRec(p.user_id) : null; if (p.user_id && !t) continue;
      const calc = buildPayslip(p, month, {}); d.payslips.push({ id: nid(d.payslips), month, staff_id: p.id, user_id: p.user_id || null, name: p.name, designation: p.designation || (t ? 'Teacher' : ''), employee_id: t ? t.employee_id || '' : '', ...calc, status: 'Draft', created_at: new Date().toISOString(), created_by: u.name }); made++;
    }
    ctx.audit(u, 'PAYROLL_RUN', `${month}: ${made} created, ${skipped} already existed`); json(res, 200, { ok: true, made, skipped, no_salary: noProfile });
  }, { noClerk: true });
  route('GET', '/api/payslips', ['admin'], async ({ res, url }) => { S(); const m = url.searchParams.get('month') || ''; const rows = D().payslips.filter(x => !m || x.month === m).sort((a, b) => b.month.localeCompare(a.month) || a.name.localeCompare(b.name)); json(res, 200, { rows, total_net: r2(rows.reduce((n, x) => n + x.net, 0)), paid_net: r2(rows.filter(x => x.status === 'Paid').reduce((n, x) => n + x.net, 0)) }); }, { noClerk: true });
  const slip = id => D().payslips.find(x => x.id === num(id));
  route('PUT', /^\/api\/payslips\/(\d+)$/, ['admin'], async ({ res, u, v, mm }) => { const ps = slip(mm[1]); if (!ps) return json(res, 404, { error: 'Not found' }); if (ps.status === 'Paid') return json(res, 400, { error: 'Paid payslips cannot be changed. Undo the payment first.' }); const b = await v(), prof = D().payroll_staff.find(x => x.id === ps.staff_id); if (!prof) return json(res, 404, { error: 'Staff record missing' }); Object.assign(ps, buildPayslip(prof, ps.month, b)); ctx.audit(u, 'PAYSLIP_EDIT', ps.name + ' ' + ps.month); json(res, 200, { ok: true, payslip: ps }); }, { noClerk: true });
  route('POST', /^\/api\/payslips\/(\d+)\/pay$/, ['admin'], async ({ res, u, v, mm }) => { const ps = slip(mm[1]); if (!ps) return json(res, 404, { error: 'Not found' }); if (ps.status === 'Paid') return json(res, 400, { error: 'Already paid' }); const b = await v(); ps.status = 'Paid'; ps.paid_date = dateOk(b.paid_date) ? b.paid_date : today(); ps.mode = ['Cash', 'Bank', 'UPI', 'Cheque', 'Other'].includes(b.mode) ? b.mode : 'Bank'; ps.ref = txt(b.ref, 40); ps.paid_by = u.name; ctx.audit(u, 'PAYSLIP_PAID', `${ps.name} ${ps.month} ₹${money(ps.net)}`); json(res, 200, { ok: true }); }, { noClerk: true });
  route('POST', /^\/api\/payslips\/(\d+)\/unpay$/, ['admin'], async ({ res, u, mm }) => { const ps = slip(mm[1]); if (!ps || ps.status !== 'Paid') return json(res, 400, { error: 'Not a paid payslip' }); ps.status = 'Draft'; ps.paid_date = ''; ps.notified = false; ctx.audit(u, 'PAYSLIP_UNPAID', ps.name + ' ' + ps.month); json(res, 200, { ok: true }); }, { noClerk: true });
  route('DELETE', /^\/api\/payslips\/(\d+)$/, ['admin'], async ({ res, u, mm }) => { const ps = slip(mm[1]); if (!ps) return json(res, 404, { error: 'Not found' }); if (ps.status === 'Paid') return json(res, 400, { error: 'Paid payslips cannot be deleted.' }); D().payslips = D().payslips.filter(x => x !== ps); ctx.audit(u, 'PAYSLIP_DELETE', ps.name + ' ' + ps.month); json(res, 200, { ok: true }); }, { noClerk: true });
  route('GET', '/api/payroll/mine', ['teacher'], async ({ res, u }) => { S(); const month = today().slice(0, 7); json(res, 200, { payslips: D().payslips.filter(x => Number(x.user_id) === Number(u.id) && x.status === 'Paid').sort((a, b) => b.month.localeCompare(a.month)).map(x => ({ id: x.id, month: x.month, net: x.net, paid_date: x.paid_date })), leave: attStats(u.id, month), year_start: leaveYearStart(month + '-01') }); });
  function words(n) { n = Math.round(n); if (n === 0) return 'Zero'; const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'], b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']; const two = x => x < 20 ? a[x] : b[Math.floor(x / 10)] + (x % 10 ? ' ' + a[x % 10] : ''); const three = x => (x >= 100 ? a[Math.floor(x / 100)] + ' Hundred' + (x % 100 ? ' ' : '') : '') + (x % 100 ? two(x % 100) : ''); let out = []; const cr = Math.floor(n / 1e7); n %= 1e7; const lk = Math.floor(n / 1e5); n %= 1e5; const th = Math.floor(n / 1e3); n %= 1e3; if (cr) out.push(three(cr) + ' Crore'); if (lk) out.push(two(lk) + ' Lakh'); if (th) out.push(two(th) + ' Thousand'); if (n) out.push(three(n)); return out.join(' '); }
  route('GET', /^\/api\/payslip\/(\d+)\/print$/, [], async ({ res, u, mm }) => {
    const ps = slip(mm[1]); if (!ps) return sendHtml(res, 404, page('Payslip', '<p>Not found.</p>'));
    if (u.role === 'teacher') { if (Number(ps.user_id) !== Number(u.id) || ps.status !== 'Paid') return sendHtml(res, 403, page('Payslip', '<p>This payslip is not available.</p>')); } else if (u.role !== 'admin' || isClerk(u)) return sendHtml(res, 403, page('Payslip', '<p>Permission denied.</p>'));
    const [y, m] = ps.month.split('-'), mname = new Date(+y, +m - 1, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }), n = Math.max(ps.earnings.length, ps.deductions.length);
    let rows = ''; for (let i = 0; i < n; i++) { const e = ps.earnings[i], dd = ps.deductions[i]; rows += `<tr><td>${e ? esc(e.label) : ''}</td><td class="r">${e ? money(e.amount) : ''}</td><td>${dd ? esc(dd.label) : ''}</td><td class="r">${dd ? money(dd.amount) : ''}</td></tr>`; }
    const body = `<div style="max-width:760px;margin:auto;border:1.5px solid #111;padding:16px"><div style="display:flex;align-items:center;gap:12px;border-bottom:2px solid #111;padding-bottom:8px"><img src="/assets/holyfaith-logo.png" alt="" style="height:54px"><div style="flex:1;text-align:center"><h2>${esc(PR().school_name)}</h2><div style="font-weight:700">PAYSLIP — ${esc(mname)}</div></div></div>
<table style="margin:10px 0;border:0"><tr><td style="border:0">Name: <b>${esc(ps.name)}</b></td><td style="border:0">Designation: ${esc(ps.designation)}</td></tr><tr><td style="border:0">Employee ID: ${esc(ps.employee_id || '—')}</td><td style="border:0">Status: ${esc(ps.status)}${ps.paid_date ? ' on ' + esc(ps.paid_date) + ' (' + esc(ps.mode) + ')' : ''}</td></tr><tr><td style="border:0">Absent: ${ps.absent_days} • Leave: ${ps.leave_days} (paid ${ps.paid_leave_days})</td><td style="border:0">Loss-of-pay days: ${ps.lop_days}</td></tr></table>
<table><thead><tr><th>Earnings</th><th class="r">₹</th><th>Deductions</th><th class="r">₹</th></tr></thead><tbody>${rows}<tr><th>Total earnings</th><th class="r">${money(ps.gross)}</th><th>Total deductions</th><th class="r">${money(ps.ded_total)}</th></tr></tbody></table>
<p style="font-size:16px;margin:12px 0 2px"><b>Net pay: ₹${money(ps.net)}</b></p><p class="muted" style="margin:0">Rupees ${esc(words(ps.net))} only</p><div style="display:flex;justify-content:space-between;margin-top:40px;font-size:12px"><span>Employee signature</span><span>Authorised signatory</span></div></div>`;
    sendHtml(res, 200, page('Payslip — ' + ps.name + ' ' + ps.month, body));
  });

  /* =====================================================================
     6. STUDENT DIARY & REMARKS (with parent acknowledgement)
     ===================================================================== */
  const DIARY_TYPES = ['Note', 'Praise', 'Concern', 'Behaviour', 'Health', 'Homework', 'Event'];
  function diaryFor(u, q) {
    S(); const d = D(); let rows = d.diary.slice(); const kids = ctx.scope(u), ids = new Set(kids.map(k => Number(k.id)));
    if (u.role === 'guardian') rows = rows.filter(e => e.visible_to_guardian && (e.student_id ? ids.has(Number(e.student_id)) : kids.some(k => Number(k.class_id) === Number(e.class_id) && (!Number(e.section_id) || Number(k.section_id) === Number(e.section_id)))));
    else if (u.role === 'teacher') rows = rows.filter(e => Number(e.created_by) === Number(u.id) || (e.student_id ? ids.has(Number(e.student_id)) : teacherOk(u, e.class_id, e.section_id)));
    if (q.student_id) rows = rows.filter(e => Number(e.student_id) === Number(q.student_id) || (!e.student_id && kids.some(k => Number(k.id) === Number(q.student_id) && Number(k.class_id) === Number(e.class_id))));
    const n = ctx.names();
    return rows.sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id).slice(0, 200).map(e => { const st = e.student_id ? d.students.find(s => Number(s.id) === Number(e.student_id)) : null; const mine = u.role === 'guardian' ? kids.filter(k => e.student_id ? Number(k.id) === Number(e.student_id) : Number(k.class_id) === Number(e.class_id)).map(k => ({ id: k.id, name: k.name, acked: (e.acks || []).some(a => Number(a.student_id) === Number(k.id)) })) : undefined; return { id: e.id, date: e.date, type: e.type, title: e.title, body: e.body, student_id: e.student_id || null, student: st ? st.name : '', scope: e.student_id ? 'student' : 'class', class_name: n.cls[e.class_id] || '', section_name: n.sec[e.section_id] || '', by: n.user[e.created_by] || 'School', visible_to_guardian: !!e.visible_to_guardian, ack_count: (e.acks || []).length, mine, can_delete: u.role === 'admin' || Number(e.created_by) === Number(u.id) }; });
  }
  route('GET', '/api/diary', [], async ({ res, u, url }) => json(res, 200, { rows: diaryFor(u, { student_id: url.searchParams.get('student_id') }), types: DIARY_TYPES }));
  route('POST', '/api/diary', ['admin', 'teacher'], async ({ res, u, v }) => {
    const b = await v(), d = D(); S(); const type = DIARY_TYPES.includes(b.type) ? b.type : 'Note', body = txt(b.body, 1500), title = txt(b.title, 80); if (!body) return json(res, 400, { error: 'Write the note.' });
    const base = { type, title: title || type, body, date: dateOk(b.date) ? b.date : today(), visible_to_guardian: b.visible_to_guardian !== false, created_by: u.id, acks: [], created_at: new Date().toISOString() };
    const sids = (Array.isArray(b.student_ids) ? b.student_ids : (b.student_id ? [b.student_id] : [])).map(num).filter(Boolean); let made = 0;
    if (sids.length) { for (const sid of sids.slice(0, 80)) { const st = ctx.studentForUser(u, sid); if (!st) return forbid(res, 'You can only write about students in your class.'); d.diary.push({ id: nid(d.diary), student_id: st.id, class_id: st.class_id, section_id: st.section_id, ...base }); made++; } }
    else { const cid = num(b.class_id) || 0, sec = num(b.section_id) || 0; if (!cid || !d.classes.some(c => c.id === cid)) return json(res, 400, { error: 'Choose a student or a class.' }); if (!teacherOk(u, cid, sec)) return forbid(res, 'You can only write to your own class.'); d.diary.push({ id: nid(d.diary), student_id: null, class_id: cid, section_id: sec, ...base }); made++; }
    ctx.audit(u, 'DIARY_ADD', `${type} • ${made} entr${made === 1 ? 'y' : 'ies'}`); json(res, 200, { ok: true, made });
  });
  route('DELETE', /^\/api\/diary\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm }) => { const e = D().diary.find(x => x.id === num(mm[1])); if (!e) return json(res, 404, { error: 'Not found' }); if (u.role !== 'admin' && Number(e.created_by) !== Number(u.id)) return forbid(res); D().diary = D().diary.filter(x => x !== e); ctx.audit(u, 'DIARY_DELETE', e.title); json(res, 200, { ok: true }); });
  route('POST', /^\/api\/diary\/(\d+)\/ack$/, ['guardian'], async ({ res, u, v, mm }) => { const e = D().diary.find(x => x.id === num(mm[1])), b = await v(); if (!e) return json(res, 404, { error: 'Not found' }); const st = ctx.studentForUser(u, num(b.student_id)); if (!st || !e.visible_to_guardian) return forbid(res); if (e.student_id ? Number(e.student_id) !== Number(st.id) : Number(e.class_id) !== Number(st.class_id)) return forbid(res); e.acks = e.acks || []; if (!e.acks.some(a => Number(a.student_id) === Number(st.id))) { e.acks.push({ student_id: st.id, by: u.id, at: new Date().toISOString() }); ctx.save(); } json(res, 200, { ok: true }); });

  /* =====================================================================
     7. SYLLABUS & LESSON-PLAN TRACKER
     ===================================================================== */
  const SYL_STATUS = ['Not started', 'In progress', 'Completed'];
  const sylClean = (b, item) => {
    const d = D(); const cid = num(b.class_id) || 0, sid = num(b.subject_id) || 0, title = txt(b.title, 120);
    if (!title) return { error: 'Give the chapter or unit a title.' }; if (!d.classes.some(c => c.id === cid)) return { error: 'Choose a class.' }; if (!d.subjects.some(s => s.id === sid)) return { error: 'Choose a subject.' };
    const status = SYL_STATUS.includes(b.status) ? b.status : (item.status || 'Not started');
    Object.assign(item, { class_id: cid, subject_id: sid, year_id: num(b.year_id) || ((d.years.find(y => y.is_current) || {}).id || 0), title, topics: txt(b.topics, 1500), objectives: txt(b.objectives, 1000), activities: txt(b.activities, 1000), resources: txt(b.resources, 600), assessment: txt(b.assessment, 600), planned_start: dateOk(b.planned_start) ? b.planned_start : '', planned_end: dateOk(b.planned_end) ? b.planned_end : '', periods: Math.max(0, num(b.periods) || 0), visible_to_guardian: b.visible_to_guardian !== false, status });
    item.percent = status === 'Completed' ? 100 : status === 'Not started' ? 0 : Math.min(99, Math.max(1, num(b.percent) || item.percent || 50));
    if (status === 'Completed') item.completed_on = item.completed_on || today(); else item.completed_on = '';
    return { item };
  };
  route('GET', '/api/syllabus', [], async ({ res, u, url }) => {
    S(); let rows = D().syllabus.slice(); const cq = num(url.searchParams.get('class_id')) || 0, sq = num(url.searchParams.get('subject_id')) || 0;
    if (u.role === 'guardian') { const cls = new Set(ctx.scope(u).map(s => Number(s.class_id))); rows = rows.filter(x => x.visible_to_guardian && cls.has(Number(x.class_id))); }
    if (cq) rows = rows.filter(x => Number(x.class_id) === cq); if (sq) rows = rows.filter(x => Number(x.subject_id) === sq);
    const n = ctx.names(), t = today();
    json(res, 200, { rows: rows.sort((a, b) => a.class_id - b.class_id || a.subject_id - b.subject_id || (a.planned_start || '9').localeCompare(b.planned_start || '9') || a.id - b.id).map(x => ({ ...x, class_name: n.cls[x.class_id] || '', subject_name: n.sub[x.subject_id] || '', behind: x.status !== 'Completed' && !!x.planned_end && x.planned_end < t, can_edit: u.role === 'admin' || (u.role === 'teacher' && teacherOk(u, x.class_id)) })) });
  });
  route('GET', '/api/syllabus/summary', ['admin', 'teacher'], async ({ res, u }) => {
    S(); const n = ctx.names(), t = today(), g = new Map();
    for (const x of D().syllabus) { if (u.role === 'teacher' && !teacherOk(u, x.class_id)) continue; const k = x.class_id + '|' + x.subject_id; if (!g.has(k)) g.set(k, { class_id: x.class_id, class_name: n.cls[x.class_id] || '', subject_id: x.subject_id, subject_name: n.sub[x.subject_id] || '', total: 0, done: 0, behind: 0, sum: 0 }); const e = g.get(k); e.total++; e.sum += Number(x.percent) || 0; if (x.status === 'Completed') e.done++; else if (x.planned_end && x.planned_end < t) e.behind++; }
    json(res, 200, { rows: [...g.values()].map(e => ({ ...e, percent: e.total ? Math.round(e.sum / e.total) : 0, sum: undefined })).sort((a, b) => a.class_id - b.class_id || a.subject_name.localeCompare(b.subject_name)) });
  });
  route('POST', '/api/syllabus', ['admin', 'teacher'], async ({ res, u, v }) => { const b = await v(), d = D(); S(); const item = { id: nid(d.syllabus), created_by: u.id, created_at: new Date().toISOString() }; const r = sylClean(b, item); if (r.error) return json(res, 400, r); if (!teacherOk(u, item.class_id)) return forbid(res, 'You can only plan for your own class.'); d.syllabus.push(item); ctx.audit(u, 'SYLLABUS_ADD', item.title); json(res, 200, { ok: true, id: item.id }); });
  route('PUT', /^\/api\/syllabus\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, v, mm }) => { const item = D().syllabus.find(x => x.id === num(mm[1])); if (!item) return json(res, 404, { error: 'Not found' }); if (!teacherOk(u, item.class_id)) return forbid(res); const b = await v(), merged = { ...item, ...b }; const r = sylClean(merged, item); if (r.error) return json(res, 400, r); ctx.audit(u, 'SYLLABUS_UPDATE', item.title + ' • ' + item.status); json(res, 200, { ok: true }); });
  route('DELETE', /^\/api\/syllabus\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm }) => { const item = D().syllabus.find(x => x.id === num(mm[1])); if (!item) return json(res, 404, { error: 'Not found' }); if (!teacherOk(u, item.class_id)) return forbid(res); D().syllabus = D().syllabus.filter(x => x !== item); ctx.audit(u, 'SYLLABUS_DELETE', item.title); json(res, 200, { ok: true }); });

  /* =====================================================================
     8. PHOTO GALLERY (albums, optionally tied to a calendar event; files go to storage = R2/Postgres/local)
     ===================================================================== */
  const readRaw = (req, limit) => new Promise((ok, no) => { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > limit) { req.destroy(); no(new Error('too large')); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch))); req.on('error', no); });
  const sniff = b => b.length > 12 && b[0] === 0xFF && b[1] === 0xD8 ? ['image/jpeg', 'jpg'] : b.length > 12 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])) ? ['image/png', 'png'] : b.length > 12 && b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' ? ['image/webp', 'webp'] : b.length > 12 && b.subarray(0, 3).toString() === 'GIF' ? ['image/gif', 'gif'] : null;
  const GAL_MAX = 8 * 1024 * 1024, GAL_PER_ALBUM = 150;
  const albumVisible = (u, al) => u.role !== 'guardian' || !Number(al.class_id) || ctx.scope(u).some(k => Number(k.class_id) === Number(al.class_id));
  const albumOut = (al, u) => { const d = D(), ph = d.gallery_photos.filter(p => p.album_id === al.id), ev = al.event_id ? d.events.find(e => Number(e.id) === Number(al.event_id)) : null, n = ctx.names(); return { id: al.id, title: al.title, date: al.date, description: al.description, class_id: al.class_id || 0, class_name: Number(al.class_id) ? n.cls[al.class_id] || '' : 'Whole school', event_id: al.event_id || 0, event_title: ev ? ev.title : '', count: ph.length, cover: ph.length ? ph[0].id : 0, can_edit: u.role === 'admin' || (u.role === 'teacher' && Number(al.created_by) === Number(u.id)) }; };
  route('GET', '/api/gallery/albums', [], async ({ res, u }) => { S(); const d = D(); json(res, 200, { rows: d.albums.filter(a => albumVisible(u, a)).sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id).map(a => albumOut(a, u)), events: u.role === 'guardian' ? [] : d.events.slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 60).map(e => ({ id: e.id, title: e.title, date: e.date })) }); });
  const albumInput = (b, al, u) => { const title = txt(b.title, 80); if (!title) return { error: 'Give the album a title.' }; const cid = Math.max(0, num(b.class_id) || 0); if (cid && !D().classes.some(c => c.id === cid)) return { error: 'Choose a valid class.' }; if (u.role === 'teacher' && cid && !teacherOk(u, cid)) return { error: 'Teachers can post to their own class or the whole school.' }; Object.assign(al, { title, date: dateOk(b.date) ? b.date : today(), description: txt(b.description, 400), class_id: cid, event_id: D().events.some(e => Number(e.id) === num(b.event_id)) ? num(b.event_id) : 0 }); return { al }; };
  route('POST', '/api/gallery/albums', ['admin', 'teacher'], async ({ res, u, v }) => { const d = D(); S(); const al = { id: nid(d.albums), created_by: u.id, created_at: new Date().toISOString() }; const r = albumInput(await v(), al, u); if (r.error) return json(res, 400, r); d.albums.push(al); ctx.audit(u, 'ALBUM_ADD', al.title); json(res, 200, { ok: true, id: al.id }); });
  route('PUT', /^\/api\/gallery\/albums\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, v, mm }) => { const al = D().albums.find(x => x.id === num(mm[1])); if (!al) return json(res, 404, { error: 'Not found' }); if (u.role !== 'admin' && Number(al.created_by) !== Number(u.id)) return forbid(res); const r = albumInput(await v(), al, u); if (r.error) return json(res, 400, r); ctx.audit(u, 'ALBUM_EDIT', al.title); json(res, 200, { ok: true }); });
  route('DELETE', /^\/api\/gallery\/albums\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm }) => {
    const d = D(), al = d.albums.find(x => x.id === num(mm[1])); if (!al) return json(res, 404, { error: 'Not found' }); if (u.role !== 'admin' && Number(al.created_by) !== Number(u.id)) return forbid(res);
    for (const p of d.gallery_photos.filter(x => x.album_id === al.id)) { try { await ctx.storage.deleteObject(p.key); } catch { } }
    d.gallery_photos = d.gallery_photos.filter(x => x.album_id !== al.id); d.albums = d.albums.filter(x => x !== al); ctx.audit(u, 'ALBUM_DELETE', al.title); json(res, 200, { ok: true });
  });
  route('GET', /^\/api\/gallery\/albums\/(\d+)$/, [], async ({ res, u, mm }) => { const al = D().albums.find(x => x.id === num(mm[1])); if (!al || !albumVisible(u, al)) return json(res, 404, { error: 'Not found' }); json(res, 200, { album: albumOut(al, u), photos: D().gallery_photos.filter(p => p.album_id === al.id).map(p => ({ id: p.id, name: p.name, caption: p.caption || '' })) }); });
  route('POST', /^\/api\/gallery\/albums\/(\d+)\/photos$/, ['admin', 'teacher'], async ({ req, res, u, mm }) => {
    const d = D(), al = d.albums.find(x => x.id === num(mm[1])); if (!al) { req.resume(); return json(res, 404, { error: 'Album not found' }); }
    if (u.role !== 'admin' && Number(al.created_by) !== Number(u.id)) { req.resume(); return forbid(res); }
    if (d.gallery_photos.filter(p => p.album_id === al.id).length >= GAL_PER_ALBUM) { req.resume(); return json(res, 400, { error: `An album can hold ${GAL_PER_ALBUM} photos.` }); }
    const len = Number(req.headers['content-length'] || 0); if (!len) return json(res, 411, { error: 'File size is required' }); if (len > GAL_MAX) { req.resume(); return json(res, 413, { error: 'Photo is too large (max 8 MB).' }); }
    let buf; try { buf = await readRaw(req, GAL_MAX); } catch { return json(res, 413, { error: 'Photo is too large (max 8 MB).' }); }
    const kind = sniff(buf); if (!kind) return json(res, 400, { error: 'Only JPG, PNG, WebP or GIF photos are allowed.' });
    let nm = 'photo'; try { nm = decodeURIComponent(String(req.headers['x-file-name'] || 'photo')); } catch { }
    const key = `malancha/gallery/${al.id}/${crypto.randomUUID()}.${kind[1]}`;
    try { await ctx.storage.putBuffer(key, buf, { contentType: kind[0] }); } catch (e) { console.error('Gallery upload failed:', e.message); return json(res, 500, { error: 'Upload failed' }); }
    const p = { id: nid(d.gallery_photos), album_id: al.id, key, mime: kind[0], name: txt(nm.replace(/[^\w.\- ]+/g, '_'), 80), size: buf.length, uploaded_by: u.id, at: new Date().toISOString() }; d.gallery_photos.push(p); ctx.save(); json(res, 200, { ok: true, id: p.id });
  });
  route('GET', /^\/api\/gallery\/photo\/(\d+)$/, [], async ({ res, u, mm }) => {
    const p = D().gallery_photos.find(x => x.id === num(mm[1])), al = p && D().albums.find(a => a.id === p.album_id); if (!p || !al || !albumVisible(u, al)) return json(res, 404, { error: 'Not found' });
    try { const obj = await ctx.storage.getObject(p.key); res.writeHead(200, { 'Content-Type': p.mime, 'Content-Length': String(p.size), 'Cache-Control': 'private, max-age=86400', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'; sandbox" }); obj.Body.pipe(res); } catch { json(res, 404, { error: 'Photo is unavailable' }); }
  });
  route('DELETE', /^\/api\/gallery\/photos\/(\d+)$/, ['admin', 'teacher'], async ({ res, u, mm }) => { const d = D(), p = d.gallery_photos.find(x => x.id === num(mm[1])), al = p && d.albums.find(a => a.id === p.album_id); if (!p || !al) return json(res, 404, { error: 'Not found' }); if (u.role !== 'admin' && Number(al.created_by) !== Number(u.id)) return forbid(res); try { await ctx.storage.deleteObject(p.key); } catch { } d.gallery_photos = d.gallery_photos.filter(x => x !== p); ctx.audit(u, 'PHOTO_DELETE', al.title); json(res, 200, { ok: true }); });

  /* =====================================================================
     dispatcher + background jobs
     ===================================================================== */
  async function handle(req, res, p, url) {
    if (!p.startsWith('/api/')) return false;
    if (req.method === 'POST' && p === '/api/login') return loginGuard(req, res);
    for (const r of routes) {
      if (r.method !== req.method) continue; const mm = p.match(r.pat); if (!mm) continue;
      if (await twoFaGate(req, res, p)) return true;
      let u = null; if (r.roles !== false) { u = await ctx.auth(req, res, r.roles || []); if (!u) return true; if (r.opts.noClerk && isClerk(u)) return forbid(res, 'This is not available for a clerk account.'), true; }
      try { await r.fn({ req, res, u, mm, url, p, v: () => ctx.body(req) }); }
      catch (e) { console.error('V10 route error', p, e); if (!res.headersSent) json(res, 500, { error: 'Something went wrong. Please try again.' }); }
      return true;
    }
    return twoFaGate(req, res, p);
  }
  function start() {
    S(); vapid();
    const safe = (fn, label) => () => { fn().catch(e => console.error('V10 ' + label + ':', e.message)); };
    setTimeout(safe(pollEvents, 'events'), 8000); setInterval(safe(pollEvents, 'events'), 60000).unref?.();
    setInterval(safe(async () => { const R = S().reminders; if (R.enabled && R.last_run !== today() && new Date().getHours() >= R.hour) await runReminders('scheduled'); }, 'reminders'), 10 * 60000).unref?.();
  }
  return { handle, start, notify, _test: { totpCheck, hotp, b32dec, b32enc, buildPayslip, dueMessages, runReminders, settleOnline } };
};
